import React, { useState, useEffect } from 'react';
import { RESTAURANTS } from './data';
import { MenuItem, CartItem, Order, Restaurant, PromoCode, WalletTransaction, Rider, User, Role } from './types';
import Header from './components/Header';
import AIChatBot from './components/AIChatBot';
import RestaurantCard from './components/RestaurantCard';
import MenuSection from './components/MenuSection';
import CartPanel from './components/CartPanel';
import CheckoutModal from './components/CheckoutModal';
import OrderTracking from './components/OrderTracking';
import OrderHistoryModal from './components/OrderHistoryModal';
import TrendingDiscovery from './components/TrendingDiscovery';
import TopRidersSection from './components/TopRidersSection';
import WalletDashboardModal from './components/WalletDashboardModal';
import InfoModal from './components/InfoModal';
import BackToTop from './components/BackToTop';
import { motion, AnimatePresence } from 'motion/react';
import { ChefHat, ShoppingBag, Sparkles, TrendingUp, X, Award, UtensilsCrossed, Bell, Shield, ShieldCheck, Database, Truck, Compass, CheckCircle2, Instagram, Facebook, Music } from 'lucide-react';

import AuthRolePortal from './components/AuthRolePortal';
import RestaurantPortal from './components/RestaurantPortal';
import RiderPortal from './components/RiderPortal';
import AdminPortal from './components/AdminPortal';
import PaymentGateway from './components/PaymentGateway';

export default function App() {
  // Unified Memory Databases with Persistence
  const [restaurantsList, setRestaurantsList] = useState<Restaurant[]>(() => {
    const saved = localStorage.getItem('foodwala_restaurants');
    return saved ? JSON.parse(saved) : RESTAURANTS;
  });

  const [ordersList, setOrdersList] = useState<Order[]>(() => {
    const saved = localStorage.getItem('foodwala_orders_list');
    return saved ? JSON.parse(saved) : [];
  });

  const [feedbackList, setFeedbackList] = useState<any[]>(() => {
    const saved = localStorage.getItem('foodwala_feedback_list');
    return saved ? JSON.parse(saved) : [
      { name: 'Ayesha Khan', email: 'ayesha@mail.com', message: 'Best biryani ever! Speed of delivery was incredible.', rating: 5 },
      { name: 'Zainab Ahmed', email: 'zainab@mail.com', message: 'KFC chicken was super crispy. Warm and delicious!', rating: 5 },
      { name: 'Hamza Farooq', email: 'hamza@mail.com', message: 'Very helpful interface, Lahore map routing looks incredible.', rating: 5 }
    ];
  });

  const [usersList, setUsersList] = useState<User[]>(() => {
    const saved = localStorage.getItem('foodwala_users_list');
    if (saved) return JSON.parse(saved);
    return [
      { id: 'usr-0', name: 'Super Owner', email: 'super@foodwala.com', role: 'super_owner', status: 'active', created_at: '2026-07-01', username: 'super', passcode: 'super123' },
      { id: 'usr-1', name: 'Ahmad Butt', email: 'ahmad@mail.com', role: 'customer', status: 'active', created_at: '2026-07-01' },
      { id: 'usr-2', name: 'Fatima Malik', email: 'fatima@mail.com', role: 'customer', status: 'active', created_at: '2026-07-05' }
    ];
  });

  const [ridersList, setRidersList] = useState<Rider[]>([
    { id: 'rider-1', name: 'Sajid Iqbal', phone: '03009876543', status: 'available', vehicle: 'Honda CD70', rating: 4.8, reviewsCount: 120, completedDeliveries: 450 },
    { id: 'rider-2', name: 'Noman Ali', phone: '03121234567', status: 'delivering', vehicle: 'Yamaha YBR125', rating: 4.5, reviewsCount: 95, completedDeliveries: 380 },
    { id: 'rider-3', name: 'Waseem Akram', phone: '03214567890', status: 'available', vehicle: 'United 70cc', rating: 4.9, reviewsCount: 150, completedDeliveries: 500 }
  ]);
  const [subscriberEmail, setSubscriberEmail] = useState('');
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [shouldShake, setShouldShake] = useState(false);
  const [subscriptionError, setSubscriptionError] = useState('');
  const [lang, setLang] = useState<'en' | 'ur'>('en');

  const t = (key: 'brand' | 'copyright' | 'placeholder' | 'subscribe' | 'subscribed') => {
    const translations = {
      en: {
        brand: "Food Wala Pakistan",
        copyright: "© 2026 Food Wala. All rights reserved. Hyderabad, Sindh Express Delivery Service.",
        placeholder: "Enter your email",
        subscribe: "Subscribe",
        subscribed: "Subscribed!"
      },
      ur: {
        brand: "فوڈ والا پاکستان",
        copyright: "© 2026 فوڈ والا۔ تمام حقوق محفوظ ہیں۔ لاہور ایکسپریس ڈیلیوری سروس۔",
        placeholder: "اپنا ای میل درج کریں",
        subscribe: "سبسکرائب کریں",
        subscribed: "سبسکرائب کر لیا!"
      }
    };
    return translations[lang][key];
  };

  // Role Routing & Active Session States
  const [activeRole, setActiveRole] = useState<Role>(() => {
    return (localStorage.getItem('foodwala_session_role') as Role) || 'customer';
  });
  const [merchantRestId, setMerchantRestId] = useState('kfc');
  const [merchantRestName, setMerchantRestName] = useState('KFC');
  const [riderSessionName, setRiderSessionName] = useState('Sajid Iqbal');

  // Push Notifications Banner Alerts State
  const [notifications, setNotifications] = useState<{ id: string; title: string; message: string; timestamp: string }[]>([]);

  // Core Application States
  const [activeRestaurant, setActiveRestaurant] = useState<Restaurant | null>(null);
  const [cartItems, setCartItems] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem('foodwala_cart');
    return saved ? JSON.parse(saved) : [];
  });
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('All');
  const [deliveryMethod, setDeliveryMethod] = useState<'delivery' | 'pickup'>('delivery');
  const [appliedPromo, setAppliedPromo] = useState<PromoCode | null>(null);
  const [chefNotes, setChefNotes] = useState('');
  
  // UI Flow States
  const [checkoutModalOpen, setCheckoutModalOpen] = useState(false);
  const [paymentGatewayOpen, setPaymentGatewayOpen] = useState(false);
  const [pendingOrderDetails, setPendingOrderDetails] = useState<any>(null);
  const [historyModalOpen, setHistoryModalOpen] = useState(false);

  const [orderHistory, setOrderHistory] = useState<Order[]>(() => {
    const saved = localStorage.getItem('foodwala_order_history');
    return saved ? JSON.parse(saved) : [];
  });
  const [placedOrder, setPlacedOrder] = useState<Order | null>(() => {
    const saved = localStorage.getItem('foodwala_active_order');
    return saved ? JSON.parse(saved) : null;
  });
  const [mobileCartOpen, setMobileCartOpen] = useState(false);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'info' | 'error' | 'newsletter'; email?: string } | null>(null);

  // FoodWala Wallet state
  const [walletBalance, setWalletBalance] = useState<number>(() => {
    const saved = localStorage.getItem('foodwala_wallet_balance');
    return saved ? parseFloat(saved) : 50;
  });

  const [walletTransactions, setWalletTransactions] = useState<WalletTransaction[]>(() => {
    const saved = localStorage.getItem('foodwala_wallet_transactions');
    return saved ? JSON.parse(saved) : [
      {
        id: 'WTX-801293',
        type: 'cashback',
        amount: 50,
        channel: 'wallet_system',
        timestamp: new Date().toLocaleString(),
        status: 'completed',
        notes: '🏆 Welcome to FoodWala Wallet Bonus'
      }
    ];
  });

  const [adminsList, setAdminsList] = useState(() => {
    const saved = localStorage.getItem('foodwala_admins_list');
    return saved ? JSON.parse(saved) : [
        { id: 'adm-1', name: 'Mohsin Ali', username: 'mohsin', passcode: 'mohsin123', role: 'super_admin', status: 'active', created_at: '2026-07-13' },
        { id: 'adm-2', name: 'System Admin', username: 'admin', passcode: 'admin123', role: 'admin', status: 'active', created_at: '2026-07-13' }
    ];
  });

  const [walletModalOpen, setWalletModalOpen] = useState(false);
  const [customerAddress, setCustomerAddress] = useState<string>("Model Town, Hyderabad, Sindh");
  const [activeInfoModal, setActiveInfoModal] = useState<'about' | 'privacy' | 'contact' | 'careers' | null>(null);
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const [showBackToTop, setShowBackToTop] = useState(false);

  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  useEffect(() => {
    const handleScroll = () => {
      setShowBackToTop(window.scrollY > window.innerHeight / 2);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const toggleTheme = () => {
    setTheme(prev => prev === 'light' ? 'dark' : 'light');
  };

  const showToast = (message: string, type: 'success' | 'info' | 'error' = 'success') => {
    setToast({ message, type });
  };

  useEffect(() => {
    if (toast) {
      const timer = setTimeout(() => setToast(null), 3000);
      return () => clearTimeout(timer);
    }
  }, [toast]);

  // Sync state lists with Local Storage
  useEffect(() => {
    localStorage.setItem('foodwala_restaurants', JSON.stringify(restaurantsList));
  }, [restaurantsList]);

  useEffect(() => {
    localStorage.setItem('foodwala_orders_list', JSON.stringify(ordersList));
  }, [ordersList]);

  useEffect(() => {
    localStorage.setItem('foodwala_feedback_list', JSON.stringify(feedbackList));
  }, [feedbackList]);

  useEffect(() => {
    localStorage.setItem('foodwala_wallet_balance', walletBalance.toString());
  }, [walletBalance]);

  useEffect(() => {
    localStorage.setItem('foodwala_wallet_transactions', JSON.stringify(walletTransactions));
  }, [walletTransactions]);

  useEffect(() => {
    localStorage.setItem('foodwala_admins_list', JSON.stringify(adminsList));
  }, [adminsList]);

  // Notifications handler
  const addNotification = (title: string, message: string) => {
    const newNotif = {
      id: `notif-${Date.now()}`,
      title,
      message,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    setNotifications(prev => [newNotif, ...prev]);
  };

  // Status transitions
  const handleUpdateOrderStatus = (orderId: string, status: 'received' | 'preparing' | 'delivery' | 'delivered') => {
    // 1. Update in ordersList
    setOrdersList((prev) => {
      const updated = prev.map((o) => (o.id === orderId ? { ...o, status } : o));
      localStorage.setItem('foodwala_orders_list', JSON.stringify(updated));
      return updated;
    });

    // 2. Update in placedOrder if it matches active order
    if (placedOrder && placedOrder.id === orderId) {
      setPlacedOrder((prev) => (prev ? { ...prev, status } : null));
    }

    // 3. Update in orderHistory
    setOrderHistory((prev) => {
      const updated = prev.map((o) => (o.id === orderId ? { ...o, status } : o));
      localStorage.setItem('foodwala_order_history', JSON.stringify(updated));
      return updated;
    });

    // 4. Fire high fidelity push notification
    const restName = ordersList.find((o) => o.id === orderId)?.items[0]?.restaurantName || 'the merchant';
    if (status === 'preparing') {
      addNotification('Order Accepted!', `${restName} is now preparing your delicious meal.`);
    } else if (status === 'delivery') {
      addNotification('Out for Delivery!', `Rider is bringing your order from ${restName} to your address.`);
    } else if (status === 'delivered') {
      addNotification('Order Delivered!', `Your food from ${restName} has been handed off successfully.`);
    }
  };

  // Menu price mod helper
  const handleUpdateMenuPrice = (restaurantId: string, itemId: string, newPrice: number) => {
    setRestaurantsList((prev) => {
      return prev.map((r) => {
        if (r.id === restaurantId) {
          return {
            ...r,
            menu: r.menu.map((item) => (item.id === itemId ? { ...item, price: newPrice } : item))
          };
        }
        return r;
      });
    });
    addNotification('Menu Rates Adjusted!', `Updated listing rates on server records to Rs. ${newPrice}.`);
  };

  // Sync Cart to LocalStorage
  useEffect(() => {
    localStorage.setItem('foodwala_cart', JSON.stringify(cartItems));
  }, [cartItems]);

  // Sync Active Order to LocalStorage
  useEffect(() => {
    if (placedOrder) {
      localStorage.setItem('foodwala_active_order', JSON.stringify(placedOrder));
    } else {
      localStorage.removeItem('foodwala_active_order');
    }
  }, [placedOrder]);

  // Sync Restaurant selection if items are empty to prevent locking
  useEffect(() => {
    if (cartItems.length === 0) {
      setAppliedPromo(null);
    }
  }, [cartItems]);

  // Helper Calculations
  const cartCount = cartItems.reduce((acc, ci) => acc + ci.quantity, 0);
  const subtotal = cartItems.reduce((acc, ci) => acc + ci.menuItem.price * ci.quantity, 0);

  const getDeliveryFee = () => {
    if (cartItems.length === 0 || deliveryMethod === 'pickup') return 0;
    if (activeRestaurant) return activeRestaurant.deliveryFee;
    // Fallback if multiple item origins
    return 100;
  };
  const deliveryFee = getDeliveryFee();

  const getDiscount = () => {
    if (!appliedPromo) return 0;
    if (appliedPromo.minSpend && subtotal < appliedPromo.minSpend) return 0;
    
    if (appliedPromo.discountType === 'fixed') {
      return appliedPromo.value;
    } else {
      return Math.round((subtotal * appliedPromo.value) / 100);
    }
  };
  const discount = getDiscount();
  const totalPayable = Math.max(0, subtotal + deliveryFee - discount);

  // Cart Management Functions
  const handleAddToCart = (item: MenuItem) => {
    const res = restaurantsList.find((r) => (r.menu || []).some((m) => m.id === item.id));
    if (!res) return;

    // Check if adding from a different restaurant than active restaurant
    if (activeRestaurant && activeRestaurant.id !== res.id && cartItems.length > 0) {
      // In a premium flow, we automatically adjust or clear, but to be helpful, let's clear and switch
      const confirmClear = window.confirm(
        `Your cart contains items from ${cartItems[0].restaurantName}. Would you like to clear your cart and order from ${res.name} instead?`
      );
      if (confirmClear) {
        setCartItems([
          {
            menuItem: item,
            quantity: 1,
            restaurantId: res.id,
            restaurantName: res.name,
          },
        ]);
        setActiveRestaurant(res);
      }
      return;
    }

    // Set active restaurant context if not already set
    if (!activeRestaurant) {
      setActiveRestaurant(res);
    }

    setCartItems((prev) => {
      const idx = prev.findIndex((ci) => ci.menuItem.id === item.id);
      if (idx > -1) {
        const updated = [...prev];
        updated[idx].quantity += 1;
        return updated;
      } else {
        return [
          ...prev,
          {
            menuItem: item,
            quantity: 1,
            restaurantId: res.id,
            restaurantName: res.name,
          },
        ];
      }
    });
  };

  const handleRemoveFromCart = (item: MenuItem) => {
    setCartItems((prev) => {
      const idx = prev.findIndex((ci) => ci.menuItem.id === item.id);
      if (idx === -1) return prev;

      const updated = [...prev];
      if (updated[idx].quantity > 1) {
        updated[idx].quantity -= 1;
        return updated;
      } else {
        // Remove item entirely
        const filtered = updated.filter((ci) => ci.menuItem.id !== item.id);
        if (filtered.length === 0) {
          // Reset restaurant context if cart becomes empty
          setActiveRestaurant(null);
        }
        return filtered;
      }
    });
  };

  const handleDeleteFromCart = (item: MenuItem) => {
    setCartItems((prev) => {
      const filtered = prev.filter((ci) => ci.menuItem.id !== item.id);
      if (filtered.length === 0) {
        setActiveRestaurant(null);
      }
      return filtered;
    });
  };

  const handleAiAddToCart = (itemId: string, quantity: number = 1) => {
    let foundItem: MenuItem | null = null;
    for (const r of restaurantsList) {
      const match = (r.menu || []).find((m) => m.id === itemId);
      if (match) {
        foundItem = match;
        break;
      }
    }
    if (foundItem) {
      for (let i = 0; i < quantity; i++) {
        handleAddToCart(foundItem);
      }
    }
  };

  const handleAiRegisterComplaint = (notes: string) => {
    const newComplaint = {
      name: 'AI Support Ticket User',
      email: 'complaints@foodwala.com',
      message: notes,
      rating: 1
    };
    setFeedbackList((prev) => {
      const updated = [...prev, newComplaint];
      localStorage.setItem('foodwala_feedback_list', JSON.stringify(updated));
      return updated;
    });
  };

  const handleApplyPromo = (code: string) => {
    // Find matching promo code config from preset data
    const presetPromo = [
      { code: 'FOODWALA50', discountType: 'fixed', value: 150, minSpend: 1000 },
      { code: 'FIRSTEAT', discountType: 'percentage', value: 20, minSpend: 0 },
      { code: 'FREEFRIES', discountType: 'fixed', value: 250, minSpend: 800 }
    ].find(p => p.code === code);

    if (presetPromo) {
      setAppliedPromo(presetPromo as PromoCode);
      showToast('Promo code applied successfully!', 'success');
    } else {
      showToast('Invalid promo code. Try FOODWALA50!', 'error');
    }
  };

  const handleRemovePromo = () => {
    setAppliedPromo(null);
    showToast('Promo code removed.', 'info');
  };

  // Order Submission
  const createFinalOrder = (
    details: { name: string; phone: string; address: string },
    paymentType: string,
    verification?: { transactionId: string; amountPaid: number; screenshot?: string },
    initialStatus: 'received' | 'preparing' | 'delivery' | 'delivered' | 'payment_verification' | 'payment_rejected' | 'paid' = 'received'
  ) => {
    const newOrder: Order = {
      id: `FW-${Math.floor(100000 + Math.random() * 900000)}`,
      items: [...cartItems],
      subtotal,
      discount,
      deliveryFee,
      total: totalPayable,
      customerName: details.name,
      phone: details.phone,
      address: details.address,
      notes: chefNotes,
      status: initialStatus,
      date: new Date().toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      }),
      deliveryMethod,
      paymentMethod: paymentType,
      transactionId: verification?.transactionId,
      amountPaid: verification?.amountPaid,
      screenshot: verification?.screenshot
    };

    // Save order in history list
    setOrderHistory((prev) => {
      const updated = [newOrder, ...prev];
      localStorage.setItem('foodwala_order_history', JSON.stringify(updated));
      return updated;
    });

    // Save in unified order stream
    setOrdersList((prev) => {
      const updated = [newOrder, ...prev];
      localStorage.setItem('foodwala_orders_list', JSON.stringify(updated));
      return updated;
    });

    setPlacedOrder(newOrder);
    setCartItems([]);
    setChefNotes('');
    setAppliedPromo(null);
    setCheckoutModalOpen(false);
    setMobileCartOpen(false);

    // Dynamic notification trigger
    if (initialStatus === 'payment_verification') {
      addNotification('Payment Under Verification!', `Order ${newOrder.id} placed. Your payment is being verified by Admin.`);
      showToast('Order placed! Awaiting payment verification...', 'info');
    } else {
      addNotification('Order Placed Successfully!', `Your order ${newOrder.id} has been transmitted to ${newOrder.items[0]?.restaurantName || 'the kitchen'}.`);
      showToast('Order placed successfully! Tracking live status...', 'success');
    }
  };

  const handlePlaceOrder = (
    details: { name: string; phone: string; address: string },
    paymentMethod: 'cod' | 'jazzcash' | 'easypaisa' | 'wallet',
    verification?: { transactionId: string; amountPaid: number; screenshot?: string }
  ) => {
    if (paymentMethod === 'jazzcash' || paymentMethod === 'easypaisa') {
      const methodLabel = paymentMethod === 'jazzcash' ? 'JazzCash' : 'Easypaisa';
      createFinalOrder(details, methodLabel, verification, 'payment_verification');
    } else if (paymentMethod === 'wallet') {
      setPendingOrderDetails(details);
      handlePaymentSuccess('wallet', details);
    } else {
      createFinalOrder(details, 'Cash on Delivery', undefined, 'received');
    }
  };

  const onApproveWalletTx = (id: string) => {
    handleApproveWalletTx(id);
  };

  const onRejectWalletTx = (id: string) => {
    setWalletTransactions(prevTxs => prevTxs.map(t => t.id === id ? { ...t, status: 'rejected' } : t));
    showToast('Payment verification rejected.', 'error');
  };

  const handlePaymentSuccess = (paymentType: string, overrideDetails?: any) => {
    const details = overrideDetails || pendingOrderDetails;
    if (!details) return;

    if (paymentType === 'wallet') {
      const finalTotal = totalPayable;
      if (walletBalance < finalTotal) {
        showToast('والٹ میں بیلنس ناکافی ہے!', 'error');
        return;
      }

      // 1. Deduct principal order total
      const remainingBal = walletBalance - finalTotal;
      setWalletBalance(remainingBal);
      localStorage.setItem('foodwala_wallet_balance', remainingBal.toString());

      // 2. Log Payment transaction
      const payTx: WalletTransaction = {
        id: `WTX-${Math.floor(100000 + Math.random() * 900000)}`,
        type: 'payment',
        amount: finalTotal,
        channel: 'wallet_system',
        referenceId: `FW-${Math.floor(100000 + Math.random() * 900000)}`,
        timestamp: new Date().toLocaleString(),
        status: 'completed'
      };

      // 3. Award 2% Order Cashback!
      const orderCashback = parseFloat((finalTotal * 0.02).toFixed(2));
      const finalBalWithCashback = remainingBal + orderCashback;
      
      const cashbackTx: WalletTransaction = {
        id: `WTX-${Math.floor(100000 + Math.random() * 900000)}`,
        type: 'cashback',
        amount: orderCashback,
        channel: 'wallet_system',
        referenceId: payTx.id,
        timestamp: new Date().toLocaleString(),
        status: 'completed',
        notes: '2% FoodWala Order Cashback Benefit'
      };

      // Batch state update
      setWalletBalance(finalBalWithCashback);
      localStorage.setItem('foodwala_wallet_balance', finalBalWithCashback.toString());

      setWalletTransactions(prev => {
        const withTxs = [cashbackTx, payTx, ...prev];
        localStorage.setItem('foodwala_wallet_transactions', JSON.stringify(withTxs));
        return withTxs;
      });

      addNotification('Wallet Payment Successful!', `Paid Rs. ${finalTotal.toLocaleString()} successfully. Rs. ${orderCashback} cashback awarded!`);
      showToast(`Paid via Wallet! Rs. ${orderCashback} Cashback credited!`, 'success');
    }

    createFinalOrder(details, paymentType === 'wallet' ? 'FoodWala Wallet' : paymentType);
    setPendingOrderDetails(null);
  };

  // Wallet user deposit request creation
  const handleAddMoney = (
    amount: number,
    channel: 'easypaisa' | 'jazzcash' | 'cash_deposit',
    senderPhone: string,
    tid: string
  ) => {
    const newTx: WalletTransaction = {
      id: `WTX-${Math.floor(100000 + Math.random() * 900000)}`,
      type: 'deposit',
      amount,
      channel,
      referenceId: tid,
      timestamp: new Date().toLocaleString(),
      status: 'pending',
      senderPhone
    };

    setWalletTransactions((prev) => [newTx, ...prev]);
    addNotification('Deposit Request Lodged', `Your deposit of Rs. ${amount.toLocaleString()} has been queued for Admin verification.`);
    showToast('ڈپازٹ کی درخواست تصدیق کے لیے بھیج دی گئی ہے!', 'info');
  };

  // Wallet user withdrawal request creation
  const handleWithdraw = (
    amount: number,
    channel: 'easypaisa' | 'jazzcash',
    accountName: string,
    accountNo: string
  ) => {
    if (walletBalance < amount) {
      showToast('والٹ میں بیلنس ناکافی ہے!', 'error');
      return;
    }

    // Hold amount in escrow upfront upon withdrawal request
    const escrowBalance = walletBalance - amount;
    setWalletBalance(escrowBalance);
    localStorage.setItem('foodwala_wallet_balance', escrowBalance.toString());

    const newTx: WalletTransaction = {
      id: `WTX-${Math.floor(100000 + Math.random() * 900000)}`,
      type: 'withdrawal',
      amount,
      channel,
      timestamp: new Date().toLocaleString(),
      status: 'pending',
      accountName,
      accountNo
    };

    setWalletTransactions((prev) => [newTx, ...prev]);
    addNotification('Withdrawal Requested', `Withdrawal of Rs. ${amount.toLocaleString()} is queued for Admin approval.`);
    showToast('رقم نکلوانے کی درخواست جمع ہو گئی ہے!', 'info');
  };

  // Admin approval of deposit / withdrawal
  const handleApproveWalletTx = (id: string) => {
    let transactionType = '';
    let transactionAmount = 0;

    setWalletTransactions((prev) => {
      const updated = prev.map((tx) => {
        if (tx.id === id) {
          transactionType = tx.type;
          transactionAmount = tx.amount;

          if (tx.type === 'deposit') {
            let creditedAmount = tx.amount;
            let bonusNotes = '';

            // Deposit Promotion: 5% match reward on deposits of Rs. 1000 or more!
            if (tx.amount >= 1000) {
              const cashbackBonus = tx.amount * 0.05;
              creditedAmount += cashbackBonus;
              bonusNotes = `Includes Rs. ${cashbackBonus} (5%) Welcome Promo Match!`;

              // Log cashback bonus transaction record
              setTimeout(() => {
                const cashbackTx: WalletTransaction = {
                  id: `WTX-${Math.floor(100000 + Math.random() * 900000)}`,
                  type: 'cashback',
                  amount: cashbackBonus,
                  channel: 'wallet_system',
                  referenceId: tx.id,
                  timestamp: new Date().toLocaleString(),
                  status: 'completed',
                  notes: '5% Match Deposit Loyalty Reward'
                };
                setWalletTransactions(currentTxs => [cashbackTx, ...currentTxs]);
              }, 100);
            }

            setWalletBalance((curr) => {
              const nextBal = curr + creditedAmount;
              localStorage.setItem('foodwala_wallet_balance', nextBal.toString());
              return nextBal;
            });

            addNotification('Deposit Confirmed!', `Rs. ${creditedAmount.toLocaleString()} has been credited to your FoodWala Wallet.`);
          } else if (tx.type === 'withdrawal') {
            // Withdrawal approved (already held in escrow), so just notify completion
            addNotification('Payout Disbursed!', `Your withdrawal of Rs. ${tx.amount.toLocaleString()} was approved and sent.`);
          }

          return { ...tx, status: 'completed' as const };
        }
        return tx;
      });

      localStorage.setItem('foodwala_wallet_transactions', JSON.stringify(updated));
      return updated;
    });

    showToast(`Transaction approved successfully!`, 'success');
  };

  // Admin denial of transaction requests
  const handleRejectWalletTx = (id: string) => {
    setWalletTransactions((prev) => {
      const updated = prev.map((tx) => {
        if (tx.id === id) {
          if (tx.type === 'withdrawal') {
            // Refund escrowed withdrawal balance back to the user
            setWalletBalance((curr) => {
              const nextBal = curr + tx.amount;
              localStorage.setItem('foodwala_wallet_balance', nextBal.toString());
              return nextBal;
            });
            addNotification('Payout Denied', `Withdrawal of Rs. ${tx.amount.toLocaleString()} was denied. Funds refunded to wallet.`);
          } else {
            addNotification('Deposit Declined', `Deposit verification failed. Please check your TID or call Helpline.`);
          }
          return { ...tx, status: 'failed' as const };
        }
        return tx;
      });

      localStorage.setItem('foodwala_wallet_transactions', JSON.stringify(updated));
      return updated;
    });

    showToast(`Transaction declined.`, 'error');
  };

  const handleClearHistory = () => {
    setOrderHistory([]);
    localStorage.removeItem('foodwala_order_history');
    showToast('Order history cleared successfully!', 'success');
  };

  const handleRateOrder = (orderId: string, rating: number, ratingNote: string) => {
    setOrderHistory(prev => {
      const updated = prev.map(o => o.id === orderId ? { ...o, rating, ratingNote } : o);
      localStorage.setItem('foodwala_order_history', JSON.stringify(updated));
      return updated;
    });
    setOrdersList(prev => {
      const updated = prev.map(o => o.id === orderId ? { ...o, rating, ratingNote } : o);
      localStorage.setItem('foodwala_orders_list', JSON.stringify(updated));
      return updated;
    });
    showToast('Rating submitted successfully!', 'success');
  };

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    setSubscriptionError('');
    const emailVal = subscriberEmail.trim();

    if (!emailVal) {
      setSubscriptionError(lang === 'en' ? 'Please enter your email.' : 'براہ کرم اپنا ای میل درج کریں۔');
      setShouldShake(true);
      setTimeout(() => setShouldShake(false), 500);
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(emailVal)) {
      setSubscriptionError(lang === 'en' ? 'Please enter a valid email address.' : 'براہ کرم ایک درست ای میل ایڈریس درج کریں۔');
      setShouldShake(true);
      setTimeout(() => setShouldShake(false), 500);
      return;
    }

    setIsSubscribed(true);
    setToast({
      message: lang === 'en'
        ? 'Subscribed successfully! Grab 200 Rs. discount with code WELCOME200 on your first order.'
        : 'کامیابی کے ساتھ سبسکرائب ہو گیا! اپنے پہلے آرڈر پر 200 روپے کی رعایت کے لیے WELCOME200 کوڈ استعمال کریں۔',
      type: 'newsletter',
      email: emailVal
    });
    setSubscriberEmail('');
    setTimeout(() => setIsSubscribed(false), 5000);
  };

  const handleReorder = (items: CartItem[]) => {
    if (items.length === 0) return;

    // Set the active restaurant to context
    const rId = items[0].restaurantId;
    const matchedRestaurant = restaurantsList.find((r) => r.id === rId);
    if (matchedRestaurant) {
      setActiveRestaurant(matchedRestaurant);
    }

    setCartItems(items);
    setHistoryModalOpen(false);
    setMobileCartOpen(true);
    showToast('Past items re-added to your cart!', 'success');
  };

  const handleSelectRestaurantByName = (name: string) => {
    const matched = restaurantsList.find((r) => r.name.toLowerCase().includes(name.toLowerCase()));
    if (matched) {
      setActiveRestaurant(matched);
      window.scrollTo({ top: 0, behavior: 'smooth' });
      showToast(`Welcome to ${matched.name}!`, 'info');
    }
  };

  // Filter restaurants based on category pill and search bar input
  const filteredRestaurants = restaurantsList.filter((r) => {
    // Category filter logic
    if (activeCategory !== 'All') {
      const matchesCategory = r.category.toLowerCase() === activeCategory.toLowerCase() ||
                              r.tags.some(t => t.toLowerCase() === activeCategory.toLowerCase());
      if (!matchesCategory) return false;
    }

    // Search query filter logic
    if (searchQuery.trim() !== '') {
      const query = searchQuery.toLowerCase();
      const matchesRestaurantName = r.name.toLowerCase().includes(query);
      const matchesTags = r.tags.some((t) => t.toLowerCase().includes(query));
      const matchesDishes = (r.menu || []).some((item) =>
        item.name.toLowerCase().includes(query) || item.description.toLowerCase().includes(query)
      );
      return matchesRestaurantName || matchesTags || matchesDishes;
    }

    return true;
  });

  return (
    <div className="min-h-screen bg-gray-50/50 text-gray-800 font-sans flex flex-col">
      {/* AuthRolePortal Session banner at the very top */}
      <AuthRolePortal
        currentRole={activeRole}
        onRoleChange={(role, payload) => {
          setActiveRole(role);
          localStorage.setItem('foodwala_session_role', role);
          if (role === 'restaurant' && payload) {
            setMerchantRestId(payload.restaurantId);
            setMerchantRestName(payload.restaurantName);
          } else if (role === 'rider' && payload) {
            setRiderSessionName(payload.name);
          }
        }}
        restaurants={restaurantsList}
        usersList={usersList}
      />

      {/* Header element */}
      {activeRole === 'customer' ? (
        <Header
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          activeCategory={activeCategory}
          setActiveCategory={setActiveCategory}
          cartCount={cartCount}
          onCartClick={() => setMobileCartOpen(true)}
          onHistoryClick={() => setHistoryModalOpen(true)}
          selectedAddress={placedOrder ? placedOrder.address : customerAddress}
          onUpdateAddress={setCustomerAddress}
          walletBalance={walletBalance}
          onWalletClick={() => setWalletModalOpen(true)}
          theme={theme}
          onToggleTheme={toggleTheme}
        />
      ) : (
        /* Dedicated Portal Header Nav bar for merchant/rider/admin */
        <header className="sticky top-0 z-40 bg-gray-900 text-white border-b border-gray-850 shadow-md">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="bg-red-500 text-white p-2 rounded-xl shadow-md flex items-center justify-center">
                <ChefHat className="h-5 w-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="font-display font-bold text-base tracking-tight text-white">
                    Food<span className="text-red-500">Wala</span> Portal
                  </h1>
                  <span className="bg-red-500/10 text-red-400 text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider">
                    {activeRole} PANEL
                  </span>
                </div>
                <p className="text-[10px] text-gray-400 font-semibold">
                  {activeRole === 'restaurant' && `Acting as Merchant: ${merchantRestName}`}
                  {activeRole === 'rider' && `Logistics Dispatcher: ${riderSessionName}`}
                  {activeRole === 'admin' && 'Enterprise System Administration'}
                </p>
              </div>
            </div>

            <button
              onClick={() => {
                setActiveRole('customer');
                localStorage.setItem('foodwala_session_role', 'customer');
              }}
              className="text-xs bg-gray-800 hover:bg-gray-750 text-gray-200 font-bold px-3.5 py-1.5 rounded-xl border border-gray-700 transition-all cursor-pointer"
            >
              Exit to Customer Store
            </button>
          </div>
        </header>
      )}

      {/* Main Content Dashboard */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <AnimatePresence mode="wait">
          {activeRole === 'restaurant' ? (
            <motion.div key="restaurant-portal" initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -15 }}>
              <RestaurantPortal
                restaurantId={merchantRestId}
                restaurantName={merchantRestName}
                orders={ordersList}
                restaurants={restaurantsList}
                onUpdateOrderStatus={handleUpdateOrderStatus}
                onUpdateMenuPrice={handleUpdateMenuPrice}
                onUpdateState={(table, data) => {
                  if (table === 'restaurants') setRestaurantsList(data as Restaurant[]);
                }}
                lang={lang}
              />
            </motion.div>
          ) : activeRole === 'rider' ? (
            <motion.div key="rider-portal" initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -15 }}>
              <RiderPortal
                riderName={riderSessionName}
                orders={ordersList}
                onUpdateOrderStatus={handleUpdateOrderStatus}
                riders={ridersList}
              />
            </motion.div>
          ) : activeRole === 'admin' ? (
            <motion.div key="admin-portal" initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -15 }}>
              <AdminPortal
                orders={ordersList}
                walletTransactions={walletTransactions}
                admins={adminsList}
                restaurants={restaurantsList}
                feedback={feedbackList}
                onApproveWalletTx={onApproveWalletTx}
                onRejectWalletTx={onRejectWalletTx}
                onUpdateState={(table, data) => {
                  if (table === 'users') setUsersList(data);
                  else if (table === 'restaurants') setRestaurantsList(data);
                  else if (table === 'orders') {
                    // Detect status transitions for notifications
                    data.forEach((newOrder) => {
                      const oldOrder = ordersList.find(o => o.id === newOrder.id);
                      if (oldOrder && oldOrder.status !== newOrder.status) {
                        if (newOrder.status === 'paid') {
                          addNotification('Payment Verified!', 'Your payment has been verified successfully. Your order is now being prepared.');
                          showToast('Payment verified by Admin!', 'success');
                        } else if (newOrder.status === 'payment_rejected') {
                          addNotification('Payment Verification Failed!', 'Your payment verification has failed. Please check your transaction details.');
                          showToast('Payment rejected by Admin!', 'error');
                        }
                      }
                    });
                    setOrdersList(data);
                    setOrderHistory(data);
                    const activeOrder = data.find(o => o.status !== 'delivered');
                    if (activeOrder) setPlacedOrder(activeOrder);
                  }
                  else if (table === 'admins') {
                    setAdminsList(data);
                    localStorage.setItem('foodwala_admins_list', JSON.stringify(data));
                  }
                  else if (table === 'riders') setRidersList(data);
                  else if (table === 'feedback') setFeedbackList(data);
                  else if (table === 'wallet_balance') {
                    setWalletBalance(data[0]);
                    localStorage.setItem('foodwala_wallet_balance', data[0].toString());
                  }
                  else if (table === 'wallet_transactions') {
                    setWalletTransactions(data);
                    localStorage.setItem('foodwala_wallet_transactions', JSON.stringify(data));
                  }
                }}
                initialDbData={{
                  users: usersList,
                  restaurants: restaurantsList,
                  menu_items: restaurantsList.flatMap(r => (r.menu || []).map(m => ({ ...m, restaurant_id: r.id }))),
                  orders: ordersList,
                  riders: ridersList,
                  feedback: feedbackList
                }}
              />
            </motion.div>
          ) : placedOrder ? (
            /* If order is placed, show live order tracker */
            <motion.div
              key="tracking-view"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
            >
              <OrderTracking
                order={placedOrder}
                onClose={() => setPlacedOrder(null)}
              />
            </motion.div>
          ) : (
            /* Main Dashboard split layout */
            <div key="dashboard-view" className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
              {/* Left/Middle Column (Restaurants or Menu list) */}
              <div className="lg:col-span-8 space-y-6">
                {activeRestaurant ? (
                  /* Single Restaurant Page */
                  <motion.div
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                  >
                    <MenuSection
                      restaurant={activeRestaurant}
                      cartItems={cartItems}
                      onAddToCart={handleAddToCart}
                      onRemoveFromCart={handleRemoveFromCart}
                      onBack={() => setActiveRestaurant(null)}
                    />
                  </motion.div>
                ) : (
                  /* Home Grid Layout - Restaurant Catalog */
                  <div className="space-y-6">
                    {/* Interactive Campaign Banner */}
                    <div className="relative overflow-hidden rounded-3xl bg-red-500 text-white p-6 md:p-8 shadow-xl shadow-red-500/15 flex flex-col md:flex-row justify-between items-center gap-6">
                      <div className="space-y-2 text-center md:text-left">
                        <span className="inline-flex items-center gap-1 bg-white/20 text-white font-bold text-xs px-3 py-1 rounded-full backdrop-blur-md">
                          <Award className="h-3.5 w-3.5" /> Hyderabad, Sindh's Choice
                        </span>
                        <h2 className="font-display font-extrabold text-2xl md:text-3.5xl tracking-tight leading-none pt-1">
                          Craving Fried Chicken or Biryani?
                        </h2>
                        <p className="text-xs md:text-sm text-red-50 font-medium max-w-md">
                          Order from Pakistan's premium eateries with active countdown order tracking & hyper-fast doorstep delivery.
                        </p>
                      </div>
                      <div className="bg-white/10 rounded-2xl p-4 border border-white/15 backdrop-blur-md text-center shrink-0">
                        <p className="text-[10px] uppercase font-bold tracking-wider text-red-100">Use Coupon Code</p>
                        <p className="font-mono text-xl font-black text-yellow-300 mt-0.5">FOODWALA50</p>
                        <p className="text-[10px] text-white mt-1 font-semibold">Get Rs. 150 off on orders above 1000!</p>
                      </div>
                    </div>

                    {/* Trending Discovery Insights Chart */}
                    <TrendingDiscovery
                      onSelectRestaurant={(r) => {
                        setActiveRestaurant(r);
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }}
                      onAddToCart={handleAddToCart}
                      orderHistory={orderHistory}
                    />

                    <TopRidersSection riders={ridersList} />

                    {/* Section Header */}
                    <div className="flex items-center justify-between">
                      <div>
                        <h2 className="font-display font-bold text-xl text-gray-900 flex items-center gap-2">
                          <UtensilsCrossed className="h-5 w-5 text-red-500" />
                          {activeCategory === 'All' ? 'Curated Outlets' : `${activeCategory} Outlets`}
                        </h2>
                        <p className="text-xs text-gray-400 font-semibold mt-1">
                          Showing {filteredRestaurants.length} premium food spots near you
                        </p>
                      </div>
                      <div className="flex items-center gap-1 text-xs font-bold text-red-500 bg-red-50 px-3 py-1.5 rounded-xl">
                        <TrendingUp className="h-4 w-4" /> Top rated
                      </div>
                    </div>

                    {/* Grid of Restaurants */}
                    {filteredRestaurants.length > 0 ? (
                      <motion.div
                        layout
                        className="grid grid-cols-1 md:grid-cols-2 gap-6"
                      >
                        {filteredRestaurants.map((restaurant) => (
                          <RestaurantCard
                            key={restaurant.id}
                            restaurant={restaurant}
                            onSelect={(r) => {
                              setActiveRestaurant(r);
                              window.scrollTo({ top: 0, behavior: 'smooth' });
                            }}
                          />
                        ))}
                      </motion.div>
                    ) : (
                      /* No Results State */
                      <div className="bg-white rounded-3xl border border-gray-100 p-12 text-center shadow-xs">
                        <p className="text-4xl">🔍</p>
                        <h3 className="font-display font-bold text-gray-800 text-lg mt-3">No matching food found</h3>
                        <p className="text-xs text-gray-400 mt-1 max-w-xs mx-auto">
                          We couldn't find any results matching "{searchQuery}". Try selecting other filters or check your spelling.
                        </p>
                        <button
                          onClick={() => {
                            setSearchQuery('');
                            setActiveCategory('All');
                          }}
                          className="mt-4 px-4 py-2 bg-red-500 text-white font-bold text-xs rounded-xl hover:bg-red-600 transition-all active:scale-95"
                        >
                          Clear Filters
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Right Column - Desktop persistent shopping basket */}
              <div className="hidden lg:block lg:col-span-4 sticky top-28 h-[calc(100vh-140px)]">
                <CartPanel
                  cartItems={cartItems}
                  deliveryMethod={deliveryMethod}
                  setDeliveryMethod={setDeliveryMethod}
                  onAddToCart={handleAddToCart}
                  onRemoveFromCart={handleRemoveFromCart}
                  onDeleteFromCart={handleDeleteFromCart}
                  appliedPromo={appliedPromo}
                  onApplyPromo={handleApplyPromo}
                  onRemovePromo={handleRemovePromo}
                  chefNotes={chefNotes}
                  setChefNotes={setChefNotes}
                  onCheckout={() => setCheckoutModalOpen(true)}
                  activeRestaurant={activeRestaurant}
                />
              </div>
            </div>
          )}
        </AnimatePresence>
      </main>

      {/* Mobile Cart Slider Drawer Modal */}
      <AnimatePresence>
        {mobileCartOpen && (
          <div className="fixed inset-0 z-50 lg:hidden flex justify-end">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setMobileCartOpen(false)}
              className="absolute inset-0 bg-gray-900/40 backdrop-blur-xs"
            />
            {/* Drawer Body */}
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="relative w-full max-w-sm bg-white h-full shadow-2xl flex flex-col z-10"
            >
              {/* Close Handle button */}
              <button
                onClick={() => setMobileCartOpen(false)}
                className="absolute top-4 left-[-48px] bg-white text-gray-700 p-2.5 rounded-l-xl shadow-lg hover:text-red-500 transition-all active:scale-95 cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>
              
              <div className="flex-1 h-full overflow-hidden">
                <CartPanel
                  cartItems={cartItems}
                  deliveryMethod={deliveryMethod}
                  setDeliveryMethod={setDeliveryMethod}
                  onAddToCart={handleAddToCart}
                  onRemoveFromCart={handleRemoveFromCart}
                  onDeleteFromCart={handleDeleteFromCart}
                  appliedPromo={appliedPromo}
                  onApplyPromo={handleApplyPromo}
                  onRemovePromo={handleRemovePromo}
                  chefNotes={chefNotes}
                  setChefNotes={setChefNotes}
                  onCheckout={() => {
                    setCheckoutModalOpen(true);
                    setMobileCartOpen(false);
                  }}
                  activeRestaurant={activeRestaurant}
                />
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Checkout Modal Form */}
      <CheckoutModal
        isOpen={checkoutModalOpen}
        onClose={() => setCheckoutModalOpen(false)}
        onSubmit={handlePlaceOrder}
        total={totalPayable}
        deliveryMethod={deliveryMethod}
        walletBalance={walletBalance}
        onOpenWallet={() => {
          setCheckoutModalOpen(false);
          setWalletModalOpen(true);
        }}
      />

      {/* Wallet Dashboard Modal Overlay */}
      <WalletDashboardModal
        isOpen={walletModalOpen}
        onClose={() => setWalletModalOpen(false)}
        balance={walletBalance}
        transactions={walletTransactions}
        onAddMoney={handleAddMoney}
        onWithdraw={handleWithdraw}
      />

      {/* Info Modals */}
      {activeInfoModal && <InfoModal type={activeInfoModal} onClose={() => setActiveInfoModal(null)} />}

      {/* Back to Top */}
      <BackToTop isVisible={showBackToTop} onClick={scrollToTop} />

      {/* Payment Gateway Modal */}
      {paymentGatewayOpen && (
        <PaymentGateway
          isOpen={paymentGatewayOpen}
          onClose={() => {
            setPaymentGatewayOpen(false);
            setPendingOrderDetails(null);
          }}
          onSuccess={(type) => {
            handlePaymentSuccess(type);
            setPaymentGatewayOpen(false);
          }}
          total={totalPayable}
        />
      )}

      {/* Push Notification Banner Overlay */}
      <div className="fixed top-20 right-6 z-50 flex flex-col gap-3 max-w-sm pointer-events-none">
        <AnimatePresence>
          {notifications.map((notif) => (
            <motion.div
              key={notif.id}
              initial={{ opacity: 0, x: 100, y: -20, scale: 0.9 }}
              animate={{ opacity: 1, x: 0, y: 0, scale: 1 }}
              exit={{ opacity: 0, x: 100, scale: 0.9 }}
              transition={{ type: 'spring', damping: 20, stiffness: 220 }}
              className="pointer-events-auto bg-gray-900/95 backdrop-blur-md text-white px-4 py-3 rounded-2xl shadow-2xl border border-gray-800 flex gap-3 items-start w-80 relative overflow-hidden"
            >
              {/* Colored light bar indicator */}
              <div className="absolute top-0 bottom-0 left-0 w-1 bg-red-500" />
              <div className="bg-red-500/10 p-2 rounded-xl text-red-400 shrink-0 animate-pulse">
                <Bell className="h-4 w-4" />
              </div>
              <div className="flex-1 space-y-0.5">
                <div className="flex justify-between items-center">
                  <h4 className="font-display font-bold text-xs tracking-tight text-white">{notif.title}</h4>
                  <span className="text-[9px] text-gray-500 font-bold">{notif.timestamp}</span>
                </div>
                <p className="text-[11px] text-gray-300 font-medium leading-relaxed">
                  {notif.message}
                </p>
              </div>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setNotifications((prev) => prev.filter((n) => n.id !== notif.id));
                }}
                className="text-gray-550 hover:text-white p-0.5 transition-all cursor-pointer"
              >
                <X className="h-3 w-3" />
              </button>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Order History Modal */}
      <AnimatePresence>
        {historyModalOpen && (
          <OrderHistoryModal
            isOpen={historyModalOpen}
            onClose={() => setHistoryModalOpen(false)}
            orderHistory={orderHistory}
            onClearHistory={handleClearHistory}
            onReorder={handleReorder}
            onRateOrder={handleRateOrder}
          />
        )}
      </AnimatePresence>

      {/* Toast Notification */}
      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.9 }}
            className={`fixed bottom-6 right-6 z-50 flex flex-col gap-2 p-4 rounded-2xl shadow-2xl border max-w-sm ${
              toast.type === 'newsletter'
                ? 'bg-gradient-to-r from-slate-900 to-rose-950 text-white border-rose-900/40'
                : toast.type === 'success'
                ? 'bg-emerald-50 text-emerald-800 border-emerald-100 flex-row items-center gap-2.5'
                : toast.type === 'error'
                ? 'bg-red-50 text-red-800 border-red-100 flex-row items-center gap-2.5'
                : 'bg-blue-50 text-blue-800 border-blue-100 flex-row items-center gap-2.5'
            }`}
          >
            {toast.type === 'newsletter' ? (
              <div className="space-y-2">
                <div className="flex items-center gap-2 border-b border-white/10 pb-2">
                  <span className="text-base animate-bounce">📬</span>
                  <div>
                    <h5 className="font-display font-black text-xs text-yellow-300 uppercase tracking-wider">
                      {lang === 'en' ? 'Welcome to the FoodWala Family!' : 'فوڈ والا فیملی میں خوش آمدید!'}
                    </h5>
                    {toast.email && (
                      <p className="text-[10px] text-gray-300 font-mono leading-none mt-0.5">{toast.email}</p>
                    )}
                  </div>
                </div>
                <p className="text-[11px] font-semibold text-rose-100 leading-relaxed">
                  {toast.message}
                </p>
                <div className="bg-white/10 rounded-xl p-2 flex items-center justify-between gap-2 border border-white/10">
                  <div className="space-y-0.5">
                    <p className="text-[9px] uppercase font-bold text-gray-300 tracking-wider">
                      {lang === 'en' ? 'First Order Promo Code' : 'پہلا آرڈر پرومو کوڈ'}
                    </p>
                    <p className="text-xs font-mono font-black text-white">WELCOME200</p>
                  </div>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText('WELCOME200');
                      showToast(lang === 'en' ? 'Copied code WELCOME200!' : 'کوڈ کاپی ہو گیا!', 'success');
                    }}
                    className="bg-red-500 hover:bg-red-600 text-white text-[10px] font-bold px-2.5 py-1 rounded-lg cursor-pointer transition-colors"
                  >
                    {lang === 'en' ? 'Copy Code' : 'کوڈ کاپی کریں'}
                  </button>
                </div>
              </div>
            ) : (
              <>
                <span className="text-sm">
                  {toast.type === 'success' ? '✨' : toast.type === 'error' ? '❌' : 'ℹ️'}
                </span>
                <span>{toast.message}</span>
              </>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* AI Customer Chatbot Overlay */}
      {activeRole === 'customer' && (
        <AIChatBot
          cart={cartItems}
          restaurants={restaurantsList}
          activeOrder={placedOrder}
          onAddToCart={handleAiAddToCart}
          onRegisterComplaint={handleAiRegisterComplaint}
          showToast={showToast}
        />
      )}

      {/* Elegant minimalist footer */}
      {/* Footer */}
      <footer id="foodwala-footer" className="bg-gray-900 text-gray-400 py-12 border-t border-gray-800 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Column 1: Brand */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <ChefHat className="h-6 w-6 text-red-500" />
              <span className="font-display font-bold text-lg text-white">{t('brand')}</span>
            </div>
            <p className="text-sm">Bringing the best of local flavors to your doorstep with speed, hygiene, and care. Your favorite meals, just a tap away.</p>
          </div>

          {/* Column 2: Sitemap */}
          <div className="space-y-4">
            <h4 className="font-display font-bold text-white">Navigate</h4>
            <nav className="flex flex-col gap-2 text-sm">
              <button className="hover:text-white transition-colors text-left" onClick={() => setActiveInfoModal('about')}>About Us</button>
              <button className="hover:text-white transition-colors text-left" onClick={() => setActiveInfoModal('privacy')}>Privacy Policy</button>
              <button className="hover:text-white transition-colors text-left" onClick={() => setActiveInfoModal('contact')}>Contact Support</button>
              <button className="hover:text-white transition-colors text-left" onClick={() => setActiveInfoModal('careers')}>Careers</button>
            </nav>
          </div>

          {/* Column 3: Social & Contact */}
          <div className="space-y-4">
            <h4 className="font-display font-bold text-white">Connect</h4>
            <div className="flex items-center gap-4">
              <a href="#" className="relative group text-gray-400 hover:text-white transition-colors">
                <Instagram className="h-5 w-5" />
                <span className="absolute -top-10 left-1/2 -translate-x-1/2 bg-gray-800 text-white text-[10px] px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap">Instagram</span>
              </a>
              <a href="#" className="relative group text-gray-400 hover:text-white transition-colors">
                <Facebook className="h-5 w-5" />
                <span className="absolute -top-10 left-1/2 -translate-x-1/2 bg-gray-800 text-white text-[10px] px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap">Facebook</span>
              </a>
              <a href="#" className="relative group text-gray-400 hover:text-white transition-colors">
                <Music className="h-5 w-5" />
                <span className="absolute -top-10 left-1/2 -translate-x-1/2 bg-gray-800 text-white text-[10px] px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap">TikTok</span>
              </a>
            </div>
            <p className="text-sm">support@foodwala.com</p>
          </div>

          {/* Column 4: Language & Newsletter */}
          <div className="space-y-4">
            <h4 className="font-display font-bold text-white">Preferences</h4>
            <select
              value={lang}
              onChange={(e) => setLang(e.target.value as 'en' | 'ur')}
              className="bg-gray-800 text-white px-3 py-2 rounded-xl text-sm w-full focus:outline-none"
            >
              <option value="en">English</option>
              <option value="ur">Urdu</option>
            </select>
            <form onSubmit={handleSubscribe} className="flex flex-col gap-2" noValidate>
              <motion.input
                type="email"
                value={subscriberEmail}
                onChange={(e) => {
                  setSubscriberEmail(e.target.value);
                  if (subscriptionError) setSubscriptionError('');
                }}
                placeholder={t('placeholder')}
                animate={shouldShake ? { x: [-10, 10, -10, 10, -5, 5, 0] } : { x: 0 }}
                transition={{ duration: 0.4, ease: "easeInOut" }}
                className={`bg-gray-800 text-white px-4 py-2 rounded-xl text-sm w-full focus:outline-none focus:ring-1 ${
                  subscriptionError ? 'focus:ring-red-500 border border-red-500' : 'focus:ring-red-500'
                }`}
              />
              {subscriptionError && (
                <p className="text-red-400 text-xs font-semibold px-1" dir="auto">
                  {subscriptionError}
                </p>
              )}
              <motion.button
                key={isSubscribed ? 'subscribed' : 'subscribe'}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.2 }}
                type="submit"
                className={`px-4 py-2 rounded-xl text-sm font-bold transition-all ${isSubscribed ? 'bg-green-600' : 'bg-red-600 hover:bg-red-700'} text-white`}
              >
                {isSubscribed ? t('subscribed') : t('subscribe')}
              </motion.button>
            </form>
          </div>
        </div>

        {/* Copyright */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12 pt-8 border-t border-gray-800 text-center text-sm">
          <p>&copy; {new Date().getFullYear()} {t('brand')}. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
