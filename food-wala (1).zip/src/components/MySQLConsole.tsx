import React, { useState, useEffect } from 'react';
import { Database, Terminal, Play, RotateCcw, AlertCircle, CheckCircle2, ChevronRight, Table, HelpCircle } from 'lucide-react';
import { motion } from 'motion/react';

interface MySQLConsoleProps {
  initialData: {
    users: any[];
    restaurants: any[];
    menu_items: any[];
    orders: any[];
    riders: any[];
    feedback: any[];
  };
  onUpdateState: (tableName: string, newData: any[]) => void;
}

export default function MySQLConsole({ initialData, onUpdateState }: MySQLConsoleProps) {
  const [query, setQuery] = useState('SELECT * FROM restaurants;');
  const [dbState, setDbState] = useState(initialData);
  const [queryResult, setQueryResult] = useState<{
    columns: string[];
    rows: any[];
    message: string;
    type: 'success' | 'error';
    timeMs: number;
  } | null>(null);

  useEffect(() => {
    setDbState(initialData);
  }, [initialData]);

  // Predefined queries for easy discovery
  const presetQueries = [
    { label: 'View All Outlets', sql: 'SELECT name, category, rating FROM restaurants;' },
    { label: 'Pending Delivery Orders', sql: "SELECT id, customer_name, total, status FROM orders WHERE status = 'delivery';" },
    { label: 'List Active Riders', sql: "SELECT name, phone, status FROM riders;" },
    { label: 'High Price Menu Items', sql: 'SELECT name, price FROM menu_items WHERE price > 600;' },
    { label: 'Reset Database Tables', sql: 'TRUNCATE orders;' }
  ];

  const handleRunQuery = () => {
    const start = performance.now();
    const cleanSql = query.trim().replace(/;$/, '').replace(/\s+/g, ' ');
    const lowerSql = cleanSql.toLowerCase();

    // Helper to log errors
    const logError = (msg: string) => {
      setQueryResult({
        columns: [],
        rows: [],
        message: `Error: ${msg}`,
        type: 'error',
        timeMs: Math.round(performance.now() - start)
      });
    };

    try {
      // 1. SELECT Query Handler
      if (lowerSql.startsWith('select')) {
        const fromIndex = lowerSql.indexOf('from');
        if (fromIndex === -1) return logError("Missing FROM keyword");

        // Parse columns
        const selectPart = cleanSql.substring(6, fromIndex).trim();
        let targetCols = selectPart.split(',').map(c => c.trim());

        // Parse Table name & Where clause
        const fromPart = cleanSql.substring(fromIndex + 4).trim();
        const whereIndex = fromPart.toLowerCase().indexOf('where');
        
        let tableName = '';
        let whereClause = '';
        
        if (whereIndex !== -1) {
          tableName = fromPart.substring(0, whereIndex).trim();
          whereClause = fromPart.substring(whereIndex + 5).trim();
        } else {
          tableName = fromPart.trim();
        }

        const validTables = ['users', 'restaurants', 'menu_items', 'orders', 'riders', 'feedback'];
        if (!validTables.includes(tableName.toLowerCase())) {
          return logError(`Table '${tableName}' does not exist in foodwala_db schema.`);
        }

        const actualTableName = tableName.toLowerCase() as keyof typeof dbState;
        let dataToFilter = [...dbState[actualTableName]];

        // Handle simple WHERE clause filtering (e.g. status = 'delivery' or price > 600)
        if (whereClause) {
          const matchEq = whereClause.match(/([a-zA-Z_0-9]+)\s*=\s*['"]?([^'"]+)['"]?/i);
          const matchGt = whereClause.match(/([a-zA-Z_0-9]+)\s*>\s*([0-9.]+)/i);
          const matchLt = whereClause.match(/([a-zA-Z_0-9]+)\s*<\s*([0-9.]+)/i);

          if (matchEq) {
            const [, col, val] = matchEq;
            dataToFilter = dataToFilter.filter(row => String(row[col] ?? '').toLowerCase() === val.toLowerCase());
          } else if (matchGt) {
            const [, col, val] = matchGt;
            dataToFilter = dataToFilter.filter(row => Number(row[col] ?? 0) > Number(val));
          } else if (matchLt) {
            const [, col, val] = matchLt;
            dataToFilter = dataToFilter.filter(row => Number(row[col] ?? 0) < Number(val));
          }
        }

        if (dataToFilter.length === 0) {
          setQueryResult({
            columns: targetCols.includes('*') ? (dataToFilter[0] ? Object.keys(dataToFilter[0]) : ['No Data']) : targetCols,
            rows: [],
            message: 'Query returned 0 rows successfully.',
            type: 'success',
            timeMs: Math.round(performance.now() - start)
          });
          return;
        }

        // Project columns
        let finalColumns: string[] = [];
        if (targetCols.includes('*')) {
          finalColumns = Object.keys(dataToFilter[0]);
        } else {
          finalColumns = targetCols;
        }

        const projectedRows = dataToFilter.map(row => {
          const projected: any = {};
          finalColumns.forEach(col => {
            projected[col] = row[col] ?? 'NULL';
          });
          return projected;
        });

        setQueryResult({
          columns: finalColumns,
          rows: projectedRows,
          message: `Query OK, ${projectedRows.length} rows returned.`,
          type: 'success',
          timeMs: Math.round(performance.now() - start)
        });
      }

      // 2. UPDATE Query Handler
      else if (lowerSql.startsWith('update')) {
        const setIndex = lowerSql.indexOf('set');
        if (setIndex === -1) return logError("Syntax error: Missing SET clause");

        const tableName = cleanSql.substring(6, setIndex).trim();
        const validTables = ['users', 'restaurants', 'menu_items', 'orders', 'riders', 'feedback'];
        if (!validTables.includes(tableName.toLowerCase())) {
          return logError(`Table '${tableName}' does not exist in foodwala_db.`);
        }

        const actualTableName = tableName.toLowerCase() as keyof typeof dbState;
        const setPart = cleanSql.substring(setIndex + 3).trim();
        const whereIndex = setPart.toLowerCase().indexOf('where');

        let assignments = '';
        let whereClause = '';

        if (whereIndex !== -1) {
          assignments = setPart.substring(0, whereIndex).trim();
          whereClause = setPart.substring(whereIndex + 5).trim();
        } else {
          assignments = setPart;
        }

        // Parse assignments, support single assignment for now (e.g. rating = 4.9)
        const matchAssign = assignments.match(/([a-zA-Z_0-9]+)\s*=\s*['"]?([^'"]+)['"]?/i);
        if (!matchAssign) return logError("Unsupported UPDATE format. Use UPDATE <table> SET col = 'val' [WHERE ...]");

        const [, assignCol, assignVal] = matchAssign;
        let updateCount = 0;

        const updatedRows = dbState[actualTableName].map(row => {
          let matches = true;
          if (whereClause) {
            const matchEq = whereClause.match(/([a-zA-Z_0-9]+)\s*=\s*['"]?([^'"]+)['"]?/i);
            if (matchEq) {
              const [, col, val] = matchEq;
              matches = String(row[col] ?? '').toLowerCase() === val.toLowerCase();
            }
          }

          if (matches) {
            updateCount++;
            return {
              ...row,
              [assignCol]: isNaN(Number(assignVal)) ? assignVal : Number(assignVal)
            };
          }
          return row;
        });

        onUpdateState(actualTableName as string, updatedRows);
        setQueryResult({
          columns: ['Rows Affected', 'Status'],
          rows: [{ 'Rows Affected': updateCount, 'Status': 'OK' }],
          message: `Query OK, ${updateCount} rows affected.`,
          type: 'success',
          timeMs: Math.round(performance.now() - start)
        });
      }

      // 3. TRUNCATE Handler
      else if (lowerSql.startsWith('truncate')) {
        const tableName = cleanSql.substring(8).trim();
        const validTables = ['users', 'restaurants', 'menu_items', 'orders', 'riders', 'feedback'];
        if (!validTables.includes(tableName.toLowerCase())) {
          return logError(`Table '${tableName}' does not exist.`);
        }

        const actualTableName = tableName.toLowerCase() as keyof typeof dbState;
        onUpdateState(actualTableName as string, []);
        setQueryResult({
          columns: ['Message'],
          rows: [[`Table ${tableName} truncated successfully.`]],
          message: 'Query OK, table truncated.',
          type: 'success',
          timeMs: Math.round(performance.now() - start)
        });
      }

      // Unsupported command fallback
      else {
        return logError("Unsupported statement. This client terminal supports SELECT, UPDATE and TRUNCATE SQL queries on the active memory state.");
      }
    } catch (err: any) {
      logError(err.message || 'Syntax error parsed.');
    }
  };

  return (
    <div className="bg-gray-950 text-gray-200 rounded-3xl p-5 md:p-6 border border-gray-800 shadow-2xl font-mono relative overflow-hidden space-y-6">
      <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none">
        <Database className="h-44 w-44" />
      </div>

      {/* Connection bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-gray-800 pb-4">
        <div className="flex items-center gap-2.5">
          <div className="h-3 w-3 bg-emerald-500 rounded-full animate-pulse" />
          <div>
            <h4 className="text-sm font-bold text-gray-100 flex items-center gap-1.5">
              <Terminal className="h-4 w-4 text-emerald-400" /> mysql_foodwala_conn
            </h4>
            <p className="text-[10px] text-gray-500">Host: 127.0.0.1 • Database: foodwala_db • Port: 3306</p>
          </div>
        </div>

        <div className="flex items-center gap-2 text-[10px] font-bold text-gray-400 bg-gray-900 border border-gray-800 px-3 py-1.5 rounded-xl">
          <Table className="h-3.5 w-3.5 text-gray-500" /> Schema Explorer Available
        </div>
      </div>

      {/* Editor Console */}
      <div className="space-y-3">
        <div className="flex justify-between items-center">
          <span className="text-[11px] text-gray-500 uppercase tracking-widest font-sans font-bold">SQL Editor console</span>
          <div className="flex gap-2">
            <button
              onClick={() => setQuery('')}
              className="px-2 py-1 text-[10px] bg-gray-900 hover:bg-gray-800 border border-gray-800 text-gray-400 rounded-lg transition-all"
              title="Clear input query"
            >
              Clear
            </button>
          </div>
        </div>

        <div className="relative border border-gray-800 rounded-2xl overflow-hidden bg-gray-900">
          <textarea
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            rows={3}
            className="w-full bg-transparent p-4 text-xs md:text-sm font-mono text-emerald-400 outline-none resize-none focus:ring-1 focus:ring-emerald-500/20"
            placeholder="SELECT * FROM restaurants;"
          />
          <div className="absolute bottom-3 right-3">
            <button
              onClick={handleRunQuery}
              className="bg-emerald-500 hover:bg-emerald-600 active:scale-95 text-gray-950 font-black text-xs px-4 py-2 rounded-xl transition-all flex items-center gap-1 cursor-pointer"
            >
              <Play className="h-3.5 w-3.5 fill-gray-950" /> Run Query
            </button>
          </div>
        </div>
      </div>

      {/* Predefined Quick Tags */}
      <div className="space-y-2">
        <span className="text-[10px] text-gray-500 uppercase tracking-widest font-sans font-bold block">Quick Reference Templates</span>
        <div className="flex flex-wrap gap-2">
          {presetQueries.map((item, idx) => (
            <button
              key={idx}
              onClick={() => {
                setQuery(item.sql);
                // Trigger query run directly
                setTimeout(() => {
                  const btn = document.querySelector('[class*="bg-emerald-500"]') as HTMLButtonElement;
                  btn?.click();
                }, 50);
              }}
              className="text-[10px] bg-gray-900 hover:bg-gray-800 border border-gray-800/60 text-gray-300 px-3 py-1.5 rounded-xl transition-all text-left font-sans font-bold hover:border-emerald-500/30"
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>

      {/* Results panel */}
      <div className="space-y-3">
        <span className="text-[11px] text-gray-500 uppercase tracking-widest font-sans font-bold block">Query Result Console</span>

        {queryResult ? (
          <div className="border border-gray-800 rounded-2xl overflow-hidden bg-gray-950/60 flex flex-col min-h-36 max-h-64">
            {/* Console Log Header */}
            <div className={`p-3 text-[11px] font-bold border-b border-gray-850 flex items-center justify-between ${
              queryResult.type === 'success' ? 'bg-emerald-950/20 text-emerald-400' : 'bg-red-950/20 text-red-400'
            }`}>
              <div className="flex items-center gap-1.5">
                {queryResult.type === 'success' ? (
                  <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                ) : (
                  <AlertCircle className="h-4 w-4 text-red-400" />
                )}
                <span>{queryResult.message}</span>
              </div>
              <span className="text-gray-500 font-mono text-[10px]">{queryResult.timeMs}ms</span>
            </div>

            {/* Response Data Table Grid */}
            {queryResult.type === 'success' && queryResult.columns.length > 0 && (
              <div className="overflow-auto flex-1 max-h-48 text-[11px]">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-gray-900 text-gray-400 sticky top-0 border-b border-gray-800">
                      {queryResult.columns.map((col) => (
                        <th key={col} className="p-2.5 font-extrabold uppercase tracking-wider min-w-[100px]">
                          {col}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-900/60">
                    {queryResult.rows.length === 0 ? (
                      <tr>
                        <td colSpan={queryResult.columns.length} className="p-4 text-center text-gray-500 font-semibold italic">
                          No matching row records found.
                        </td>
                      </tr>
                    ) : (
                      queryResult.rows.map((row, rowIdx) => (
                        <tr key={rowIdx} className="hover:bg-gray-900/40 transition-colors">
                          {queryResult.columns.map((col) => (
                            <td key={col} className="p-2.5 text-gray-300 font-medium truncate max-w-[180px]">
                              {typeof row[col] === 'object' ? JSON.stringify(row[col]).slice(0, 30) + '...' : String(row[col])}
                            </td>
                          ))}
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        ) : (
          <div className="border border-dashed border-gray-800 rounded-2xl p-8 text-center text-gray-500 text-xs">
            <HelpCircle className="h-8 w-8 text-gray-700 mx-auto mb-2.5" />
            Write an SQL query or select a preset reference query above to run and inspect active records in Hyderabad's FoodWala memory database!
          </div>
        )}
      </div>
    </div>
  );
}
