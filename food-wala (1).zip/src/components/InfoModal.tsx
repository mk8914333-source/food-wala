import React from 'react';
import { X } from 'lucide-react';

interface InfoModalProps {
  type: 'about' | 'privacy' | 'contact' | 'careers';
  onClose: () => void;
}

export default function InfoModal({ type, onClose }: InfoModalProps) {
  const content = {
    about: { title: 'About Us', body: 'We are Food Wala, committed to delivering the freshest and most delicious meals across Hyderabad. Our mission is to bridge the gap between your cravings and your doorstep with speed and hygiene.' },
    privacy: { title: 'Privacy Policy', body: 'Your privacy is our priority. We collect only necessary information to ensure smooth delivery and secure transactions. We never share your personal data with third parties without your explicit consent.' },
    contact: { title: 'Contact Support', body: 'Need help? Our support team is available 24/7. Reach out to us at support@foodwala.com or call our helpline at 0300-1234567.' },
    careers: { title: 'Careers', body: 'Want to work with us? We are always looking for passionate individuals to join our team in logistics, tech, and operations. Email your CV to careers@foodwala.com.' }
  };
  
  const { title, body } = content[type];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="bg-white rounded-3xl p-8 max-w-md w-full shadow-2xl">
        <div className="flex justify-between items-center mb-6">
          <h2 className="font-display font-bold text-2xl text-gray-900">{title}</h2>
          <button onClick={onClose} className="p-1 rounded-full hover:bg-gray-100 transition-colors">
            <X className="h-6 w-6 text-gray-400 hover:text-gray-600" />
          </button>
        </div>
        <p className="text-gray-600 leading-relaxed text-sm">{body}</p>
        <button 
          onClick={onClose} 
          className="mt-8 w-full bg-red-500 text-white font-bold py-3 rounded-xl hover:bg-red-600 transition-colors"
        >
          Close
        </button>
      </div>
    </div>
  );
}
