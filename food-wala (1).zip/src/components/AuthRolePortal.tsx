import React, { useState } from 'react';
import { User as UserIcon, ShieldAlert, Key, HelpCircle, LogOut, CheckCircle2, ShoppingBag, Eye, EyeOff, UserCheck, Shield } from 'lucide-react';
import { User } from '../types';
import { motion, AnimatePresence } from 'motion/react';

interface AuthRolePortalProps {
  currentRole: 'customer' | 'restaurant' | 'rider' | 'admin' | 'super_owner';
  onRoleChange: (role: 'customer' | 'restaurant' | 'rider' | 'admin' | 'super_owner', payload?: any) => void;
  restaurants: any[];
  usersList: User[];
}

export default function AuthRolePortal({ currentRole, onRoleChange, restaurants, usersList }: AuthRolePortalProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'customer' | 'restaurant' | 'rider' | 'admin' | 'super_owner'>('customer');
  const [showPassword, setShowPassword] = useState(false);
  
  // Login form values
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [selectedRestId, setSelectedRestId] = useState(restaurants[0]?.id || 'kfc');
  const [riderId, setRiderId] = useState('');
  const [adminUser, setAdminUser] = useState('');
  const [adminPasscode, setAdminPasscode] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);

  // Persistent mock login memory
  const [loggedInUser, setLoggedInUser] = useState<string | null>(() => {
    return localStorage.getItem('foodwala_session_user') || null;
  });
  const [loggedInRole, setLoggedInRole] = useState<string | null>(() => {
    return localStorage.getItem('foodwala_session_role') || 'customer';
  });

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    if (activeTab === 'customer') {
      const user = email.split('@')[0] || 'Customer';
      setLoggedInUser(user);
      setLoggedInRole('customer');
      localStorage.setItem('foodwala_session_user', user);
      localStorage.setItem('foodwala_session_role', 'customer');
      onRoleChange('customer', { username: user });
    } else if (activeTab === 'restaurant') {
      const targetRest = restaurants.find(r => r.id === selectedRestId);
      const partnerName = targetRest ? targetRest.name : 'Restaurant Partner';
      setLoggedInUser(partnerName);
      setLoggedInRole('restaurant');
      localStorage.setItem('foodwala_session_user', partnerName);
      localStorage.setItem('foodwala_session_role', 'restaurant');
      onRoleChange('restaurant', { restaurantId: selectedRestId, restaurantName: partnerName });
    } else if (activeTab === 'rider') {
      const riderName = riderId || 'Speedy Rider';
      setLoggedInUser(riderName);
      setLoggedInRole('rider');
      localStorage.setItem('foodwala_session_user', riderName);
      localStorage.setItem('foodwala_session_role', 'rider');
      onRoleChange('rider', { name: riderName });
    } else if (activeTab === 'admin' || activeTab === 'super_owner') {
      const matched = usersList.find(
        (a) => (activeTab === 'super_owner' ? a.role === 'super_owner' : a.role === 'admin') && 
                    a.username?.toLowerCase() === adminUser.toLowerCase() && a.passcode === adminPasscode
      );

      if (!matched) {
        setLoginError("Invalid Admin Username or Passcode!");
        return;
      }

      if (matched.status === 'blocked') {
        setLoginError("This Admin account has been blocked by the Super Admin!");
        return;
      }

      setLoggedInUser(matched.name);
      setLoggedInRole(matched.role);
      localStorage.setItem('foodwala_session_user', matched.name);
      localStorage.setItem('foodwala_session_role', matched.role);
      localStorage.setItem('foodwala_session_admin_role', matched.role);
      onRoleChange(matched.role === 'super_owner' ? 'super_owner' : 'admin', { adminRole: matched.role, name: matched.name });
    }
    setIsOpen(false);
  };

  const handleLogout = () => {
    setLoggedInUser(null);
    setLoggedInRole('customer');
    localStorage.removeItem('foodwala_session_user');
    localStorage.removeItem('foodwala_session_role');
    localStorage.removeItem('foodwala_session_admin_role');
    onRoleChange('customer');
  };

  return (
    <div className="relative font-sans">
      {/* Mini Persistent Header Portal Trigger */}
      <div className="bg-red-950 text-red-50 text-[11px] font-semibold py-1.5 px-4 sm:px-6 flex items-center justify-between border-b border-red-900/40 shadow-inner">
        <div className="flex items-center gap-1.5">
          <span className="h-2 w-2 bg-emerald-400 rounded-full animate-pulse" />
          <span>Active Session: </span>
          <span className="font-extrabold text-red-300 uppercase tracking-wider bg-red-900/50 px-2 py-0.5 rounded-md border border-red-800/60">
            {loggedInUser ? `${loggedInUser} (${loggedInRole})` : 'Guest Customer (Default)'}
          </span>
        </div>
        
        <div className="flex items-center gap-2">
          {loggedInUser ? (
            <button
              onClick={handleLogout}
              className="hover:text-white transition-colors flex items-center gap-1 cursor-pointer font-extrabold uppercase tracking-widest text-[9px]"
            >
              <LogOut className="h-3.5 w-3.5 text-red-300" /> Sign Out
            </button>
          ) : (
            <button
              onClick={() => setIsOpen(true)}
              className="hover:text-white text-red-200 transition-colors flex items-center gap-1 cursor-pointer font-extrabold uppercase tracking-widest text-[10px]"
            >
              <UserCheck className="h-3.5 w-3.5 text-red-300" /> Portals / Login
            </button>
          )}
        </div>
      </div>

      {/* Gateway Login Overlay Modal */}
      <AnimatePresence>
        {isOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-950/80 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl overflow-hidden shadow-2xl max-w-md w-full border border-gray-150 flex flex-col max-h-[90vh]"
            >
              {/* Header */}
              <div className="p-5 border-b border-gray-100 flex items-center justify-between bg-gray-50/50">
                <div className="flex items-center gap-2">
                  <div className="bg-red-500 text-white p-2 rounded-xl">
                    <img src="/logo.png" alt="Food Wala" className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="font-display font-black text-base text-gray-900">FoodWala Identity Portals</h3>
                    <p className="text-[10px] text-gray-400 font-semibold uppercase mt-0.5">Select Role Portal to Sign-In</p>
                  </div>
                </div>
                <button
                  onClick={() => setIsOpen(false)}
                  className="p-1 text-gray-400 hover:text-gray-900 bg-gray-100 hover:bg-gray-200 rounded-full transition-all cursor-pointer"
                >
                  <XIcon className="h-5 w-5" />
                </button>
              </div>

              {/* Portal Selector Grid */}
              <div className="p-4 border-b border-gray-50 grid grid-cols-5 gap-1 bg-gray-50/30">
                {(['customer', 'restaurant', 'rider', 'admin', 'super_owner'] as const).map((role) => (
                  <button
                    key={role}
                    type="button"
                    onClick={() => setActiveTab(role)}
                    className={`py-2 rounded-xl text-[9px] font-black uppercase transition-all border ${
                      activeTab === role
                        ? 'bg-red-500 text-white border-red-500 shadow-sm'
                        : 'bg-white hover:bg-gray-50 text-gray-600 border-gray-150'
                    }`}
                  >
                    {role.replace('_', ' ')}
                  </button>
                ))}
              </div>

              {/* Identity Form */}
              <form onSubmit={handleLoginSubmit} className="p-6 space-y-4 flex-1 overflow-y-auto">
                <div className="space-y-4">
                  {loginError && (
                    <div className="bg-red-50 border border-red-100 p-3 rounded-2xl text-[11px] font-bold text-red-600">
                      ⚠️ {loginError}
                    </div>
                  )}
                  {activeTab === 'customer' && (
                    <>
                      <div className="bg-red-50/50 border border-red-100/60 p-3.5 rounded-2xl">
                        <p className="text-[11px] text-red-700 font-semibold leading-relaxed">
                          👤 Customer Registration Portal saves your favorite addresses, tracks past meals, and unlocks instant 50% discount codes!
                        </p>
                      </div>

                      <div className="space-y-3">
                        <div>
                          <label className="block text-[10px] font-extrabold text-gray-400 uppercase tracking-wider mb-1">
                            Email Address / Username
                          </label>
                          <input
                            type="email"
                            required
                            placeholder="ali@example.com"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            className="w-full px-3.5 py-2.5 border border-gray-150 focus:border-red-500 rounded-xl text-xs outline-none focus:ring-1 focus:ring-red-100 font-semibold"
                          />
                        </div>

                        <div>
                          <label className="block text-[10px] font-extrabold text-gray-400 uppercase tracking-wider mb-1">
                            Secure Password
                          </label>
                          <div className="relative">
                            <input
                              type={showPassword ? 'text' : 'password'}
                              required
                              placeholder="••••••••"
                              value={password}
                              onChange={(e) => setPassword(e.target.value)}
                              className="w-full px-3.5 py-2.5 border border-gray-150 focus:border-red-500 rounded-xl text-xs outline-none focus:ring-1 focus:ring-red-100 font-semibold font-mono"
                            />
                            <button
                              type="button"
                              onClick={() => setShowPassword(!showPassword)}
                              className="absolute inset-y-0 right-3 flex items-center text-gray-400 hover:text-gray-700"
                            >
                              {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                            </button>
                          </div>
                        </div>
                      </div>
                    </>
                  )}

                  {activeTab === 'restaurant' && (
                    <>
                      <div className="bg-amber-50/50 border border-amber-100/60 p-3.5 rounded-2xl">
                        <p className="text-[11px] text-amber-800 font-semibold leading-relaxed">
                          🍳 Restaurant Merchant Center. Control cooking queues, manage menu inventory, view commissions, and process rider dispatch logs!
                        </p>
                      </div>

                      <div className="space-y-3">
                        <div>
                          <label className="block text-[10px] font-extrabold text-gray-400 uppercase tracking-wider mb-1">
                            Select Restaurant Outlet
                          </label>
                          <select
                            value={selectedRestId}
                            onChange={(e) => setSelectedRestId(e.target.value)}
                            className="w-full px-3.5 py-2.5 border border-gray-150 focus:border-red-500 rounded-xl text-xs outline-none focus:ring-1 focus:ring-red-100 font-bold text-gray-700 bg-white"
                          >
                            {restaurants.map(r => (
                              <option key={r.id} value={r.id}>{r.name} - {r.category}</option>
                            ))}
                          </select>
                        </div>

                        <div>
                          <label className="block text-[10px] font-extrabold text-gray-400 uppercase tracking-wider mb-1">
                            Merchant Partner PIN Key
                          </label>
                          <input
                            type="password"
                            required
                            placeholder="e.g. partner123"
                            className="w-full px-3.5 py-2.5 border border-gray-150 focus:border-red-500 rounded-xl text-xs outline-none focus:ring-1 focus:ring-red-100 font-semibold font-mono"
                          />
                        </div>
                      </div>
                    </>
                  )}

                  {activeTab === 'rider' && (
                    <>
                      <div className="bg-blue-50/50 border border-blue-100/60 p-3.5 rounded-2xl">
                        <p className="text-[11px] text-blue-800 font-semibold leading-relaxed">
                          🏍️ Rider Fleet Logistics Portal. Claim active delivery route tickets, trigger GPS simulation coordinates, and confirm delivered checks!
                        </p>
                      </div>

                      <div className="space-y-3">
                        <div>
                          <label className="block text-[10px] font-extrabold text-gray-400 uppercase tracking-wider mb-1">
                            Rider ID / Call Sign
                          </label>
                          <input
                            type="text"
                            required
                            placeholder="e.g. LHR-Rider-45"
                            value={riderId}
                            onChange={(e) => setRiderId(e.target.value)}
                            className="w-full px-3.5 py-2.5 border border-gray-150 focus:border-red-500 rounded-xl text-xs outline-none focus:ring-1 focus:ring-red-100 font-semibold"
                          />
                        </div>

                        <div>
                          <label className="block text-[10px] font-extrabold text-gray-400 uppercase tracking-wider mb-1">
                            Security Security Passkey
                          </label>
                          <input
                            type="password"
                            required
                            placeholder="e.g. rider123"
                            className="w-full px-3.5 py-2.5 border border-gray-150 focus:border-red-500 rounded-xl text-xs outline-none focus:ring-1 focus:ring-red-100 font-semibold font-mono"
                          />
                        </div>
                      </div>
                    </>
                  )}

                  {(activeTab === 'admin' || activeTab === 'super_owner') && (
                    <>
                      <div className="bg-slate-900/5 p-3.5 rounded-2xl border border-gray-200">
                        <p className="text-[11px] text-slate-700 font-semibold leading-relaxed">
                          🛡️ FoodWala Administration Core. Full system logs, SQL Console dashboard terminal query tools, and consumer feedback moderators!
                        </p>
                      </div>

                      <div className="space-y-3">
                        <div>
                          <label className="block text-[10px] font-extrabold text-gray-400 uppercase tracking-wider mb-1">
                            {activeTab === 'super_owner' ? 'Super Owner' : 'Admin'} Account Name
                          </label>
                          <input
                            type="text"
                            required
                            placeholder={activeTab === 'super_owner' ? 'super' : 'admin'}
                            value={adminUser}
                            onChange={(e) => setAdminUser(e.target.value)}
                            className="w-full px-3.5 py-2.5 border border-gray-150 focus:border-red-500 rounded-xl text-xs outline-none focus:ring-1 focus:ring-red-100 font-semibold"
                          />
                        </div>

                        <div>
                          <label className="block text-[10px] font-extrabold text-gray-400 uppercase tracking-wider mb-1">
                            Passcode
                          </label>
                          <input
                            type="password"
                            required
                            placeholder={activeTab === 'super_owner' ? 'super123' : 'admin123'}
                            value={adminPasscode}
                            onChange={(e) => setAdminPasscode(e.target.value)}
                            className="w-full px-3.5 py-2.5 border border-gray-150 focus:border-red-500 rounded-xl text-xs outline-none focus:ring-1 focus:ring-red-100 font-semibold font-mono"
                          />
                        </div>
                      </div>
                    </>
                  )}
                </div>

                <button
                  type="submit"
                  className="w-full bg-red-500 hover:bg-red-600 active:scale-95 text-white font-bold py-3 rounded-xl text-xs transition-all flex items-center justify-center gap-1.5 shadow-md shadow-red-500/10 mt-6 cursor-pointer"
                >
                  Confirm Identity & Log-In <CheckCircle2 className="h-4.5 w-4.5" />
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

// Simple absolute SVG XIcon
function XIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" {...props}>
      <line x1="18" y1="6" x2="6" y2="18"></line>
      <line x1="6" y1="6" x2="18" y2="18"></line>
    </svg>
  );
}
