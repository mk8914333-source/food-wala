import React, { useState } from 'react';
import { X, History, Calendar, Trash2, ShoppingBag, CheckCircle2, RotateCcw, Receipt, ArrowRight, Star } from 'lucide-react';
import { Order, CartItem } from '../types';
import { motion, AnimatePresence } from 'motion/react';

interface OrderHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  orderHistory: Order[];
  onClearHistory: () => void;
  onReorder: (items: CartItem[]) => void;
  onRateOrder: (orderId: string, rating: number, note: string) => void;
}

export default function OrderHistoryModal({
  isOpen,
  onClose,
  orderHistory,
  onClearHistory,
  onReorder,
  onRateOrder
}: OrderHistoryModalProps) {
  const [rating, setRating] = useState<number>(0);
  const [hoverRating, setHoverRating] = useState<number>(0);
  const [ratingNote, setRatingNote] = useState<string>('');
  const [ratingOrderId, setRatingOrderId] = useState<string | null>(null);
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-900/60 backdrop-blur-xs">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        className="bg-white rounded-3xl overflow-hidden shadow-2xl max-w-lg w-full border border-gray-100 flex flex-col max-h-[85vh]"
      >
        {/* Header */}
        <div className="p-5 border-b border-gray-100 flex items-center justify-between bg-gray-50/50">
          <div className="flex items-center gap-2">
            <div className="bg-red-50 text-red-500 p-2 rounded-xl">
              <History className="h-5 w-5" />
            </div>
            <div>
              <h3 className="font-display font-bold text-lg text-gray-900">Your Past Orders</h3>
              <p className="text-xs text-gray-400 font-semibold mt-0.5">Stored securely in your browser</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {orderHistory.length > 0 && (
              <button
                onClick={() => {
                  if (confirm("Are you sure you want to clear your order history?")) {
                    onClearHistory();
                  }
                }}
                className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 text-xs font-bold"
                title="Clear all order history"
              >
                <Trash2 className="h-4 w-4" />
                <span className="hidden sm:inline">Clear All</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1.5 hover:bg-gray-100 text-gray-400 hover:text-gray-900 rounded-full transition-all cursor-pointer"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* List Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {orderHistory.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <div className="h-16 w-16 bg-red-50 text-red-400 rounded-2xl flex items-center justify-center mb-4">
                <History className="h-8 w-8" />
              </div>
              <h4 className="font-display font-bold text-gray-800 text-base">No order history yet</h4>
              <p className="text-xs text-gray-400 max-w-xs mt-2">
                Your future culinary adventures will show up here. Place an order to start compiling your history!
              </p>
              <button
                onClick={onClose}
                className="mt-6 px-5 py-2.5 bg-red-500 hover:bg-red-600 text-white font-bold text-xs rounded-xl transition-all active:scale-95 cursor-pointer flex items-center gap-1.5"
              >
                Order Now <ArrowRight className="h-4.5 w-4.5" />
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {orderHistory.map((order) => {
                const uniqueRestaurantNames = Array.from(
                  new Set(order.items.map((item) => item.restaurantName))
                ).join(', ');

                return (
                  <div
                    key={order.id}
                    className="border border-gray-100 hover:border-gray-200 rounded-2xl p-4 space-y-4 hover:shadow-xs transition-all bg-white"
                  >
                    {/* Top Row with ID & Date */}
                    <div className="flex justify-between items-start gap-4">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-xs text-gray-900 bg-gray-100 px-2.5 py-0.5 rounded-md">
                            {order.id}
                          </span>
                          <span className="text-[10px] bg-green-50 text-green-700 font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                            <CheckCircle2 className="h-3 w-3" /> Paid & Completed
                          </span>
                        </div>
                        <p className="text-xs font-bold text-gray-700 mt-2 truncate">
                          Ordered from: <span className="text-red-500">{uniqueRestaurantNames}</span>
                        </p>
                      </div>

                      <div className="text-right flex-shrink-0">
                        <div className="flex items-center justify-end gap-1 text-[10px] text-gray-400 font-bold uppercase tracking-wider">
                          <Calendar className="h-3.5 w-3.5 text-gray-300" />
                          <span>{order.date}</span>
                        </div>
                        <p className="text-sm font-extrabold text-gray-900 mt-1">Rs. {order.total}</p>
                      </div>
                    </div>

                    {/* Items Breakdown */}
                    <div className="bg-gray-50/50 p-3 rounded-xl border border-gray-100/40 text-xs space-y-1.5">
                      {order.items.map((item) => (
                        <div key={item.menuItem.id} className="flex justify-between items-center">
                          <span className="text-gray-600 font-semibold">
                            <span className="text-gray-400 font-bold pr-1.5">{item.quantity}x</span>
                            {item.menuItem.name}
                          </span>
                          <span className="text-gray-500 font-medium">Rs. {item.menuItem.price * item.quantity}</span>
                        </div>
                      ))}
                      {order.notes && (
                        <div className="pt-1.5 mt-1.5 border-t border-gray-100 text-[10px] text-gray-400 italic">
                          <span className="font-bold font-sans not-italic">Chef Note:</span> "{order.notes}"
                        </div>
                      )}
                    </div>

                    {/* Bottom action row */}
                    <div className="flex justify-between items-center pt-1">
                      <div className="text-[11px] text-gray-400 font-semibold">
                        <span>Method: {order.deliveryMethod === 'delivery' ? '🚚 Home Delivery' : '🎒 Counter Pickup'}</span>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        {order.status === 'delivered' && !order.rating && (
                          <button
                            onClick={() => setRatingOrderId(order.id)}
                            className="px-3 py-1 bg-yellow-100 text-yellow-700 hover:bg-yellow-200 font-bold text-xs rounded-xl transition-all duration-200 cursor-pointer"
                          >
                            Rate Delivery
                          </button>
                        )}
                        <button
                          onClick={() => onReorder(order.items)}
                          className="px-3.5 py-1.5 bg-red-50 text-red-600 hover:bg-red-500 hover:text-white font-bold text-xs rounded-xl transition-all duration-200 active:scale-95 cursor-pointer flex items-center gap-1.5"
                        >
                          <RotateCcw className="h-3.5 w-3.5" /> Reorder Items
                        </button>
                      </div>
                    </div>
                    {ratingOrderId === order.id && (
                      <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} className="bg-gray-50 p-4 rounded-xl mt-2 space-y-3">
                        <h4 className="text-xs font-bold text-gray-800">Rate your experience</h4>
                        <div className="flex gap-1.5">
                          {[1,2,3,4,5].map(r => (
                            <button
                              key={r}
                              type="button"
                              onClick={() => setRating(r)}
                              onMouseEnter={() => setHoverRating(r)}
                              onMouseLeave={() => setHoverRating(0)}
                              className={`transition-all ${ (hoverRating || rating) >= r ? 'text-yellow-400 scale-110' : 'text-gray-300' }`}
                            >
                              <Star className="h-6 w-6 fill-current" />
                            </button>
                          ))}
                        </div>
                        <input type="text" placeholder="Write a note (optional)..." value={ratingNote} onChange={e => setRatingNote(e.target.value)} className="w-full p-2.5 rounded-xl border border-gray-200 text-xs focus:ring-2 focus:ring-red-100 outline-none"/>
                        <button onClick={() => { onRateOrder(order.id, rating, ratingNote); setRatingOrderId(null); setRating(0); setRatingNote(''); }} className="bg-red-500 text-white w-full py-2 rounded-xl text-xs font-bold hover:bg-red-600 active:scale-95 transition-all">Submit Rating</button>
                      </motion.div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
}
