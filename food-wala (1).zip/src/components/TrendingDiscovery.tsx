import React, { useState } from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Cell,
  CartesianGrid,
  AreaChart,
  Area
} from 'recharts';
import {
  Flame,
  TrendingUp,
  Sparkles,
  Award,
  ShoppingCart,
  ArrowRight,
  BarChart3,
  Utensils,
  History,
  CheckCircle,
  HelpCircle,
  ChevronRight
} from 'lucide-react';
import { RESTAURANTS } from '../data';
import { MenuItem, Restaurant, Order } from '../types';
import { motion, AnimatePresence } from 'motion/react';

interface TrendingDiscoveryProps {
  onSelectRestaurant: (restaurant: Restaurant) => void;
  onAddToCart: (item: MenuItem) => void;
  orderHistory: Order[];
}

export default function TrendingDiscovery({
  onSelectRestaurant,
  onAddToCart,
  orderHistory
}: TrendingDiscoveryProps) {
  const [activeTab, setActiveTab] = useState<'charts' | 'explorer' | 'leaderboard'>('charts');
  const [chartMode, setChartMode] = useState<'restaurants' | 'dishes'>('restaurants');

  // 1. Calculate Real-Time / Simulated Restaurant Data
  const getRestaurantData = () => {
    const baseRestaurants = [
      { id: 'biryani-house', name: 'Biryani House', orders: 1240, color: '#ef4444', accent: 'bg-red-50 text-red-600' },
      { id: 'kfc', name: 'KFC', orders: 980, color: '#dc2626', accent: 'bg-red-50 text-red-600' },
      { id: 'mcdonalds', name: "McDonald's", orders: 845, color: '#eab308', accent: 'bg-yellow-50 text-yellow-600' },
      { id: 'pizza-point', name: 'Pizza Point', orders: 620, color: '#f97316', accent: 'bg-orange-50 text-orange-600' }
    ];

    // Factor in active session order history dynamically to make charts interactive!
    orderHistory.forEach((order) => {
      order.items.forEach((item) => {
        const matched = baseRestaurants.find((br) => br.id === item.restaurantId);
        if (matched) {
          matched.orders += item.quantity * 15; // Weighted order impact
        }
      });
    });

    return baseRestaurants.sort((a, b) => b.orders - a.orders);
  };

  // 2. Calculate Real-Time / Simulated Dish Data
  const getDishData = () => {
    const baseDishes = [
      { id: 'biryani-chicken', name: 'Special Chicken Biryani', restaurantId: 'biryani-house', orders: 450, color: '#ef4444' },
      { id: 'kfc-zinger', name: 'Zinger Burger', restaurantId: 'kfc', orders: 380, color: '#dc2626' },
      { id: 'mcd-bigmac', name: 'Big Mac Burger', restaurantId: 'mcdonalds', orders: 340, color: '#eab308' },
      { id: 'pizza-tikka', name: 'Chicken Tikka Pizza', restaurantId: 'pizza-point', orders: 290, color: '#f97316' },
      { id: 'biryani-pulao', name: 'Beef Bannu Pulao', restaurantId: 'biryani-house', orders: 210, color: '#ef4444' }
    ];

    orderHistory.forEach((order) => {
      order.items.forEach((item) => {
        const matched = baseDishes.find((bd) => bd.id === item.menuItem.id);
        if (matched) {
          matched.orders += item.quantity * 15; // Weighted order impact
        }
      });
    });

    return baseDishes.sort((a, b) => b.orders - a.orders);
  };

  const restaurantData = getRestaurantData();
  const dishData = getDishData();

  // Find real model mapping objects so clicks work flawlessly
  const getRealRestaurant = (id: string): Restaurant | undefined => {
    return RESTAURANTS.find((r) => r.id === id);
  };

  const getRealMenuItem = (dishId: string, restaurantId: string): MenuItem | undefined => {
    const rest = getRealRestaurant(restaurantId);
    return rest?.menu.find((item) => item.id === dishId);
  };

  // Custom tooltips matching elegant high-contrast dark style
  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-gray-900 border border-gray-800 text-white p-3 rounded-2xl shadow-xl font-sans text-xs space-y-1">
          <p className="font-bold text-gray-100">{payload[0].name}</p>
          <div className="flex items-center gap-1 text-red-400 font-extrabold font-mono mt-0.5">
            <span>🔥 {payload[0].value.toLocaleString()} orders</span>
          </div>
          <p className="text-[10px] text-gray-400">Weekly simulated + session volume</p>
        </div>
      );
    }
    return null;
  };

  return (
    <div id="trending-discovery-panel" className="bg-white rounded-3xl border border-gray-100 p-6 md:p-8 space-y-6 shadow-xs relative overflow-hidden">
      {/* Dynamic ambient background glow */}
      <div className="absolute -top-24 -right-24 h-48 w-48 rounded-full bg-red-500/5 blur-3xl pointer-events-none" />

      {/* Header Panel */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-gray-100 pb-5">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="flex h-2.5 w-2.5 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-red-500"></span>
            </span>
            <h3 className="font-display font-black text-lg md:text-xl text-gray-900 flex items-center gap-2">
              <Flame className="h-5.5 w-5.5 text-red-500 fill-red-500" />
              Live Discovery Hub
            </h3>
          </div>
          <p className="text-xs text-gray-400 font-semibold max-w-lg">
            Simulated weekly orders combined with your active session history. Click elements to navigate or order!
          </p>
        </div>

        {/* Tab Controls */}
        <div className="flex items-center bg-gray-100/80 p-1 rounded-2xl self-start sm:self-auto shrink-0 border border-gray-200/40">
          <button
            onClick={() => setActiveTab('charts')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'charts'
                ? 'bg-white text-gray-900 shadow-sm'
                : 'text-gray-500 hover:text-gray-900'
            }`}
          >
            <BarChart3 className="h-3.5 w-3.5" /> Analytics
          </button>
          <button
            onClick={() => setActiveTab('explorer')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'explorer'
                ? 'bg-white text-gray-900 shadow-sm'
                : 'text-gray-500 hover:text-gray-900'
            }`}
          >
            <Utensils className="h-3.5 w-3.5" /> Hot Dishes
          </button>
          <button
            onClick={() => setActiveTab('leaderboard')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'leaderboard'
                ? 'bg-white text-gray-900 shadow-sm'
                : 'text-gray-500 hover:text-gray-900'
            }`}
          >
            <Award className="h-3.5 w-3.5" /> Leaderboard
          </button>
        </div>
      </div>

      {/* Main Tab Content */}
      <AnimatePresence mode="wait">
        {/* TAB 1: CHARTS */}
        {activeTab === 'charts' && (
          <motion.div
            key="charts-tab"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-6"
          >
            {/* Chart Sub-mode selectors */}
            <div className="flex items-center gap-3">
              <button
                onClick={() => setChartMode('restaurants')}
                className={`px-4 py-1.5 rounded-xl text-xs font-bold transition-all border cursor-pointer ${
                  chartMode === 'restaurants'
                    ? 'bg-red-500 text-white border-red-500 shadow-md shadow-red-500/15'
                    : 'bg-white text-gray-600 border-gray-150 hover:bg-gray-50'
                }`}
              >
                🔥 Premium Outlets
              </button>
              <button
                onClick={() => setChartMode('dishes')}
                className={`px-4 py-1.5 rounded-xl text-xs font-bold transition-all border cursor-pointer ${
                  chartMode === 'dishes'
                    ? 'bg-red-500 text-white border-red-500 shadow-md shadow-red-500/15'
                    : 'bg-white text-gray-600 border-gray-150 hover:bg-gray-50'
                }`}
              >
                ⭐ Popular Dishes
              </button>
            </div>

            {/* Recharts Render Area */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
              {/* Left Column: The Chart */}
              <div className="lg:col-span-7 space-y-4">
                <div className="h-60 w-full bg-gray-50/70 border border-gray-100/50 rounded-2xl p-4 flex flex-col justify-between shadow-xs">
                  <ResponsiveContainer width="100%" height="100%">
                    {chartMode === 'restaurants' ? (
                      <BarChart
                        data={restaurantData}
                        layout="vertical"
                        margin={{ top: 5, right: 15, left: -20, bottom: 5 }}
                      >
                        <XAxis type="number" hide />
                        <YAxis
                          dataKey="name"
                          type="category"
                          axisLine={false}
                          tickLine={false}
                          tick={{ fill: '#374151', fontSize: 11, fontWeight: 700, fontFamily: 'Space Grotesk' }}
                          width={110}
                        />
                        <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(239, 68, 68, 0.04)' }} />
                        <Bar dataKey="orders" radius={[0, 8, 8, 0]} barSize={16}>
                          {restaurantData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Bar>
                      </BarChart>
                    ) : (
                      <BarChart
                        data={dishData}
                        layout="horizontal"
                        margin={{ top: 10, right: 10, left: -10, bottom: 5 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f3f4f6" />
                        <XAxis
                          dataKey="name"
                          axisLine={false}
                          tickLine={false}
                          tick={{ fill: '#4b5563', fontSize: 10, fontWeight: 700 }}
                          tickFormatter={(val) => (val.length > 12 ? `${val.slice(0, 10)}...` : val)}
                        />
                        <YAxis axisLine={false} tickLine={false} tick={{ fill: '#9ca3af', fontSize: 10 }} />
                        <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(239, 68, 68, 0.04)' }} />
                        <Bar dataKey="orders" radius={[8, 8, 0, 0]} barSize={24}>
                          {dishData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Bar>
                      </BarChart>
                    )}
                  </ResponsiveContainer>
                </div>
                <div className="text-center">
                  <span className="text-[10px] text-gray-400 font-bold bg-gray-100 px-2.5 py-1 rounded-full inline-flex items-center gap-1">
                    <History className="h-3 w-3" /> Dynamically reacts to your session purchases
                  </span>
                </div>
              </div>

              {/* Right Column: Dynamic interaction cards corresponding to selected mode */}
              <div className="lg:col-span-5 space-y-3">
                <h4 className="text-xs uppercase font-extrabold tracking-wider text-gray-400">
                  {chartMode === 'restaurants' ? 'Instant Navigation' : 'Quick Single-Click Add'}
                </h4>

                <div className="space-y-2 max-h-[250px] overflow-y-auto pr-1">
                  {chartMode === 'restaurants' ? (
                    restaurantData.map((item, idx) => {
                      const realRest = getRealRestaurant(item.id);
                      if (!realRest) return null;
                      return (
                        <div
                          key={item.id}
                          onClick={() => onSelectRestaurant(realRest)}
                          className="flex items-center justify-between p-3 border border-gray-100 hover:border-red-100 hover:bg-red-50/10 rounded-2xl cursor-pointer transition-all group shadow-2xs"
                        >
                          <div className="flex items-center gap-3">
                            <div className="h-8 w-8 bg-gray-150 rounded-xl overflow-hidden shrink-0 border border-gray-200/50">
                              <img src={realRest.image} alt={item.name} className="h-full w-full object-cover group-hover:scale-105 transition-transform" />
                            </div>
                            <div>
                              <h5 className="text-xs font-bold text-gray-900 group-hover:text-red-500 transition-colors">
                                {item.name}
                              </h5>
                              <p className="text-[10px] text-gray-400 font-semibold">
                                ⭐ {realRest.rating} • {item.orders} orders
                              </p>
                            </div>
                          </div>
                          <button className="p-1.5 bg-gray-50 hover:bg-red-500 hover:text-white text-gray-400 rounded-xl transition-all">
                            <ChevronRight className="h-4 w-4" />
                          </button>
                        </div>
                      );
                    })
                  ) : (
                    dishData.map((item) => {
                      const realItem = getRealMenuItem(item.id, item.restaurantId);
                      const realRest = getRealRestaurant(item.restaurantId);
                      if (!realItem || !realRest) return null;
                      return (
                        <div
                          key={item.id}
                          className="flex items-center justify-between p-3 border border-gray-100 rounded-2xl hover:border-gray-200 transition-all shadow-2xs"
                        >
                          <div className="flex items-center gap-3">
                            <div className="h-8 w-8 bg-gray-150 rounded-xl overflow-hidden shrink-0">
                              <img src={realItem.image} alt={item.name} className="h-full w-full object-cover" />
                            </div>
                            <div>
                              <h5 className="text-xs font-bold text-gray-900 truncate max-w-[130px] sm:max-w-xs">
                                {item.name}
                              </h5>
                              <p className="text-[9px] text-red-500 font-bold">
                                {realRest.name}
                              </p>
                            </div>
                          </div>

                          <div className="flex items-center gap-2 shrink-0">
                            <span className="text-[11px] font-extrabold text-gray-900">
                              Rs. {realItem.price}
                            </span>
                            <button
                              onClick={() => onAddToCart(realItem)}
                              className="px-2.5 py-1.5 bg-red-50 text-red-600 hover:bg-red-500 hover:text-white font-extrabold text-[10px] rounded-lg transition-all active:scale-90 flex items-center gap-1 cursor-pointer"
                            >
                              + Add
                            </button>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* TAB 2: EXPLORER Bento Grid of popular items */}
        {activeTab === 'explorer' && (
          <motion.div
            key="explorer-tab"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {dishData.slice(0, 3).map((item, idx) => {
              const realItem = getRealMenuItem(item.id, item.restaurantId);
              const realRest = getRealRestaurant(item.restaurantId);
              if (!realItem || !realRest) return null;

              return (
                <div
                  key={item.id}
                  className="bg-white border border-gray-100 rounded-3xl overflow-hidden hover:shadow-md transition-all flex flex-col group relative"
                >
                  {/* Rank Badge */}
                  <div className="absolute top-3 left-3 z-10 bg-gray-900/80 backdrop-blur-md text-white font-mono font-black text-xs px-2.5 py-1 rounded-xl flex items-center gap-1">
                    <Award className="h-3.5 w-3.5 text-yellow-400" /> #{idx + 1}
                  </div>

                  {/* Food Image */}
                  <div className="h-36 w-full overflow-hidden bg-gray-100 relative">
                    <img
                      src={realItem.image}
                      alt={realItem.name}
                      className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-gray-900/60 to-transparent" />
                    <div className="absolute bottom-3 left-3 text-white">
                      <span className="text-[10px] uppercase tracking-wider font-extrabold bg-red-500 text-white px-2 py-0.5 rounded-full">
                        {realRest.name}
                      </span>
                    </div>
                  </div>

                  {/* Body Info */}
                  <div className="p-4 flex-1 flex flex-col justify-between space-y-4">
                    <div className="space-y-1">
                      <h4 className="font-display font-bold text-sm text-gray-900 group-hover:text-red-500 transition-colors">
                        {realItem.name}
                      </h4>
                      <p className="text-[11px] text-gray-400 font-medium line-clamp-2">
                        {realItem.description}
                      </p>
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-gray-50">
                      <div>
                        <span className="text-[10px] text-gray-400 font-semibold block">Price</span>
                        <span className="text-sm font-extrabold text-gray-900">Rs. {realItem.price}</span>
                      </div>

                      <button
                        onClick={() => onAddToCart(realItem)}
                        className="px-3.5 py-2 bg-red-500 hover:bg-red-600 text-white font-bold text-xs rounded-xl transition-all shadow-md shadow-red-500/10 active:scale-95 flex items-center gap-1 cursor-pointer"
                      >
                        <ShoppingCart className="h-3.5 w-3.5" /> Order Now
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </motion.div>
        )}

        {/* TAB 3: LEADERBOARD List views */}
        {activeTab === 'leaderboard' && (
          <motion.div
            key="leaderboard-tab"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="grid grid-cols-1 md:grid-cols-2 gap-8"
          >
            {/* Outlets ranking */}
            <div className="space-y-4">
              <div className="flex items-center gap-2 border-b border-gray-50 pb-2">
                <div className="h-6 w-6 rounded-lg bg-red-50 text-red-500 flex items-center justify-center">
                  <TrendingUp className="h-4 w-4" />
                </div>
                <h4 className="text-sm font-bold text-gray-900">Top Outlets Ranking</h4>
              </div>

              <div className="space-y-2.5">
                {restaurantData.map((item, idx) => {
                  const realRest = getRealRestaurant(item.id);
                  if (!realRest) return null;
                  return (
                    <div
                      key={item.id}
                      onClick={() => onSelectRestaurant(realRest)}
                      className="flex items-center justify-between p-3.5 border border-gray-100 hover:border-gray-200 hover:bg-gray-50/50 rounded-2xl cursor-pointer transition-all group"
                    >
                      <div className="flex items-center gap-3">
                        <div className="font-mono font-black text-gray-400 text-xs w-5">
                          {idx === 0 ? '🏆' : `#${idx + 1}`}
                        </div>
                        <div>
                          <h5 className="text-xs font-bold text-gray-900 group-hover:text-red-500 transition-colors">
                            {item.name}
                          </h5>
                          <span className="text-[10px] text-gray-400 font-semibold">
                            {realRest.category} • Avg Prep: {realRest.prepTime}
                          </span>
                        </div>
                      </div>

                      <div className="text-right">
                        <span className="inline-flex items-center gap-1 text-[10px] font-extrabold text-red-500 bg-red-50 px-2 py-0.5 rounded-md">
                          🔥 {item.orders.toLocaleString()} orders
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Dishes ranking */}
            <div className="space-y-4">
              <div className="flex items-center gap-2 border-b border-gray-50 pb-2">
                <div className="h-6 w-6 rounded-lg bg-yellow-50 text-yellow-600 flex items-center justify-center">
                  <Award className="h-4 w-4" />
                </div>
                <h4 className="text-sm font-bold text-gray-900">Top Dishes Ranking</h4>
              </div>

              <div className="space-y-2.5">
                {dishData.map((item, idx) => {
                  const realItem = getRealMenuItem(item.id, item.restaurantId);
                  const realRest = getRealRestaurant(item.restaurantId);
                  if (!realItem || !realRest) return null;
                  return (
                    <div
                      key={item.id}
                      className="flex items-center justify-between p-3.5 border border-gray-100 rounded-2xl hover:border-gray-200 transition-all"
                    >
                      <div className="flex items-center gap-3">
                        <div className="font-mono font-black text-gray-400 text-xs w-5">
                          {idx === 0 ? '👑' : `#${idx + 1}`}
                        </div>
                        <div>
                          <h5 className="text-xs font-bold text-gray-900">
                            {item.name}
                          </h5>
                          <span className="text-[10px] text-red-500 font-bold">
                            By {realRest.name}
                          </span>
                        </div>
                      </div>

                      <button
                        onClick={() => onAddToCart(realItem)}
                        className="px-3 py-1 bg-gray-50 hover:bg-red-500 hover:text-white text-gray-700 font-bold text-xs rounded-xl transition-all duration-200 active:scale-95 flex items-center gap-1 cursor-pointer shrink-0"
                      >
                        Rs. {realItem.price} • + Add
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
