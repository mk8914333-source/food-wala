import React, { useState, useEffect } from 'react';
import { 
  ShieldAlert, BarChart3, Users, ChefHat, MessageSquareCode, Database, 
  RefreshCw, CheckCircle2, Wallet, XCircle, CheckCircle, Sparkles, 
  AlertTriangle, FileText, Activity, UserCheck, Send, TrendingUp, Bot,
  MapPin, Globe, Plus, Trash2, Edit2, Lock, Unlock, Phone, DollarSign, 
  Percent, Check, AlertCircle, Key, Settings, HelpCircle, Mail, 
  MessageCircle, Star, Sliders, Shield
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Order, Restaurant, WalletTransaction, User, MenuItem } from '../types';
import MySQLConsole from './MySQLConsole';
import TopRidersSection from './TopRidersSection';

interface AdminPortalProps {
  orders: Order[];
  walletTransactions: WalletTransaction[];
  admins: any[];
  restaurants: Restaurant[];
  feedback: any[];
  onApproveWalletTx: (id: string) => void;
  onRejectWalletTx: (id: string) => void;
  onUpdateState: (table: string, data: any[]) => void;
  initialDbData: {
    users: User[];
    restaurants: Restaurant[];
    menu_items: any[];
    orders: Order[];
    riders: any[];
    feedback: any[];
  };
}

export default function AdminPortal({
  orders,
  walletTransactions,
  admins,
  restaurants,
  feedback,
  onApproveWalletTx,
  onRejectWalletTx,
  onUpdateState,
  initialDbData,
}: AdminPortalProps) {
  // Session check for Super Admin or normal Admin
  const currentSessionUser = localStorage.getItem('foodwala_session_user') || 'Admin';
  const currentSessionRole = localStorage.getItem('foodwala_session_role') || 'admin';
  const isAdminSuper = currentSessionRole === 'super_owner' || localStorage.getItem('foodwala_session_admin_role') === 'super_owner';

  // 17 Modules Definition
  const modulesList = [
    { id: 'dashboard', name: '1. Stats & Dashboard', icon: BarChart3, role: 'admin' },
    { id: 'users', name: '2. User Management', icon: Users, role: 'admin' },
    { id: 'restaurants', name: '3. Restaurant Partners', icon: ChefHat, role: 'admin' },
    { id: 'menu', name: '4. Menu & Prices', icon: Sparkles, role: 'admin' },
    { id: 'orders', name: '5. Order Management', icon: FileText, role: 'admin' },
    { id: 'riders', name: '6. Rider Management', icon: Activity, role: 'admin' },
    { id: 'payments', name: '7. Payments & Payouts', icon: Wallet, role: 'admin' },
    { id: 'promotions', name: '8. Promotions & Coupons', icon: TrendingUp, role: 'admin' },
    { id: 'locations', name: '9. Locations & Zones', icon: MapPin, role: 'admin' },
    { id: 'reviews', name: '10. Reviews & Ratings', icon: MessageSquareCode, role: 'admin' },
    { id: 'notifications', name: '11. Notifications Broadcast', icon: Send, role: 'admin' },
    { id: 'reports', name: '12. Financial Reports', icon: FileText, role: 'admin' },
    { id: 'cms', name: '13. Content Editor (CMS)', icon: Globe, role: 'admin' },
    { id: 'settings', name: '14. System Parameters', icon: Settings, role: 'super_owner' },
    { id: 'support', name: '15. Support & Tickets', icon: HelpCircle, role: 'admin' },
    { id: 'roles', name: '16. Roles & Permissions', icon: Shield, role: 'super_owner' },
    { id: 'logs', name: '17. Logs & Security', icon: Key, role: 'super_owner' }
  ];

  const [activeModule, setActiveModule] = useState<string>('dashboard');

  // --- COMPLAINTS/TICKETS MOCK DATA ---
  const [complaints, setComplaints] = useState<any[]>(() => {
    const saved = localStorage.getItem('foodwala_admin_complaints');
    if (saved) return JSON.parse(saved);
    const initial = [
      { id: 'TKT-101', user: 'Ali Ahmed', role: 'Customer', issue: 'Cold food delivered with leakage.', status: 'open', time: '2026-07-14 08:30 AM', messages: [{ sender: 'user', text: 'Please help, the burger was ice cold.' }] },
      { id: 'TKT-102', user: 'Pizza Point', role: 'Restaurant Owner', issue: 'Payout delayed for last week cycles.', status: 'open', time: '2026-07-14 09:12 AM', messages: [{ sender: 'user', text: 'Our weekly payout hasn\'t reached our bank.' }] },
      { id: 'TKT-103', user: 'Sajid Iqbal', role: 'Rider', issue: 'App crashed during delivery status change.', status: 'resolved', time: '2026-07-13 04:45 PM', messages: [{ sender: 'user', text: 'I completed order #304 but couldn\'t mark it.' }, { sender: 'admin', text: 'We have updated your status manually.' }] }
    ];
    localStorage.setItem('foodwala_admin_complaints', JSON.stringify(initial));
    return initial;
  });

  // CMS Content States
  const [cmsBanners, setCmsBanners] = useState<{ id: string; url: string; title: string }[]>([
    { id: 'b-1', url: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=1200&q=80', title: '50% Flat Discount on Pizza Point!' },
    { id: 'b-2', url: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=1200&q=80', title: 'Double Patty Zinger Feast starts from Rs.250' }
  ]);
  const [faqs, setFaqs] = useState<{ question: string; answer: string }[]>([
    { question: 'How do I cancel my order on FoodWala?', answer: 'Go to your active order, and if the restaurant has not accepted it yet, you can press cancel. Otherwise, contact support.' },
    { question: 'What are the delivery charges?', answer: 'Base delivery charges range from Rs. 80 to Rs. 150 depending on your zone and city.' }
  ]);
  const [privacyPolicy, setPrivacyPolicy] = useState('We value your privacy. FoodWala collects minimum telemetry and user addresses purely to complete real-time logistics deliveries.');
  const [termsAndConditions, setTermsAndConditions] = useState('By registering, customers, riders, and merchants agree to complete orders truthfully. Standard commission rates apply.');

  // Locations State
  const [locations, setLocations] = useState<{ id: string; country: string; city: string; zone: string; charges: number }[]>([
    { id: 'loc-1', country: 'Pakistan', city: 'Lahore', zone: 'DHA Phase 5', charges: 120 },
    { id: 'loc-2', country: 'Pakistan', city: 'Lahore', zone: 'Gulberg III', charges: 100 },
    { id: 'loc-3', country: 'Pakistan', city: 'Karachi', zone: 'Clifton', charges: 150 },
    { id: 'loc-4', country: 'Pakistan', city: 'Islamabad', zone: 'F-10 Markaz', charges: 110 }
  ]);
  const [newLocationZone, setNewLocationZone] = useState('');
  const [newLocationCity, setNewLocationCity] = useState('Lahore');
  const [newLocationCharges, setNewLocationCharges] = useState('100');

  // Coupons State
  const [coupons, setCoupons] = useState<{ code: string; type: 'fixed' | 'percentage'; value: number; minSpend: number }[]>([
    { code: 'WELCOME200', type: 'fixed', value: 200, minSpend: 600 },
    { code: 'PIZZA50', type: 'percentage', value: 15, minSpend: 1000 }
  ]);
  const [newCouponCode, setNewCouponCode] = useState('');
  const [newCouponType, setNewCouponType] = useState<'fixed' | 'percentage'>('fixed');
  const [newCouponValue, setNewCouponValue] = useState('100');
  const [newCouponMinSpend, setNewCouponMinSpend] = useState('500');

  // Local System Parameter Settings
  const [sysParams, setSysParams] = useState(() => {
    const saved = localStorage.getItem('foodwala_system_settings');
    if (saved) return JSON.parse(saved);
    return {
      currency: 'Rs.',
      language: 'en',
      praTaxPct: 16,
      deliveryFeeOverride: 100,
      minOrderAmount: 200,
      serviceCharges: 30,
      customAiInstruction: ''
    };
  });

  // Gateway Settings
  const [paymentSettings, setPaymentSettings] = useState(() => {
    const saved = localStorage.getItem('foodwala_payment_settings');
    if (saved) return JSON.parse(saved);
    return {
      jazzCashActive: true,
      jazzCashAccountNo: '03240732363',
      jazzCashTillId: '980131623',
      easyPaisaActive: true,
      easyPaisaAccountNo: '03240732363',
      codActive: true,
    };
  });

  // User Management Forms
  const [userSearch, setUserSearch] = useState('');
  const [selectedUserRole, setSelectedUserRole] = useState<string>('all');
  const [isAddingUser, setIsAddingUser] = useState(false);
  const [newUserName, setNewUserName] = useState('');
  const [newUserEmail, setNewUserEmail] = useState('');
  const [newUserPassword, setNewUserPassword] = useState('');
  const [newUserRole, setNewUserRole] = useState<any>('customer');

  // Menu Management Forms
  const [selectedMenuRestId, setSelectedMenuRestId] = useState<string>('');
  const [isAddingMenuItem, setIsAddingMenuItem] = useState(false);
  const [newMenuItemName, setNewMenuItemName] = useState('');
  const [newMenuItemPrice, setNewMenuItemPrice] = useState('');
  const [newMenuItemCategory, setNewMenuItemCategory] = useState<'Main' | 'Side' | 'Beverage' | 'Dessert'>('Main');
  const [newMenuItemDesc, setNewMenuItemDesc] = useState('');

  // Support / Live chat state
  const [activeTicketId, setActiveTicketId] = useState<string | null>(null);
  const [supportMessageText, setSupportMessageText] = useState('');

  // Toast System
  const [toast, setToast] = useState<{ text: string; type: 'success' | 'error' | 'info' } | null>(null);
  const showToast = (text: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToast({ text, type });
    setTimeout(() => setToast(null), 3000);
  };

  useEffect(() => {
    if (restaurants.length > 0 && !selectedMenuRestId) {
      setSelectedMenuRestId(restaurants[0].id);
    }
  }, [restaurants, selectedMenuRestId]);

  // Calculations
  const totalRevenue = orders.reduce((sum, o) => sum + o.total, 0);
  const totalTodaySales = orders
    .filter(o => o.status === 'delivered' || o.status === 'paid')
    .reduce((sum, o) => sum + o.total, 0);

  // User list mutations helper
  const handleToggleUserStatus = (userId: string) => {
    const updated = initialDbData.users.map(u => {
      if (u.id === userId) {
        const nextStatus = u.status === 'active' ? 'blocked' : 'active';
        return { ...u, status: nextStatus };
      }
      return u;
    });
    onUpdateState('users', updated);
    showToast('User state updated successfully!');
  };

  const handleDeleteUser = (userId: string) => {
    if (confirm('Are you sure you want to delete this user?')) {
      const updated = initialDbData.users.filter(u => u.id !== userId);
      onUpdateState('users', updated);
      showToast('User removed from core records!');
    }
  };

  const handleCreateUserSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUserName.trim() || !newUserEmail.trim() || !newUserPassword.trim()) {
      alert('All fields are required.');
      return;
    }
    const newUser: User = {
      id: `usr-${Date.now().toString().slice(-6)}`,
      name: newUserName,
      email: newUserEmail,
      role: newUserRole,
      status: 'active',
      created_at: new Date().toISOString().split('T')[0]
    };
    onUpdateState('users', [...initialDbData.users, newUser]);
    setIsAddingUser(false);
    setNewUserName('');
    setNewUserEmail('');
    setNewUserPassword('');
    showToast(`Added new ${newUserRole} successfully!`);
  };

  // Add Menu Item
  const handleAddMenuItemSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMenuItemName.trim() || !newMenuItemPrice.trim()) {
      alert('Name and price are required.');
      return;
    }
    const priceNum = parseFloat(newMenuItemPrice);
    if (isNaN(priceNum)) return;

    const newItem: MenuItem = {
      id: `it-${Date.now().toString().slice(-5)}`,
      name: newMenuItemName,
      price: priceNum,
      description: newMenuItemDesc || 'Special FoodWala item',
      image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=300&q=80',
      category: newMenuItemCategory
    };

    const updatedRest = restaurants.map(r => {
      if (r.id === selectedMenuRestId) {
        return {
          ...r,
          menu: [...r.menu, newItem]
        };
      }
      return r;
    });

    onUpdateState('restaurants', updatedRest);
    setIsAddingMenuItem(false);
    setNewMenuItemName('');
    setNewMenuItemPrice('');
    setNewMenuItemDesc('');
    showToast('Menu item added successfully!');
  };

  const handleToggleMenuItemAvailability = (restId: string, itemId: string) => {
    // This removes or makes item unavailable, let's toggle name prefix or price
    const updated = restaurants.map(r => {
      if (r.id === restId) {
        const nextMenu = r.menu.map(m => {
          if (m.id === itemId) {
            return { ...m, isPopular: !m.isPopular }; // use isPopular to toggle flag
          }
          return m;
        });
        return { ...r, menu: nextMenu };
      }
      return r;
    });
    onUpdateState('restaurants', updated);
    showToast('Availability status toggled!');
  };

  const handleDeleteMenuItem = (restId: string, itemId: string) => {
    if (confirm('Are you sure you want to remove this food item?')) {
      const updated = restaurants.map(r => {
        if (r.id === restId) {
          return {
            ...r,
            menu: r.menu.filter(m => m.id !== itemId)
          };
        }
        return r;
      });
      onUpdateState('restaurants', updated);
      showToast('Food item removed successfully!');
    }
  };

  // Assign Order Manually
  const handleAssignOrderToRider = (orderId: string, riderName: string) => {
    const updatedOrders = orders.map(o => {
      if (o.id === orderId) {
        return { ...o, status: 'delivery' as const, notes: `Manual Dispatch to ${riderName}` };
      }
      return o;
    });
    onUpdateState('orders', updatedOrders);
    showToast(`Order #${orderId} assigned manually to ${riderName}!`, 'success');
  };

  // Refund Order helper
  const handleRefundOrder = (order: Order) => {
    const savedBalance = parseFloat(localStorage.getItem('foodwala_wallet_balance') || '50');
    const newBalance = savedBalance + order.total;
    onUpdateState('wallet_balance', [newBalance]);

    const savedTransactions = localStorage.getItem('foodwala_wallet_transactions');
    const parsedTransactions = savedTransactions ? JSON.parse(savedTransactions) : [];
    
    const newTx = {
      id: `WTX-REF-${Date.now().toString().slice(-6)}`,
      type: 'refund',
      amount: order.total,
      channel: 'wallet_system',
      timestamp: new Date().toLocaleString(),
      status: 'completed',
      notes: `Order #${order.id} full refund processed by Admin.`
    };

    onUpdateState('wallet_transactions', [newTx, ...parsedTransactions]);
    
    const updatedOrders = orders.map(o => {
      if (o.id === order.id) {
        return { ...o, status: 'payment_rejected' as const };
      }
      return o;
    });
    onUpdateState('orders', updatedOrders);
    showToast(`Rs. ${order.total} refunded successfully to client wallet!`, 'success');
  };

  // Support / Complaint message send
  const handleSendSupportMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!supportMessageText.trim() || !activeTicketId) return;

    const updatedComplaints = complaints.map(c => {
      if (c.id === activeTicketId) {
        return {
          ...c,
          messages: [...c.messages, { sender: 'admin', text: supportMessageText }],
          status: 'resolved'
        };
      }
      return c;
    });

    setComplaints(updatedComplaints);
    localStorage.setItem('foodwala_admin_complaints', JSON.stringify(updatedComplaints));
    setSupportMessageText('');
    showToast('Reply transmitted successfully! Ticket resolved.');
  };

  // Locations add
  const handleAddLocation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newLocationZone.trim()) return;
    const priceVal = parseFloat(newLocationCharges) || 0;
    const newLoc = {
      id: `loc-${Date.now()}`,
      country: 'Pakistan',
      city: newLocationCity,
      zone: newLocationZone,
      charges: priceVal
    };
    setLocations([...locations, newLoc]);
    setNewLocationZone('');
    showToast(`Added delivery zone: ${newLoc.zone} successfully!`);
  };

  // Coupons Add
  const handleAddCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCouponCode.trim()) return;
    const val = parseFloat(newCouponValue) || 10;
    const minS = parseFloat(newCouponMinSpend) || 200;

    const nC = {
      code: newCouponCode.trim().toUpperCase(),
      type: newCouponType,
      value: val,
      minSpend: minS
    };
    setCoupons([...coupons, nC]);
    setNewCouponCode('');
    showToast(`Promo Code ${nC.code} successfully deployed!`);
  };

  // Settings saves
  const handleSaveParams = (e: React.FormEvent) => {
    e.preventDefault();
    localStorage.setItem('foodwala_system_settings', JSON.stringify(sysParams));
    showToast('Platform operational parameters saved successfully!');
  };

  const handleSaveGateway = (e: React.FormEvent) => {
    e.preventDefault();
    localStorage.setItem('foodwala_payment_settings', JSON.stringify(paymentSettings));
    showToast('JazzCash & EasyPaisa billing nodes saved successfully!');
  };

  return (
    <div className="space-y-6 font-sans">
      {/* Absolute Dynamic Toast Notification */}
      <AnimatePresence>
        {toast && (
          <motion.div 
            initial={{ opacity: 0, y: -50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -50 }}
            className={`fixed top-4 right-4 z-50 px-5 py-3 rounded-2xl text-xs font-bold text-white shadow-lg flex items-center gap-2 ${
              toast.type === 'error' ? 'bg-red-500' : toast.type === 'info' ? 'bg-indigo-600' : 'bg-emerald-600'
            }`}
          >
            {toast.type === 'error' ? <AlertCircle className="h-4 w-4 animate-spin" /> : <CheckCircle className="h-4 w-4" />}
            {toast.text}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Corporate Admin Header */}
      <div className="bg-gradient-to-r from-red-950 to-rose-900 text-white rounded-3xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none">
          <ShieldAlert className="h-32 w-32" />
        </div>
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <span className="text-[10px] font-black uppercase tracking-widest bg-white/15 px-3 py-1 rounded-full text-rose-200">
              FoodWala National Operations Console
            </span>
            <h2 className="font-display font-black text-2xl tracking-tight mt-2.5 flex items-center gap-2">
              Corporate ERP Command Center
              <Sparkles className="h-5 w-5 text-yellow-300 animate-pulse fill-yellow-300" />
            </h2>
            <p className="text-xs text-rose-100 font-medium mt-1">
              Active Session: <strong className="text-white underline">{currentSessionUser}</strong> • Rank: <strong className="text-yellow-300 uppercase">{currentSessionRole.replace('_', ' ')}</strong>
            </p>
          </div>
          <div className="flex items-center gap-3">
            <span className="flex h-3 w-3 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
            </span>
            <span className="text-[11px] font-black tracking-widest uppercase bg-rose-950/55 px-3.5 py-1.5 border border-rose-500/20 rounded-xl">
              ● Server Live: 100.0%
            </span>
          </div>
        </div>
      </div>

      {/* Main ERP Layout - Sidebar + Module View */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        
        {/* Left Side: Module Sidebar Selector */}
        <div className="lg:col-span-1 space-y-4">
          <div className="bg-white border border-gray-150 rounded-3xl p-4 shadow-3xs space-y-2.5">
            <h3 className="text-[10px] font-black uppercase tracking-wider text-gray-400 px-2.5">
              Operations Navigation
            </h3>
            <div className="flex lg:flex-col gap-1.5 overflow-x-auto lg:overflow-visible pb-2.5 lg:pb-0 scrollbar-none">
              {modulesList.map((m) => {
                const Icon = m.icon;
                const isSuperOnly = m.role === 'super_owner';
                const isRestricted = isSuperOnly && !isAdminSuper;

                return (
                  <button
                    key={m.id}
                    onClick={() => {
                      if (isRestricted) {
                        showToast('Access Blocked! Only Super Admin has permission.', 'error');
                      } else {
                        setActiveModule(m.id);
                      }
                    }}
                    className={`w-full text-left px-3.5 py-2.5 rounded-xl text-xs font-black transition-all flex items-center justify-between shrink-0 lg:shrink cursor-pointer border ${
                      activeModule === m.id
                        ? 'bg-red-500 text-white border-red-500 shadow-md shadow-red-500/10'
                        : isRestricted
                        ? 'bg-gray-50 text-gray-300 border-transparent cursor-not-allowed'
                        : 'bg-white text-gray-600 hover:text-gray-900 hover:bg-gray-50 border-transparent'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <Icon className="h-4 w-4 shrink-0" />
                      <span className="whitespace-nowrap">{m.name}</span>
                    </div>
                    {isSuperOnly && (
                      <Lock className={`h-3 w-3 shrink-0 ${activeModule === m.id ? 'text-white' : 'text-amber-500'}`} />
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Quick System Telemetry Info Box */}
          <div className="bg-gradient-to-br from-slate-900 to-slate-950 text-slate-300 rounded-3xl p-4.5 border border-slate-800 shadow-sm space-y-3">
            <span className="text-[9px] font-black uppercase tracking-wider bg-slate-800 text-slate-300 px-2.5 py-0.5 rounded-full block w-max">
              System Health
            </span>
            <div className="space-y-1.5 text-[11px] font-semibold">
              <div className="flex justify-between">
                <span>Active Channels:</span>
                <span className="text-emerald-400">3 Node Nodes</span>
              </div>
              <div className="flex justify-between">
                <span>Total Commissions:</span>
                <span className="text-white">Rs. {(totalRevenue * (sysParams.praTaxPct / 100)).toFixed(0)}</span>
              </div>
              <div className="flex justify-between">
                <span>Pending Complaints:</span>
                <span className="text-yellow-400">{complaints.filter(c => c.status === 'open').length} tickets</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Side: Active Module Canvas */}
        <div className="lg:col-span-3 space-y-6">

          {/* 1. Dashboard & Live Stats */}
          {activeModule === 'dashboard' && (
            <div className="space-y-6">
              {/* Dynamic Stats Cards */}
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                <div className="bg-white border border-gray-150 p-4 rounded-2xl shadow-3xs">
                  <span className="text-[10px] text-gray-400 font-bold uppercase block">Core System Revenue</span>
                  <p className="text-xl font-black text-slate-900 mt-1">Rs. {totalRevenue.toLocaleString()}</p>
                </div>
                <div className="bg-white border border-gray-150 p-4 rounded-2xl shadow-3xs">
                  <span className="text-[10px] text-gray-400 font-bold uppercase block">Today's Active Sales</span>
                  <p className="text-xl font-black text-emerald-600 mt-1">Rs. {totalTodaySales.toLocaleString()}</p>
                </div>
                <div className="bg-white border border-gray-150 p-4 rounded-2xl shadow-3xs col-span-2 md:col-span-1">
                  <span className="text-[10px] text-gray-400 font-bold uppercase block">Registered Users</span>
                  <p className="text-xl font-black text-indigo-600 mt-1">{initialDbData.users.length} accounts</p>
                </div>
                <div className="bg-white border border-gray-150 p-4 rounded-2xl shadow-3xs">
                  <span className="text-[10px] text-gray-400 font-bold uppercase block">Total Placed Orders</span>
                  <p className="text-xl font-black text-slate-800 mt-1">{orders.length} orders</p>
                </div>
                <div className="bg-white border border-gray-150 p-4 rounded-2xl shadow-3xs">
                  <span className="text-[10px] text-gray-400 font-bold uppercase block">Active Merchants</span>
                  <p className="text-xl font-black text-rose-500 mt-1">{restaurants.length} outlets</p>
                </div>
                <div className="bg-white border border-gray-150 p-4 rounded-2xl shadow-3xs">
                  <span className="text-[10px] text-gray-400 font-bold uppercase block">Fleet Riders List</span>
                  <p className="text-xl font-black text-blue-600 mt-1">{(initialDbData.riders || []).length} riders</p>
                </div>
              </div>

              {/* Handcrafted Graphic Chart */}
              <div className="bg-white border border-gray-150 rounded-3xl p-5 md:p-6 shadow-3xs space-y-4">
                <div className="flex justify-between items-center border-b border-gray-100 pb-3">
                  <div>
                    <h3 className="font-display font-black text-gray-900 text-sm">Revenue & Delivery Growth Curve</h3>
                    <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider mt-0.5">Real-time daily telemetry visualization</p>
                  </div>
                  <span className="text-[10px] bg-red-100 text-red-700 font-black px-2.5 py-1 rounded-full uppercase">Live</span>
                </div>
                <div className="h-64 bg-slate-50 border border-slate-100 rounded-2xl p-4 flex flex-col justify-between relative overflow-hidden">
                  <div className="absolute inset-0 p-6 flex flex-col justify-between pointer-events-none opacity-20">
                    <div className="border-b border-gray-300 w-full" />
                    <div className="border-b border-gray-300 w-full" />
                    <div className="border-b border-gray-300 w-full" />
                    <div className="border-b border-gray-300 w-full" />
                  </div>
                  {/* Visual SVG line representing trends */}
                  <div className="flex-1 w-full relative">
                    <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
                      <path d="M0,80 Q25,40 50,60 T100,20" fill="none" stroke="rgb(239, 68, 68)" strokeWidth="3" />
                      <path d="M0,80 Q25,40 50,60 T100,20 L100,100 L0,100 Z" fill="rgba(239, 68, 68, 0.05)" />
                    </svg>
                  </div>
                  <div className="flex justify-between text-[10px] font-bold text-gray-400 uppercase pt-2 border-t border-slate-200">
                    <span>Monday</span>
                    <span>Tuesday</span>
                    <span>Wednesday</span>
                    <span>Thursday</span>
                    <span>Friday</span>
                    <span>Saturday</span>
                    <span>Sunday</span>
                  </div>
                </div>
              </div>

              {/* Top Riders List */}
              <TopRidersSection riders={initialDbData.riders} />
            </div>
          )}

          {/* 2. User Management */}
          {activeModule === 'users' && (
            <div className="bg-white border border-gray-150 rounded-3xl p-5 md:p-6 shadow-3xs space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-gray-100 pb-4">
                <div>
                  <h3 className="font-display font-black text-gray-900 text-sm">Platform User Directory</h3>
                  <p className="text-[10px] text-gray-400 font-bold uppercase mt-0.5">Control login nodes, toggle security ranks, block violators</p>
                </div>
                <button
                  onClick={() => setIsAddingUser(true)}
                  className="bg-red-500 hover:bg-red-600 text-white font-bold text-xs px-4 py-2 rounded-xl transition-all flex items-center gap-1.5 shadow-sm cursor-pointer"
                >
                  <Plus className="h-4 w-4" /> Add Register Node
                </button>
              </div>

              {/* Filter controls */}
              <div className="flex flex-col sm:flex-row gap-3">
                <input
                  type="text"
                  placeholder="Search user email or name..."
                  value={userSearch}
                  onChange={(e) => setUserSearch(e.target.value)}
                  className="bg-gray-50 border border-gray-150 rounded-xl px-4 py-2 text-xs font-semibold outline-none focus:border-red-500 focus:bg-white transition-all flex-1"
                />
                <select
                  value={selectedUserRole}
                  onChange={(e) => setSelectedUserRole(e.target.value)}
                  className="bg-gray-50 border border-gray-150 rounded-xl px-4 py-2 text-xs font-bold outline-none"
                >
                  <option value="all">All Ranks</option>
                  <option value="customer">Customers</option>
                  <option value="restaurant">Merchants</option>
                  <option value="rider">Riders</option>
                  <option value="admin">Administrators</option>
                </select>
              </div>

              {/* Add User Panel modal */}
              {isAddingUser && (
                <form onSubmit={handleCreateUserSubmit} className="bg-gray-50 border border-gray-150 rounded-2xl p-4.5 space-y-3.5 animate-fadeIn">
                  <div className="flex justify-between items-center border-b border-gray-150 pb-2">
                    <span className="text-[10px] text-gray-500 font-extrabold uppercase">Add New User Credentials</span>
                    <button type="button" onClick={() => setIsAddingUser(false)} className="text-xs text-gray-400 font-bold hover:text-gray-700">Cancel</button>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                    <div className="space-y-1">
                      <label className="text-[9px] font-black uppercase text-gray-400">Full Name</label>
                      <input
                        type="text"
                        required
                        value={newUserName}
                        onChange={(e) => setNewUserName(e.target.value)}
                        className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2 text-xs font-semibold outline-none"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[9px] font-black uppercase text-gray-400">Email Address</label>
                      <input
                        type="email"
                        required
                        value={newUserEmail}
                        onChange={(e) => setNewUserEmail(e.target.value)}
                        className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2 text-xs font-semibold outline-none"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[9px] font-black uppercase text-gray-400">Password / Access Code</label>
                      <input
                        type="password"
                        required
                        value={newUserPassword}
                        onChange={(e) => setNewUserPassword(e.target.value)}
                        className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2 text-xs font-semibold outline-none"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[9px] font-black uppercase text-gray-400">Security Rank Role</label>
                      <select
                        value={newUserRole}
                        onChange={(e) => setNewUserRole(e.target.value)}
                        className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2 text-xs font-bold outline-none"
                      >
                        <option value="customer">Customer</option>
                        <option value="restaurant">Restaurant Owner</option>
                        <option value="rider">Rider</option>
                      </select>
                    </div>
                  </div>
                  <button type="submit" className="w-full bg-red-500 hover:bg-red-600 text-white text-xs font-black py-2.5 rounded-xl">
                    Deploy User Node
                  </button>
                </form>
              )}

              {/* Users Ledger */}
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-gray-50 border-b border-gray-100 font-black text-gray-400 uppercase tracking-wider">
                      <th className="p-3">User Node</th>
                      <th className="p-3">Email</th>
                      <th className="p-3">Rank Role</th>
                      <th className="p-3">Status</th>
                      <th className="p-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50 font-semibold">
                    {initialDbData.users
                      .filter(u => {
                        const mRole = selectedUserRole === 'all' || u.role === selectedUserRole;
                        const mSearch = u.name.toLowerCase().includes(userSearch.toLowerCase()) || u.email.toLowerCase().includes(userSearch.toLowerCase());
                        return mRole && mSearch;
                      })
                      .map((u) => (
                        <tr key={u.id} className="hover:bg-gray-50/40">
                          <td className="p-3">
                            <div>
                              <p className="font-black text-gray-900">{u.name}</p>
                              <p className="text-[10px] text-gray-400 font-mono">{u.id}</p>
                            </div>
                          </td>
                          <td className="p-3 text-gray-600 font-mono">{u.email}</td>
                          <td className="p-3">
                            <span className="px-2 py-0.5 rounded-md text-[10px] font-black uppercase bg-indigo-50 text-indigo-700">
                              {u.role}
                            </span>
                          </td>
                          <td className="p-3">
                            <span className={`px-2 py-0.5 rounded-md text-[10px] font-black uppercase ${
                              u.status === 'active' ? 'bg-emerald-50 text-emerald-700' : 'bg-red-50 text-red-700'
                            }`}>
                              {u.status}
                            </span>
                          </td>
                          <td className="p-3 text-right space-x-1">
                            <button
                              onClick={() => handleToggleUserStatus(u.id)}
                              className={`px-2 py-1 rounded-lg text-[9px] font-black uppercase border ${
                                u.status === 'active' ? 'bg-amber-50 text-amber-700 border-amber-200' : 'bg-emerald-50 text-emerald-700 border-emerald-200'
                              }`}
                            >
                              {u.status === 'active' ? 'Block' : 'Unblock'}
                            </button>
                            <button
                              onClick={() => handleDeleteUser(u.id)}
                              className="px-2 py-1 bg-red-50 text-red-600 hover:bg-red-100 border border-red-200 rounded-lg text-[9px] font-bold uppercase"
                            >
                              Delete
                            </button>
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* 3. Restaurant Management */}
          {activeModule === 'restaurants' && (
            <div className="bg-white border border-gray-150 rounded-3xl p-5 md:p-6 shadow-3xs space-y-6">
              <div>
                <h3 className="font-display font-black text-gray-900 text-sm border-b border-gray-100 pb-3">
                  Merchant Partnership Center
                </h3>
                <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider mt-0.5">Toggle live status, suspend merchants, review business licenses</p>
              </div>

              {/* Verify Documents Mock Popover */}
              {locations && (
                <div className="grid grid-cols-1 gap-4">
                  {restaurants.map((rest) => (
                    <div key={rest.id} className="border border-gray-150 rounded-2xl p-4.5 flex flex-col md:flex-row md:items-center justify-between gap-4 hover:border-gray-300 transition-all">
                      <div className="flex items-center gap-3">
                        <img src={rest.image} className="h-12 w-12 rounded-xl object-cover shrink-0" />
                        <div>
                          <h4 className="font-black text-sm text-gray-900 flex items-center gap-1.5">
                            {rest.name}
                            {rest.isHotel && (
                              <span className="text-[9px] bg-indigo-100 text-indigo-700 font-black uppercase px-2 py-0.5 rounded-full">Hotel Partner</span>
                            )}
                          </h4>
                          <p className="text-[10px] text-gray-500 font-medium">Category: {rest.category} • Avg Prep: {rest.prepTime}</p>
                          <p className="text-[10px] text-gray-400 font-mono mt-0.5">Min Order: Rs.{rest.minOrder} • Base Delivery: Rs.{rest.deliveryFee}</p>
                        </div>
                      </div>

                      <div className="flex flex-wrap items-center gap-2">
                        {/* Status controllers */}
                        <button
                          onClick={() => {
                            const updated = restaurants.map(r => r.id === rest.id ? { ...r, isHotel: !r.isHotel } : r);
                            onUpdateState('restaurants', updated);
                            showToast('Hotel status updated!');
                          }}
                          className={`px-2.5 py-1 rounded-lg text-[10px] font-black uppercase ${
                            rest.isHotel ? 'bg-indigo-50 text-indigo-700 border border-indigo-200' : 'bg-gray-50 text-gray-600 border border-gray-200'
                          }`}
                        >
                          {rest.isHotel ? 'Hotel Badge ON' : 'Make Hotel'}
                        </button>

                        <button
                          onClick={() => {
                            const updated = restaurants.map(r => r.id === rest.id ? { ...r, status: r.status === 'active' ? 'suspended' : 'active' as const } : r);
                            onUpdateState('restaurants', updated);
                            showToast('Merchant operational state toggled!');
                          }}
                          className={`px-2.5 py-1 rounded-lg text-[10px] font-black uppercase border ${
                            rest.status === 'active' ? 'bg-amber-50 text-amber-700 border-amber-200' : 'bg-emerald-50 text-emerald-700 border-emerald-200'
                          }`}
                        >
                          {rest.status === 'active' ? 'Suspend Merchant' : 'Activate Partner'}
                        </button>

                        <button
                          onClick={() => {
                            alert(`FBR Certificate #FBR-182939-2026\nFood License #PFA-PK-019283\nCNIC verification verified for ${rest.name}.`);
                          }}
                          className="px-2.5 py-1 bg-slate-50 border border-slate-200 hover:bg-slate-100 rounded-lg text-[10px] font-black uppercase"
                        >
                          Verify Documents 📂
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* 4. Menu Management */}
          {activeModule === 'menu' && (
            <div className="bg-white border border-gray-150 rounded-3xl p-5 md:p-6 shadow-3xs space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-gray-100 pb-4">
                <div>
                  <h3 className="font-display font-black text-gray-900 text-sm">Product Catalog & Menu Manager</h3>
                  <p className="text-[10px] text-gray-400 font-bold uppercase mt-0.5">Edit base item prices, availability tags, category mapping</p>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-xs font-bold text-gray-500">Merchant:</span>
                  <select
                    value={selectedMenuRestId}
                    onChange={(e) => setSelectedMenuRestId(e.target.value)}
                    className="bg-gray-50 border border-gray-150 rounded-xl px-3 py-1.5 text-xs font-black outline-none"
                  >
                    {restaurants.map(r => (
                      <option key={r.id} value={r.id}>{r.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Add menu item form overlay / inline */}
              {isAddingMenuItem ? (
                <form onSubmit={handleAddMenuItemSubmit} className="bg-gray-50 border border-gray-150 rounded-2xl p-4 space-y-3.5 animate-fadeIn">
                  <div className="flex justify-between items-center border-b border-gray-150 pb-1.5">
                    <span className="text-[10px] font-black uppercase text-gray-500">Add Menu Item To {(restaurants.find(x => x.id === selectedMenuRestId) || {}).name}</span>
                    <button type="button" onClick={() => setIsAddingMenuItem(false)} className="text-xs text-gray-400 font-bold">Cancel</button>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div className="space-y-1">
                      <label className="text-[9px] font-black uppercase text-gray-400">Item Name</label>
                      <input
                        type="text" required value={newMenuItemName} onChange={(e) => setNewMenuItemName(e.target.value)}
                        className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2 text-xs font-semibold outline-none"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[9px] font-black uppercase text-gray-400">Price (Rs.)</label>
                      <input
                        type="number" required value={newMenuItemPrice} onChange={(e) => setNewMenuItemPrice(e.target.value)}
                        className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2 text-xs font-semibold outline-none"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[9px] font-black uppercase text-gray-400">Category Tag</label>
                      <select
                        value={newMenuItemCategory} onChange={(e: any) => setNewMenuItemCategory(e.target.value)}
                        className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2 text-xs font-bold outline-none"
                      >
                        <option value="Main">Main Course</option>
                        <option value="Side">Side dish</option>
                        <option value="Beverage">Beverages</option>
                        <option value="Dessert">Dessert</option>
                      </select>
                    </div>
                  </div>
                  <div className="space-y-1">
                    <label className="text-[9px] font-black uppercase text-gray-400">Brief Ingredients Description</label>
                    <input
                      type="text" value={newMenuItemDesc} onChange={(e) => setNewMenuItemDesc(e.target.value)}
                      className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2 text-xs font-semibold outline-none"
                    />
                  </div>
                  <button type="submit" className="w-full bg-red-500 hover:bg-red-600 text-white font-black text-xs py-2 rounded-xl">
                    Deploy Food Item Node
                  </button>
                </form>
              ) : (
                <button
                  onClick={() => setIsAddingMenuItem(true)}
                  className="w-full bg-slate-50 border border-dashed border-slate-300 hover:border-slate-500 py-3 rounded-2xl text-xs font-black text-slate-700 flex items-center justify-center gap-1.5"
                >
                  <Plus className="h-4 w-4" /> Add Food Item To This Menu
                </button>
              )}

              {/* Items Table */}
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-gray-50 border-b border-gray-100 font-black text-gray-400 uppercase tracking-wider">
                      <th className="p-3">Dish / Item</th>
                      <th className="p-3">Category</th>
                      <th className="p-3">Price</th>
                      <th className="p-3">State</th>
                      <th className="p-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50 font-semibold text-gray-700">
                    {((restaurants.find(x => x.id === selectedMenuRestId) || {}).menu || []).map((item) => (
                      <tr key={item.id} className="hover:bg-gray-50/50">
                        <td className="p-3 font-black text-gray-900">{item.name}</td>
                        <td className="p-3 uppercase text-[10px] text-indigo-600">{item.category}</td>
                        <td className="p-3 text-slate-800">Rs. {item.price}</td>
                        <td className="p-3">
                          <button
                            onClick={() => handleToggleMenuItemAvailability(selectedMenuRestId, item.id)}
                            className={`px-2 py-0.5 rounded-md text-[9px] font-black uppercase ${
                              item.isPopular ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' : 'bg-rose-50 text-rose-700 border border-rose-100'
                            }`}
                          >
                            {item.isPopular ? 'Trending / Available' : 'Standard'}
                          </button>
                        </td>
                        <td className="p-3 text-right">
                          <button
                            onClick={() => handleDeleteMenuItem(selectedMenuRestId, item.id)}
                            className="text-red-500 hover:text-red-700 uppercase text-[10px] font-bold"
                          >
                            Remove
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* 5. Order Management */}
          {activeModule === 'orders' && (
            <div className="bg-white border border-gray-150 rounded-3xl p-5 md:p-6 shadow-3xs space-y-6">
              <div>
                <h3 className="font-display font-black text-gray-900 text-sm border-b border-gray-100 pb-3">
                  Live Dispatch & Orders Control Room
                </h3>
                <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider mt-0.5">Update cooking/logistic milestones, override payment triggers, issue wallet refunds</p>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-gray-50 border-b border-gray-100 font-black text-gray-400 uppercase tracking-wider">
                      <th className="p-3">Order Ticket</th>
                      <th className="p-3">Customer</th>
                      <th className="p-3">Subtotal / Fee</th>
                      <th className="p-3">Billing</th>
                      <th className="p-3">Fulfillment Status</th>
                      <th className="p-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50 font-semibold text-gray-700">
                    {orders.map((ord) => (
                      <tr key={ord.id} className="hover:bg-gray-50/50">
                        <td className="p-3">
                          <p className="font-black text-gray-900">#{ord.id}</p>
                          <p className="text-[9px] text-gray-400 font-mono">{ord.date}</p>
                        </td>
                        <td className="p-3">
                          <p className="font-bold text-gray-800">{ord.customerName}</p>
                          <p className="text-[9px] text-gray-500 font-semibold">{ord.address}</p>
                        </td>
                        <td className="p-3 text-slate-900">
                          Rs. {ord.total}
                          <p className="text-[9px] text-gray-400 font-bold">Delivery: Rs.{ord.deliveryFee}</p>
                        </td>
                        <td className="p-3">
                          <span className="text-[9.5px] uppercase font-black tracking-wider text-slate-500">
                            {ord.paymentMethod || 'COD'}
                          </span>
                        </td>
                        <td className="p-3">
                          <select
                            value={ord.status}
                            onChange={(e) => {
                              const updated = orders.map(o => o.id === ord.id ? { ...o, status: e.target.value as any } : o);
                              onUpdateState('orders', updated);
                              showToast(`Order #${ord.id} state updated to: ${e.target.value}!`);
                            }}
                            className="bg-gray-50 border border-gray-200 rounded-lg px-2 py-1 text-[10px] font-black uppercase outline-none"
                          >
                            <option value="received">Received</option>
                            <option value="preparing">Cooking</option>
                            <option value="delivery">Dispatch</option>
                            <option value="delivered">Delivered</option>
                            <option value="payment_verification">Verification</option>
                            <option value="payment_rejected">Rejected</option>
                            <option value="paid">Paid</option>
                          </select>
                        </td>
                        <td className="p-3 text-right space-x-1 whitespace-nowrap">
                          {ord.status !== 'payment_rejected' && (
                            <button
                              onClick={() => handleRefundOrder(ord)}
                              className="px-2 py-1 bg-amber-50 text-amber-700 hover:bg-amber-100 border border-amber-200 rounded-lg text-[9px] font-black uppercase"
                            >
                              Issue Refund
                            </button>
                          )}
                          <button
                            onClick={() => {
                              const updated = orders.filter(o => o.id !== ord.id);
                              onUpdateState('orders', updated);
                              showToast('Order node deleted.');
                            }}
                            className="px-2 py-1 bg-red-50 text-red-600 hover:bg-red-100 border border-red-100 rounded-lg text-[9px] font-bold uppercase"
                          >
                            Cancel
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* 6. Rider Management */}
          {activeModule === 'riders' && (
            <div className="bg-white border border-gray-150 rounded-3xl p-5 md:p-6 shadow-3xs space-y-6">
              <div>
                <h3 className="font-display font-black text-gray-900 text-sm border-b border-gray-100 pb-3">
                  Logistics Dispatch & Rider Fleet
                </h3>
                <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider mt-0.5">Monitor active riders, manually dispatch orders, track accumulated earnings</p>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-gray-50 border-b border-gray-100 font-black text-gray-400 uppercase tracking-wider">
                      <th className="p-3">Rider</th>
                      <th className="p-3">Phone Node</th>
                      <th className="p-3">Logistics Status</th>
                      <th className="p-3">Total Deliveries</th>
                      <th className="p-3 text-right">Fulfillment Assignment</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50 font-semibold text-gray-700">
                    {(initialDbData.riders || []).map((rider) => (
                      <tr key={rider.id} className="hover:bg-gray-50/50">
                        <td className="p-3">
                          <p className="font-black text-gray-900">{rider.name}</p>
                          <p className="text-[9.5px] text-gray-400">Motorcycle: {rider.vehicle}</p>
                        </td>
                        <td className="p-3 text-gray-600 font-mono">{rider.phone}</td>
                        <td className="p-3">
                          <select
                            value={rider.status}
                            onChange={(e) => {
                              const updated = initialDbData.riders.map(r => r.id === rider.id ? { ...r, status: e.target.value as any } : r);
                              onUpdateState('riders', updated);
                              showToast(`Rider ${rider.name} marked ${e.target.value}!`);
                            }}
                            className="bg-gray-50 border border-gray-200 rounded-lg px-2 py-1 text-[10px] font-black uppercase outline-none"
                          >
                            <option value="available">Online / Active</option>
                            <option value="offline">Offline</option>
                            <option value="delivering">Busy delivering</option>
                          </select>
                        </td>
                        <td className="p-3 text-center">{rider.completedDeliveries || 0} drops</td>
                        <td className="p-3 text-right">
                          <select
                            onChange={(e) => {
                              if (e.target.value) {
                                handleAssignOrderToRider(e.target.value, rider.name);
                                e.target.value = '';
                              }
                            }}
                            className="bg-red-50 border border-red-100 text-red-700 rounded-lg px-2 py-1 text-[10px] font-black uppercase outline-none"
                          >
                            <option value="">Dispatch Manual Order</option>
                            {orders.filter(o => o.status === 'received' || o.status === 'preparing').map(o => (
                              <option key={o.id} value={o.id}>Order #{o.id} ({o.customerName})</option>
                            ))}
                          </select>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* 7. Payments & Payouts */}
          {activeModule === 'payments' && (
            <div className="space-y-6">
              {/* JazzCash / EasyPaisa config */}
              <form onSubmit={handleSaveGateway} className="bg-white border border-gray-150 rounded-3xl p-5 md:p-6 shadow-3xs space-y-4">
                <div className="border-b border-gray-100 pb-3 flex items-center justify-between">
                  <div>
                    <h3 className="font-display font-black text-gray-900 text-sm">Fintech & Checkout Payment Nodes</h3>
                    <p className="text-[10px] text-gray-400 font-bold uppercase mt-0.5">Toggle live channels, assign Corporate Till accounts</p>
                  </div>
                  <button type="submit" className="bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black px-4 py-2 rounded-xl">
                    Save Nodes
                  </button>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="bg-slate-50 border border-slate-100 rounded-2xl p-4 space-y-3">
                    <span className="text-[10px] text-gray-500 font-extrabold uppercase">EasyPaisa Corporate Gateway</span>
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-gray-600">Gateway Status:</span>
                      <input
                        type="checkbox"
                        checked={paymentSettings.easyPaisaActive}
                        onChange={(e) => setPaymentSettings({ ...paymentSettings, easyPaisaActive: e.target.checked })}
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[9px] font-black uppercase text-gray-400">EasyPaisa Account No</label>
                      <input
                        type="text"
                        value={paymentSettings.easyPaisaAccountNo}
                        onChange={(e) => setPaymentSettings({ ...paymentSettings, easyPaisaAccountNo: e.target.value })}
                        className="w-full bg-white border border-gray-200 rounded-xl px-3 py-1.5 text-xs font-semibold outline-none"
                      />
                    </div>
                  </div>

                  <div className="bg-slate-50 border border-slate-100 rounded-2xl p-4 space-y-3">
                    <span className="text-[10px] text-gray-500 font-extrabold uppercase">JazzCash Merchant Till Node</span>
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-gray-600">Gateway Status:</span>
                      <input
                        type="checkbox"
                        checked={paymentSettings.jazzCashActive}
                        onChange={(e) => setPaymentSettings({ ...paymentSettings, jazzCashActive: e.target.checked })}
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[9px] font-black uppercase text-gray-400">JazzCash Till ID</label>
                      <input
                        type="text"
                        value={paymentSettings.jazzCashTillId}
                        onChange={(e) => setPaymentSettings({ ...paymentSettings, jazzCashTillId: e.target.value })}
                        className="w-full bg-white border border-gray-200 rounded-xl px-3 py-1.5 text-xs font-semibold outline-none"
                      />
                    </div>
                  </div>
                </div>
              </form>

              {/* Wallet Approvals Ledger */}
              <div className="bg-white border border-gray-150 rounded-3xl p-5 md:p-6 shadow-3xs space-y-4">
                <h3 className="font-display font-black text-gray-900 text-sm border-b border-gray-100 pb-3">
                  Mobile Wallet Deposit Approvals ({walletTransactions.filter(t => t.status === 'pending').length} pending)
                </h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-gray-50 border-b border-gray-100 font-black text-gray-400 uppercase tracking-wider">
                        <th className="p-3">Reference / Tx ID</th>
                        <th className="p-3">Fintech Channel</th>
                        <th className="p-3">Amount</th>
                        <th className="p-3">Sender Details</th>
                        <th className="p-3 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-50 font-semibold text-gray-700">
                      {walletTransactions.map((tx) => (
                        <tr key={tx.id} className="hover:bg-gray-50/50">
                          <td className="p-3">
                            <p className="font-black text-gray-900">{tx.id}</p>
                            <p className="text-[9px] text-gray-400">{tx.timestamp}</p>
                          </td>
                          <td className="p-3 uppercase text-indigo-600 font-black text-[10px]">{tx.channel || 'easypaisa'}</td>
                          <td className="p-3 font-black text-slate-800">Rs. {tx.amount}</td>
                          <td className="p-3">
                            <p className="font-bold">{tx.accountName || 'Unknown Customer'}</p>
                            <p className="text-[9.5px] text-gray-400">{tx.senderPhone || tx.accountNo}</p>
                          </td>
                          <td className="p-3 text-right space-x-1.5 whitespace-nowrap">
                            {tx.status === 'pending' ? (
                              <>
                                <button
                                  onClick={() => onApproveWalletTx(tx.id)}
                                  className="px-2 py-1 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-lg text-[9px] font-black uppercase"
                                >
                                  Approve
                                </button>
                                <button
                                  onClick={() => onRejectWalletTx(tx.id)}
                                  className="px-2 py-1 bg-red-50 text-red-600 border border-red-100 rounded-lg text-[9px] font-bold uppercase"
                                >
                                  Reject
                                </button>
                              </>
                            ) : (
                              <span className={`px-2 py-0.5 rounded text-[9px] font-black uppercase ${
                                tx.status === 'completed' ? 'bg-emerald-100 text-emerald-700' : 'bg-gray-100 text-gray-500'
                              }`}>
                                {tx.status}
                              </span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* 8. Promotions & Campaign Center */}
          {activeModule === 'promotions' && (
            <div className="bg-white border border-gray-150 rounded-3xl p-5 md:p-6 shadow-3xs space-y-6">
              <div className="border-b border-gray-100 pb-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h3 className="font-display font-black text-gray-900 text-sm">Campaigns, Coupons & Promotions</h3>
                  <p className="text-[10px] text-gray-400 font-bold uppercase mt-0.5">Create national coupon codes, edit referral cashbacks</p>
                </div>
              </div>

              {/* Add Coupon code form */}
              <form onSubmit={handleAddCoupon} className="bg-gray-50 border border-gray-150 rounded-2xl p-4.5 space-y-3.5">
                <span className="text-[10px] text-gray-500 font-extrabold uppercase tracking-wider block">Deploy Promo Coupon</span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className="space-y-1">
                    <label className="text-[9px] font-black uppercase text-gray-400 block">Coupon Code</label>
                    <input
                      type="text" required placeholder="E.g. PIZZA30" value={newCouponCode} onChange={(e) => setNewCouponCode(e.target.value)}
                      className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2 text-xs font-semibold outline-none"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[9px] font-black uppercase text-gray-400 block">Discount Type</label>
                    <select
                      value={newCouponType} onChange={(e: any) => setNewCouponType(e.target.value)}
                      className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2 text-xs font-bold outline-none"
                    >
                      <option value="fixed">Fixed Rs.</option>
                      <option value="percentage">Percentage %</option>
                    </select>
                  </div>
                  <div className="space-y-1">
                    <label className="text-[9px] font-black uppercase text-gray-400 block">Discount Value</label>
                    <input
                      type="number" required value={newCouponValue} onChange={(e) => setNewCouponValue(e.target.value)}
                      className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2 text-xs font-semibold outline-none"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[9px] font-black uppercase text-gray-400 block">Min Spend (Rs.)</label>
                    <input
                      type="number" required value={newCouponMinSpend} onChange={(e) => setNewCouponMinSpend(e.target.value)}
                      className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2 text-xs font-semibold outline-none"
                    />
                  </div>
                </div>
                <button type="submit" className="w-full bg-red-500 hover:bg-red-600 text-white font-black text-xs py-2 rounded-xl">
                  Deploy Active Coupon
                </button>
              </form>

              {/* Coupons List */}
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-gray-50 border-b border-gray-100 font-black text-gray-400 uppercase tracking-wider">
                      <th className="p-3">Coupon Code</th>
                      <th className="p-3">Discount Value</th>
                      <th className="p-3">Min Spend trigger</th>
                      <th className="p-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50 font-semibold text-gray-700">
                    {coupons.map((c) => (
                      <tr key={c.code} className="hover:bg-gray-50/50">
                        <td className="p-3 text-red-600 font-black tracking-wider">{c.code}</td>
                        <td className="p-3">{c.type === 'fixed' ? `Rs. ${c.value}` : `${c.value}% Flat`}</td>
                        <td className="p-3">Rs. {c.minSpend}</td>
                        <td className="p-3 text-right">
                          <button
                            onClick={() => {
                              setCoupons(coupons.filter(x => x.code !== c.code));
                              showToast('Coupon terminated.');
                            }}
                            className="text-red-500 font-bold uppercase text-[10px]"
                          >
                            Terminate
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* 9. Location Management */}
          {activeModule === 'locations' && (
            <div className="bg-white border border-gray-150 rounded-3xl p-5 md:p-6 shadow-3xs space-y-6">
              <div className="border-b border-gray-100 pb-3">
                <h3 className="font-display font-black text-gray-900 text-sm">Geographical Logistics & Zones</h3>
                <p className="text-[10px] text-gray-400 font-bold uppercase mt-0.5">Assign delivery coverage zones, configure flat dispatch rates</p>
              </div>

              {/* Add Zone */}
              <form onSubmit={handleAddLocation} className="bg-gray-50 border border-gray-150 rounded-2xl p-4 space-y-3">
                <span className="text-[10px] text-gray-500 font-extrabold uppercase tracking-wider block">Deploy Operational Coverage Node</span>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="space-y-1">
                    <label className="text-[9px] font-black uppercase text-gray-400 block">City Node</label>
                    <select
                      value={newLocationCity} onChange={(e) => setNewLocationCity(e.target.value)}
                      className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2 text-xs font-bold outline-none"
                    >
                      <option value="Lahore">Lahore</option>
                      <option value="Karachi">Karachi</option>
                      <option value="Islamabad">Islamabad</option>
                      <option value="Peshawar">Peshawar</option>
                    </select>
                  </div>
                  <div className="space-y-1">
                    <label className="text-[9px] font-black uppercase text-gray-400 block">Coverage Zone Name</label>
                    <input
                      type="text" required placeholder="E.g. Gulberg Phase II" value={newLocationZone} onChange={(e) => setNewLocationZone(e.target.value)}
                      className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2 text-xs font-semibold outline-none"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[9px] font-black uppercase text-gray-400 block">Delivery Charge (Rs.)</label>
                    <input
                      type="number" required value={newLocationCharges} onChange={(e) => setNewLocationCharges(e.target.value)}
                      className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2 text-xs font-semibold outline-none"
                    />
                  </div>
                </div>
                <button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs py-2 rounded-xl">
                  Deploy Zone coverage
                </button>
              </form>

              {/* Coverage list */}
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-gray-50 border-b border-gray-100 font-black text-gray-400 uppercase tracking-wider">
                      <th className="p-3">Country</th>
                      <th className="p-3">City</th>
                      <th className="p-3">Delivery Zone Node</th>
                      <th className="p-3">Base Logistics Charge</th>
                      <th className="p-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50 font-semibold text-gray-700">
                    {locations.map((loc) => (
                      <tr key={loc.id} className="hover:bg-gray-50/50">
                        <td className="p-3 text-gray-500 font-mono">{loc.country}</td>
                        <td className="p-3 font-bold">{loc.city}</td>
                        <td className="p-3 text-indigo-950 font-black">{loc.zone}</td>
                        <td className="p-3 text-emerald-700 font-black">Rs. {loc.charges}</td>
                        <td className="p-3 text-right">
                          <button
                            onClick={() => {
                              setLocations(locations.filter(x => x.id !== loc.id));
                              showToast('Location coverage node withdrawn.');
                            }}
                            className="text-red-500 font-bold uppercase text-[10px]"
                          >
                            Withdraw
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* 10. Reviews & Ratings Moderation */}
          {activeModule === 'reviews' && (
            <div className="bg-white border border-gray-150 rounded-3xl p-5 md:p-6 shadow-3xs space-y-6">
              <div className="border-b border-gray-100 pb-3">
                <h3 className="font-display font-black text-gray-900 text-sm">Review & Rating Moderation</h3>
                <p className="text-[10px] text-gray-400 font-bold uppercase mt-0.5">Track user sentiments, flag or delete abusive ratings</p>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-gray-50 border-b border-gray-100 font-black text-gray-400 uppercase tracking-wider">
                      <th className="p-3">Reviewer Details</th>
                      <th className="p-3">Satisfaction Rating</th>
                      <th className="p-3">Testimonial Comment</th>
                      <th className="p-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50 font-semibold text-gray-700">
                    {feedback.map((feed) => (
                      <tr key={feed.id} className="hover:bg-gray-50/50">
                        <td className="p-3">
                          <p className="font-black text-gray-900">{feed.name || 'Anonymous client'}</p>
                          <p className="text-[10px] text-gray-400">{feed.email || 'No email log'}</p>
                        </td>
                        <td className="p-3">
                          <span className="text-amber-500 font-black flex items-center gap-1">
                            ⭐ {feed.rating || 5} / 5
                          </span>
                        </td>
                        <td className="p-3 text-gray-600 max-w-xs truncate">{feed.message}</td>
                        <td className="p-3 text-right">
                          <button
                            onClick={() => {
                              const updated = feedback.filter(f => f.id !== feed.id);
                              onUpdateState('feedback', updated);
                              showToast('Review deleted successfully!');
                            }}
                            className="px-2 py-1 bg-red-50 text-red-600 hover:bg-red-100 border border-red-200 rounded-lg text-[9px] font-black uppercase"
                          >
                            Delete Review
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* 11. Broadcast Notifications */}
          {activeModule === 'notifications' && (
            <div className="bg-white border border-gray-150 rounded-3xl p-5 md:p-6 shadow-3xs space-y-6">
              <div className="border-b border-gray-100 pb-3">
                <h3 className="font-display font-black text-gray-900 text-sm">Announcement & Notification Hub</h3>
                <p className="text-[10px] text-gray-400 font-bold uppercase mt-0.5">Broadcast push, SMS, and email payloads instantly to regional cohorts</p>
              </div>

              <div className="bg-slate-50 border border-slate-100 rounded-2xl p-5 space-y-4">
                <div className="space-y-1">
                  <label className="text-[9px] font-black uppercase text-gray-400">Target Recipient Cohort</label>
                  <select className="bg-white border border-gray-200 rounded-xl px-3 py-2 text-xs font-bold outline-none w-full">
                    <option>All Registered Clients (Pakistan)</option>
                    <option>All Merchant Outlets</option>
                    <option>Active Delivery Rider Fleet</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-[9px] font-black uppercase text-gray-400">Broadcast Channel</label>
                  <select className="bg-white border border-gray-200 rounded-xl px-3 py-2 text-xs font-bold outline-none w-full">
                    <option>Push Notification Alert 📱</option>
                    <option>SMS Gateway Alert 💬</option>
                    <option>Email Newsletter Blast 📧</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-[9px] font-black uppercase text-gray-400">Message payload (Urdu / English)</label>
                  <textarea
                    rows={4}
                    placeholder="E.g. FoodWala Alert: Use promo PIZZA50 to save flat 15% on any order tonight! 🍕"
                    className="w-full bg-white border border-gray-200 rounded-xl p-3 text-xs font-semibold outline-none focus:border-red-500"
                  />
                </div>
                <button
                  type="button"
                  onClick={() => showToast('National Notification Broadcast transmitted successfully!', 'success')}
                  className="w-full bg-red-500 hover:bg-red-600 text-white font-black text-xs py-2.5 rounded-xl transition-all"
                >
                  Broadcast Announcement
                </button>
              </div>
            </div>
          )}

          {/* 12. Financial Reports */}
          {activeModule === 'reports' && (
            <div className="bg-white border border-gray-150 rounded-3xl p-5 md:p-6 shadow-3xs space-y-6">
              <div className="border-b border-gray-100 pb-3 flex justify-between items-center">
                <div>
                  <h3 className="font-display font-black text-gray-900 text-sm">ERP Financial Ledgers & Audits</h3>
                  <p className="text-[10px] text-gray-400 font-bold uppercase mt-0.5">Generate, audit, and output PRA (Punjab Revenue Authority) and national taxes</p>
                </div>
                <button
                  onClick={() => alert('PDF generation initiated. System printer ready.')}
                  className="bg-slate-850 hover:bg-slate-900 text-white text-xs font-black px-4 py-2 rounded-xl"
                >
                  Print Report
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="border border-gray-150 rounded-2xl p-4 bg-slate-50">
                  <span className="text-[9px] text-gray-400 font-extrabold uppercase">FBR General Sales Tax (GST)</span>
                  <p className="text-lg font-black text-slate-800 mt-1">Rs. {(totalRevenue * 0.16).toFixed(0)}</p>
                  <p className="text-[9px] text-gray-400 font-bold uppercase mt-0.5">Standard 16% Provincial PRA Levy</p>
                </div>
                <div className="border border-gray-150 rounded-2xl p-4 bg-slate-50">
                  <span className="text-[9px] text-gray-400 font-extrabold uppercase">FoodWala Commission Share</span>
                  <p className="text-lg font-black text-indigo-700 mt-1">Rs. {(totalRevenue * 0.10).toFixed(0)}</p>
                  <p className="text-[9px] text-gray-400 font-bold uppercase mt-0.5">10% Platform Commission</p>
                </div>
              </div>

              {/* General ledger summary */}
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-gray-50 border-b border-gray-100 font-black text-gray-400 uppercase tracking-wider">
                      <th className="p-3">Order Ticket</th>
                      <th className="p-3">Net Sales</th>
                      <th className="p-3">Tax Component</th>
                      <th className="p-3">FoodWala Commission</th>
                      <th className="p-3 text-right">Net Payout</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50 font-semibold text-gray-700">
                    {orders.map((ord) => (
                      <tr key={ord.id} className="hover:bg-gray-50/50">
                        <td className="p-3 font-black">#{ord.id}</td>
                        <td className="p-3">Rs. {(ord.total * 0.84).toFixed(0)}</td>
                        <td className="p-3 text-red-600">Rs. {(ord.total * 0.16).toFixed(0)}</td>
                        <td className="p-3 text-indigo-600">Rs. {(ord.total * 0.10).toFixed(0)}</td>
                        <td className="p-3 text-right text-emerald-700 font-black">Rs. {(ord.total * 0.74).toFixed(0)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* 13. Content Management System (CMS) */}
          {activeModule === 'cms' && (
            <div className="bg-white border border-gray-150 rounded-3xl p-5 md:p-6 shadow-3xs space-y-6">
              <div className="border-b border-gray-100 pb-3">
                <h3 className="font-display font-black text-gray-900 text-sm">CMS Marketing & Legal Editors</h3>
                <p className="text-[10px] text-gray-400 font-bold uppercase mt-0.5">Update homepage banners, edit FAQs, modify user agreements</p>
              </div>

              {/* Banners */}
              <div className="space-y-3">
                <span className="text-[10px] text-gray-400 font-extrabold uppercase">Homepage Banners</span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {cmsBanners.map(b => (
                    <div key={b.id} className="border border-gray-150 rounded-2xl overflow-hidden shadow-3xs relative group">
                      <img src={b.url} className="h-32 w-full object-cover" />
                      <div className="absolute inset-0 bg-black/40 p-3 flex flex-col justify-end text-white">
                        <p className="font-black text-xs">{b.title}</p>
                        <button
                          onClick={() => {
                            setCmsBanners(cmsBanners.filter(x => x.id !== b.id));
                            showToast('Banner retired.');
                          }}
                          className="text-[9px] text-red-300 font-bold uppercase tracking-wider underline mt-1 text-left"
                        >
                          Decommission Banner
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* FAQ and Legal fields */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4.5">
                <div className="space-y-1">
                  <label className="text-[10px] font-black uppercase text-gray-400">Privacy Policy Text</label>
                  <textarea
                    rows={4}
                    value={privacyPolicy}
                    onChange={(e) => setPrivacyPolicy(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-semibold outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-black uppercase text-gray-400">Terms & Conditions Text</label>
                  <textarea
                    rows={4}
                    value={termsAndConditions}
                    onChange={(e) => setTermsAndConditions(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-semibold outline-none"
                  />
                </div>
              </div>
              <button
                onClick={() => showToast('Legal agreements updated successfully!')}
                className="w-full bg-slate-850 hover:bg-slate-900 text-white text-xs font-black py-2.5 rounded-xl"
              >
                Save CMS Content Block
              </button>
            </div>
          )}

          {/* 14. Settings (Super Admin Only) */}
          {activeModule === 'settings' && isAdminSuper && (
            <form onSubmit={handleSaveParams} className="bg-white border border-gray-150 rounded-3xl p-5 md:p-6 shadow-3xs space-y-6">
              <div className="border-b border-gray-100 pb-3 flex justify-between items-center">
                <div>
                  <h3 className="font-display font-black text-slate-900 text-sm">System Variables & Limits</h3>
                  <p className="text-[10px] text-gray-400 font-bold uppercase mt-0.5">Edit flat fee overrides, service tax rates, and core thresholds</p>
                </div>
                <button type="submit" className="bg-red-500 hover:bg-red-600 text-white text-xs font-black px-4 py-2 rounded-xl">
                  Save Changes
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-black uppercase text-gray-400">Currency Symbol</label>
                  <input
                    type="text"
                    value={sysParams.currency}
                    onChange={(e) => setSysParams({ ...sysParams, currency: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-black uppercase text-gray-400">Default Locale Language</label>
                  <select
                    value={sysParams.language}
                    onChange={(e) => setSysParams({ ...sysParams, language: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold outline-none"
                  >
                    <option value="en">English (En)</option>
                    <option value="ur">Urdu (Ur)</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-black uppercase text-gray-400">Punjab Revenue Authority GST (%)</label>
                  <input
                    type="number"
                    value={sysParams.praTaxPct}
                    onChange={(e) => setSysParams({ ...sysParams, praTaxPct: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-black uppercase text-gray-400">Minimum Order Amount threshold (Rs.)</label>
                  <input
                    type="number"
                    value={sysParams.minOrderAmount}
                    onChange={(e) => setSysParams({ ...sysParams, minOrderAmount: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold outline-none"
                  />
                </div>
              </div>
            </form>
          )}

          {/* 15. Live Tickets & Support */}
          {activeModule === 'support' && (
            <div className="bg-white border border-gray-150 rounded-3xl p-5 md:p-6 shadow-3xs space-y-6">
              <div className="border-b border-gray-100 pb-3">
                <h3 className="font-display font-black text-gray-900 text-sm">Disputes & Customer Tickets</h3>
                <p className="text-[10px] text-gray-400 font-bold uppercase mt-0.5">Solve driver, merchant, and client issues through interactive tickets</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                
                {/* Tickets list */}
                <div className="md:col-span-1 space-y-2 max-h-[400px] overflow-y-auto">
                  {complaints.map(t => (
                    <button
                      key={t.id}
                      onClick={() => setActiveTicketId(t.id)}
                      className={`w-full text-left p-3 rounded-xl border transition-all space-y-1 ${
                        activeTicketId === t.id
                          ? 'bg-red-50 border-red-200 shadow-3xs'
                          : 'bg-white border-gray-150 hover:bg-gray-50'
                      }`}
                    >
                      <div className="flex justify-between items-center">
                        <span className="text-[10px] font-black text-red-600 tracking-wider font-mono">{t.id}</span>
                        <span className={`text-[8.5px] px-1.5 py-0.5 rounded font-black uppercase ${
                          t.status === 'open' ? 'bg-red-100 text-red-700 animate-pulse' : 'bg-gray-100 text-gray-500'
                        }`}>{t.status}</span>
                      </div>
                      <p className="text-xs font-black text-gray-900">{t.user}</p>
                      <p className="text-[10px] text-gray-500 font-semibold truncate">{t.issue}</p>
                    </button>
                  ))}
                </div>

                {/* Ticket Chat Panel */}
                <div className="md:col-span-2">
                  {activeTicketId ? (
                    <div className="border border-gray-150 rounded-2xl p-4 min-h-[300px] flex flex-col justify-between bg-slate-50">
                      <div className="space-y-4 flex-1 overflow-y-auto max-h-[250px] pr-1.5">
                        <div className="border-b border-gray-200 pb-2">
                          <span className="text-[9px] font-black uppercase text-gray-400">Issue Description</span>
                          <p className="text-xs font-semibold text-gray-700">
                            {(complaints.find(c => c.id === activeTicketId) || {}).issue}
                          </p>
                        </div>
                        {((complaints.find(c => c.id === activeTicketId) || {}).messages || []).map((msg: any, mIdx: number) => (
                          <div key={mIdx} className={`flex ${msg.sender === 'admin' ? 'justify-end' : 'justify-start'}`}>
                            <div className={`p-2.5 rounded-xl text-xs max-w-[80%] leading-relaxed ${
                              msg.sender === 'admin' ? 'bg-red-500 text-white font-semibold' : 'bg-white text-gray-800 border'
                            }`}>
                              {msg.text}
                            </div>
                          </div>
                        ))}
                      </div>

                      <form onSubmit={handleSendSupportMessage} className="mt-4 flex gap-2">
                        <input
                          type="text"
                          required
                          value={supportMessageText}
                          onChange={(e) => setSupportMessageText(e.target.value)}
                          placeholder="Type reply or resolution notes..."
                          className="flex-1 bg-white border border-gray-200 rounded-xl px-3 py-2 text-xs font-semibold outline-none"
                        />
                        <button type="submit" className="bg-red-500 hover:bg-red-600 text-white text-xs font-black px-4 rounded-xl">
                          Resolve
                        </button>
                      </form>
                    </div>
                  ) : (
                    <div className="border border-dashed border-gray-150 rounded-2xl p-8 text-center text-gray-400 text-xs bg-gray-50/50 flex flex-col items-center justify-center min-h-[300px]">
                      <HelpCircle className="h-8 w-8 text-gray-300 mb-1" />
                      <p className="font-bold text-gray-600">No active ticket selected</p>
                      <p className="text-[10px] text-gray-400">Select any ticket from the left pane to resolve customer/partner disputes.</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* 16. Roles & Permissions (Super Admin Only) */}
          {activeModule === 'roles' && isAdminSuper && (
            <div className="bg-white border border-gray-150 rounded-3xl p-5 md:p-6 shadow-3xs space-y-6">
              <div className="border-b border-gray-100 pb-3">
                <h3 className="font-display font-black text-slate-900 text-sm">Employee Privileges & Security Roles</h3>
                <p className="text-[10px] text-gray-400 font-bold uppercase mt-0.5">Control administrative nodes, grant access, block administrative users</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* Staff list */}
                <div className="space-y-4">
                  <span className="text-[10px] text-gray-400 font-extrabold uppercase">Administrative Employees</span>
                  <div className="space-y-2.5">
                    {admins.map(adm => (
                      <div key={adm.id} className="border border-gray-150 p-3 rounded-2xl flex items-center justify-between hover:border-gray-300">
                        <div>
                          <p className="font-black text-slate-900">{adm.name}</p>
                          <p className="text-[10px] text-gray-400 uppercase font-mono">Rank: {adm.role}</p>
                        </div>
                        <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 text-[9px] rounded font-bold uppercase">Active Operator</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Permissions form */}
                <div className="bg-slate-50 border border-slate-100 rounded-2xl p-4 space-y-4">
                  <span className="text-[10px] text-gray-500 font-extrabold uppercase block">Grant Access privileges</span>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-gray-600">Access Database Console</span>
                      <input type="checkbox" defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-gray-600">Adjust Customer Wallets</span>
                      <input type="checkbox" defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-gray-600">Approve partner restaurants</span>
                      <input type="checkbox" defaultChecked />
                    </div>
                  </div>
                  <button
                    onClick={() => showToast('Privilege logs updated!')}
                    className="w-full bg-slate-850 hover:bg-slate-900 text-white font-black text-xs py-2 rounded-xl"
                  >
                    Deploy security policies
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* 17. Logs & Security (Super Admin Only) */}
          {activeModule === 'logs' && isAdminSuper && (
            <div className="space-y-6 animate-fadeIn">
              
              {/* MySQL DB Query Console */}
              <div className="bg-white border border-gray-150 rounded-3xl p-5 md:p-6 shadow-3xs space-y-4">
                <div className="border-b border-gray-100 pb-3 flex justify-between items-center">
                  <div>
                    <h3 className="font-display font-black text-gray-900 text-sm">Transactional SQL Command Center</h3>
                    <p className="text-[10px] text-gray-400 font-bold uppercase mt-0.5">Direct raw SQL manipulation interface over relational nodes</p>
                  </div>
                </div>
                <MySQLConsole initialData={initialDbData} onUpdateState={onUpdateState} />
              </div>

              {/* Security settings, database backups */}
              <div className="bg-white border border-gray-150 rounded-3xl p-5 md:p-6 shadow-3xs space-y-5">
                <div className="border-b border-gray-100 pb-3">
                  <h3 className="font-display font-black text-gray-900 text-sm">ERP Security, 2FA, Backup & Logs</h3>
                  <p className="text-[10px] text-gray-400 font-bold uppercase mt-0.5">Enforce Two-Factor Authentication across nodes, dump backup binaries</p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <button
                    onClick={() => showToast('Two-Factor Authentication policy enforced successfully!', 'info')}
                    className="bg-slate-50 border border-slate-200 hover:bg-slate-100 p-4 rounded-2xl text-center space-y-1"
                  >
                    <Sliders className="h-5 w-5 text-indigo-600 mx-auto" />
                    <p className="font-black text-xs text-slate-800">Enforce 2FA Mode</p>
                    <p className="text-[9px] text-gray-400">Force passcode verification</p>
                  </button>

                  <button
                    onClick={() => showToast('Database binary dump successfully exported to local storage!', 'success')}
                    className="bg-slate-50 border border-slate-200 hover:bg-slate-100 p-4 rounded-2xl text-center space-y-1"
                  >
                    <Database className="h-5 w-5 text-emerald-600 mx-auto" />
                    <p className="font-black text-xs text-slate-800">Backup DB Dump</p>
                    <p className="text-[9px] text-gray-400">Save complete binary records</p>
                  </button>

                  <button
                    onClick={() => showToast('All caches flushed. Relational tables verified.', 'success')}
                    className="bg-slate-50 border border-slate-200 hover:bg-slate-100 p-4 rounded-2xl text-center space-y-1"
                  >
                    <RefreshCw className="h-5 w-5 text-amber-600 mx-auto" />
                    <p className="font-black text-xs text-slate-800">Flush Memory Cache</p>
                    <p className="text-[9px] text-gray-400">Purge stale cache clusters</p>
                  </button>
                </div>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}
