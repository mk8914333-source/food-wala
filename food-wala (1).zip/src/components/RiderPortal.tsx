import React, { useState } from 'react';
import { Truck, Navigation, Compass, MapPin, CheckCircle2, UserCheck, AlertCircle } from 'lucide-react';
import { motion } from 'motion/react';
import { Order, Rider } from '../types';
import InteractiveMap from './InteractiveMap';
import TopRidersSection from './TopRidersSection';

interface RiderPortalProps {
  riderName: string;
  orders: Order[];
  onUpdateOrderStatus: (orderId: string, status: 'received' | 'preparing' | 'delivery' | 'delivered') => void;
  riders: Rider[];
}

export default function RiderPortal({
  riderName,
  orders,
  onUpdateOrderStatus,
  riders
}: RiderPortalProps) {
  // Orders eligible for delivery (i.e. 'preparing' meaning ready for dispatch, or 'delivery' which are active)
  const availableOrders = orders.filter(o => o.status === 'preparing' || o.status === 'delivery');
  const [activeDeliveryId, setActiveDeliveryId] = useState<string | null>(() => {
    const ongoing = orders.find(o => o.status === 'delivery');
    return ongoing ? ongoing.id : null;
  });

  const activeOrder = orders.find(o => o.id === activeDeliveryId);

  const handleClaimTicket = (orderId: string) => {
    setActiveDeliveryId(orderId);
    onUpdateOrderStatus(orderId, 'delivery');
  };

  const handleDelivered = (orderId: string) => {
    onUpdateOrderStatus(orderId, 'delivered');
    setActiveDeliveryId(null);
  };

  return (
    <div className="space-y-6 font-sans">
      {/* Banner */}
      <div className="bg-gradient-to-r from-amber-500 to-orange-600 text-white rounded-3xl p-6 shadow-md relative overflow-hidden">
        <div className="absolute top-0 right-0 p-4 opacity-10 pointer-events-none">
          <Truck className="h-32 w-32" />
        </div>
        <div className="relative">
          <span className="text-[10px] font-black uppercase tracking-wider bg-white/20 px-3 py-1 rounded-full">
            Rider Logistics Hub
          </span>
          <h2 className="font-display font-black text-2xl tracking-tight mt-2">{riderName}</h2>
          <p className="text-xs text-amber-100 font-medium mt-1">Accept local delivery tickets and speed warm meals to customer doorsteps.</p>
        </div>
      </div>

      <TopRidersSection riders={riders} />

      {/* Main Grid: Active ticket vs List */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left column: Live Tracking Navigation Panel */}
        <div className="lg:col-span-7 space-y-6">
          {activeOrder ? (
            <div className="bg-white border border-gray-150 rounded-3xl p-5 md:p-6 shadow-3xs space-y-5">
              <div className="flex items-center justify-between border-b border-gray-100 pb-3">
                <h3 className="font-display font-black text-gray-900 text-sm flex items-center gap-1.5">
                  <Navigation className="h-4 w-4 text-amber-500 animate-pulse" /> Active Ticket Navigation
                </h3>
                <span className="text-[10px] bg-amber-50 text-amber-700 font-black px-2.5 py-1 rounded-lg border border-amber-100/50">
                  {activeOrder.id}
                </span>
              </div>

              {/* Vector Map inside */}
              <InteractiveMap
                restaurantId="all"
                restaurantName={activeOrder.items[0]?.restaurantName || "Outlet"}
                customerAddress={activeOrder.address}
                orderStatus={activeOrder.status as 'received' | 'preparing' | 'delivery' | 'delivered'}
              />

              {/* Delivery coordinates summary */}
              <div className="bg-gray-50 border border-gray-100 rounded-2xl p-4 text-xs space-y-3 font-semibold text-gray-600">
                <div className="flex items-start gap-2.5">
                  <div className="bg-red-50 text-red-600 p-1.5 rounded-lg font-black text-[10px]">
                    FROM
                  </div>
                  <div>
                    <p className="text-[10px] text-gray-400 font-bold uppercase">Pickup Restaurant Counter</p>
                    <p className="text-gray-800 font-extrabold mt-0.5">{activeOrder.items[0]?.restaurantName}</p>
                  </div>
                </div>

                <div className="flex items-start gap-2.5">
                  <div className="bg-emerald-50 text-emerald-600 p-1.5 rounded-lg font-black text-[10px]">
                    TO
                  </div>
                  <div>
                    <p className="text-[10px] text-gray-400 font-bold uppercase">Customer Drop-off Location</p>
                    <p className="text-gray-800 font-extrabold mt-0.5">{activeOrder.address}</p>
                  </div>
                </div>

                <div className="flex justify-between items-center pt-2.5 border-t border-gray-200/50 text-gray-800">
                  <div>
                    <p className="text-[10px] text-gray-400 font-bold uppercase">Contact Customer</p>
                    <p className="font-extrabold mt-0.5">📞 {activeOrder.phone}</p>
                  </div>
                  
                  <button
                    onClick={() => handleDelivered(activeOrder.id)}
                    className="bg-emerald-500 hover:bg-emerald-600 text-white font-black text-xs px-4 py-2.5 rounded-xl transition-all shadow-sm cursor-pointer flex items-center gap-1"
                  >
                    Confirm Delivered <CheckCircle2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white border border-gray-150 rounded-3xl p-8 text-center shadow-3xs text-gray-400 text-xs">
              <Compass className="h-10 w-10 text-gray-300 mx-auto mb-3" />
              <p className="font-bold text-gray-500">No active delivery coordinate route.</p>
              <p className="text-[11px] text-gray-400 mt-1">Claim an active ticket from the dispatch board to start GPS coordinate driving simulation!</p>
            </div>
          )}
        </div>

        {/* Right column: Dispatch Tickets Board */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white border border-gray-150 rounded-3xl p-5 md:p-6 shadow-3xs space-y-4">
            <h3 className="font-display font-black text-gray-900 text-sm border-b border-gray-100 pb-3">
              Rider Ticket Board ({availableOrders.length})
            </h3>

            {availableOrders.length === 0 ? (
              <div className="p-8 text-center border-2 border-dashed border-gray-100 rounded-2xl text-gray-400 text-xs">
                ✨ No tickets ready right now. Keep this open or wait for clients to order!
              </div>
            ) : (
              <div className="space-y-3.5">
                {availableOrders.map((order) => {
                  const isActiveRiderOrder = order.id === activeDeliveryId;
                  return (
                    <div
                      key={order.id}
                      className={`p-4 border rounded-2xl transition-all space-y-2.5 ${
                        isActiveRiderOrder
                          ? 'border-amber-500 bg-amber-50/10'
                          : 'border-gray-150 hover:border-gray-200 bg-white'
                      }`}
                    >
                      <div className="flex justify-between items-center">
                        <span className="font-mono font-bold text-xs bg-gray-100 text-gray-800 px-2 py-0.5 rounded-md">
                          {order.id}
                        </span>
                        <span className="text-[10px] text-gray-400 font-extrabold uppercase">
                          {order.status}
                        </span>
                      </div>

                      <div className="text-xs text-gray-600 font-semibold space-y-1">
                        <p>🏠 <span className="text-gray-800">{order.customerName}</span></p>
                        <p className="truncate">📍 {order.address}</p>
                        <p>🍲 {order.items[0]?.restaurantName}</p>
                      </div>

                      {!activeDeliveryId ? (
                        <button
                          onClick={() => handleClaimTicket(order.id)}
                          className="w-full bg-amber-500 hover:bg-amber-600 text-white font-bold py-2 rounded-xl text-xs transition-all cursor-pointer"
                        >
                          Accept Deliver Ticket
                        </button>
                      ) : isActiveRiderOrder ? (
                        <div className="text-center text-[10px] bg-amber-500 text-white font-black py-1.5 rounded-xl">
                          Ongoing Delivery
                        </div>
                      ) : null}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
