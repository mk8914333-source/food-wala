import React, { useState } from 'react';
import { ShoppingBag, Trash2, Plus, Minus, Ticket, Check, X, AlertCircle } from 'lucide-react';
import { CartItem, MenuItem, PromoCode, Restaurant } from '../types';
import { PROMO_CODES } from '../data';
import { motion, AnimatePresence } from 'motion/react';

interface CartPanelProps {
  cartItems: CartItem[];
  deliveryMethod: 'delivery' | 'pickup';
  setDeliveryMethod: (method: 'delivery' | 'pickup') => void;
  onAddToCart: (item: MenuItem) => void;
  onRemoveFromCart: (item: MenuItem) => void;
  onDeleteFromCart: (item: MenuItem) => void;
  appliedPromo: PromoCode | null;
  onApplyPromo: (code: string) => void;
  onRemovePromo: () => void;
  chefNotes: string;
  setChefNotes: (notes: string) => void;
  onCheckout: () => void;
  activeRestaurant: Restaurant | null;
}

export default function CartPanel({
  cartItems,
  deliveryMethod,
  setDeliveryMethod,
  onAddToCart,
  onRemoveFromCart,
  onDeleteFromCart,
  appliedPromo,
  onApplyPromo,
  onRemovePromo,
  chefNotes,
  setChefNotes,
  onCheckout,
  activeRestaurant
}: CartPanelProps) {
  const [promoInput, setPromoInput] = useState('');
  const [promoError, setPromoError] = useState('');

  // Calculations
  const subtotal = cartItems.reduce((acc, item) => acc + item.menuItem.price * item.quantity, 0);
  
  // Calculate delivery fee
  // If no items, delivery fee is 0
  // If pickup, delivery fee is 0
  // Else, use delivery fee of the active restaurant, or the first item's restaurant, or a default
  const getDeliveryFee = () => {
    if (cartItems.length === 0 || deliveryMethod === 'pickup') return 0;
    if (activeRestaurant) return activeRestaurant.deliveryFee;
    return 100; // Default delivery fee
  };
  const deliveryFee = getDeliveryFee();

  // Discount calculation
  const getDiscount = () => {
    if (!appliedPromo) return 0;
    if (appliedPromo.minSpend && subtotal < appliedPromo.minSpend) return 0;
    
    if (appliedPromo.discountType === 'fixed') {
      return appliedPromo.value;
    } else {
      return Math.round((subtotal * appliedPromo.value) / 100);
    }
  };
  const discount = getDiscount();
  const total = Math.max(0, subtotal + deliveryFee - discount);

  // Validate minimum order requirement
  const minOrderValue = activeRestaurant ? activeRestaurant.minOrder : 0;
  const isBelowMinOrder = subtotal > 0 && subtotal < minOrderValue;
  const remainingForMinOrder = minOrderValue - subtotal;

  const handleApplyPromo = (e: React.FormEvent) => {
    e.preventDefault();
    setPromoError('');
    const code = promoInput.trim().toUpperCase();
    
    if (!code) return;

    const match = PROMO_CODES.find((p) => p.code === code);
    if (!match) {
      setPromoError('Invalid promo code');
      return;
    }

    if (match.minSpend && subtotal < match.minSpend) {
      setPromoError(`Requires a minimum spend of Rs. ${match.minSpend}`);
      return;
    }

    onApplyPromo(code);
    setPromoInput('');
  };

  const handleQuickPromo = (code: string) => {
    setPromoError('');
    const match = PROMO_CODES.find((p) => p.code === code);
    if (match && match.minSpend && subtotal < match.minSpend) {
      setPromoError(`Requires Rs. ${match.minSpend} minimum order`);
      return;
    }
    onApplyPromo(code);
  };

  return (
    <div id="shopping-cart-panel" className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden flex flex-col h-full">
      {/* Title Header */}
      <div className="p-5 border-b border-gray-100 flex items-center justify-between bg-gray-50/50">
        <div className="flex items-center gap-2">
          <ShoppingBag className="h-5 w-5 text-red-500" />
          <h2 className="font-display font-bold text-lg text-gray-900">Your Basket</h2>
        </div>
        <span className="text-xs bg-red-100 text-red-600 font-bold px-2.5 py-1 rounded-full">
          {cartItems.reduce((acc, i) => acc + i.quantity, 0)} Items
        </span>
      </div>

      {cartItems.length === 0 ? (
        /* Empty State */
        <div className="flex-1 flex flex-col items-center justify-center p-8 text-center bg-white">
          <div className="h-16 w-16 bg-red-50 text-red-500 rounded-2xl flex items-center justify-center mb-4 animate-bounce">
            <ShoppingBag className="h-8 w-8" />
          </div>
          <h3 className="font-display font-bold text-gray-800 text-base">Your cart is empty</h3>
          <p className="text-xs text-gray-400 max-w-[200px] mt-2">
            Browse restaurants and add some mouthwatering dishes to your plate.
          </p>
        </div>
      ) : (
        /* Active Cart */
        <div className="flex-1 overflow-y-auto p-5 space-y-5 scrollbar-hide">
          {/* Delivery Method Selector Toggle */}
          <div className="flex bg-gray-100 p-1 rounded-2xl">
            <button
              onClick={() => setDeliveryMethod('delivery')}
              className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
                deliveryMethod === 'delivery'
                  ? 'bg-white text-gray-900 shadow-xs'
                  : 'text-gray-500 hover:text-gray-900'
              }`}
            >
              🚚 Delivery
            </button>
            <button
              onClick={() => setDeliveryMethod('pickup')}
              className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
                deliveryMethod === 'pickup'
                  ? 'bg-white text-gray-900 shadow-xs'
                  : 'text-gray-500 hover:text-gray-900'
              }`}
            >
              🎒 Self Pickup
            </button>
          </div>

          {/* Cart Item Cards */}
          <div className="space-y-3">
            <AnimatePresence initial={false}>
              {cartItems.map((item) => (
                <motion.div
                  key={item.menuItem.id}
                  layout
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, x: -100 }}
                  className="flex items-center justify-between p-3 border border-gray-100/60 rounded-xl hover:bg-gray-50/40 transition-all"
                >
                  <div className="flex-1 min-w-0 pr-3">
                    <p className="text-xs font-bold text-gray-900 truncate">{item.menuItem.name}</p>
                    <p className="text-[10px] text-gray-400 font-semibold">{item.restaurantName}</p>
                    <p className="text-xs font-bold text-red-500 mt-1">Rs. {item.menuItem.price * item.quantity}</p>
                  </div>

                  <div className="flex items-center gap-3">
                    {/* Plus/Minus increment buttons */}
                    <div className="flex items-center bg-gray-100 rounded-lg p-0.5">
                      <button
                        onClick={() => onRemoveFromCart(item.menuItem)}
                        className="p-1 text-gray-500 hover:text-red-500 hover:bg-white rounded-md transition-all active:scale-90"
                      >
                        <Minus className="h-3 w-3" />
                      </button>
                      <span className="text-xs font-bold w-6 text-center text-gray-800">{item.quantity}</span>
                      <button
                        onClick={() => onAddToCart(item.menuItem)}
                        className="p-1 text-gray-500 hover:text-green-500 hover:bg-white rounded-md transition-all active:scale-90"
                      >
                        <Plus className="h-3 w-3" />
                      </button>
                    </div>

                    <button
                      onClick={() => onDeleteFromCart(item.menuItem)}
                      className="p-1.5 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>

          {/* Cooking Instructions Notes */}
          <div>
            <label className="block text-[11px] text-gray-400 font-bold uppercase tracking-wider mb-1">
              Chef Instructions Notes
            </label>
            <input
              type="text"
              placeholder="e.g. No mayo, extra napkins, make it spicy"
              value={chefNotes}
              onChange={(e) => setChefNotes(e.target.value)}
              className="w-full px-3 py-2 border border-gray-100 focus:border-red-500 focus:ring-1 focus:ring-red-100 rounded-xl text-xs outline-none transition-all placeholder-gray-400 text-gray-700"
            />
          </div>

          {/* Promo Code Application */}
          <div className="pt-2 border-t border-gray-50">
            <label className="block text-[11px] text-gray-400 font-bold uppercase tracking-wider mb-2">
              Promo Coupon Code
            </label>
            
            {appliedPromo ? (
              <div className="flex items-center justify-between bg-green-50 text-green-700 px-3 py-2 rounded-xl border border-green-200">
                <div className="flex items-center gap-2">
                  <Check className="h-4 w-4" />
                  <div>
                    <p className="text-xs font-bold">{appliedPromo.code} Applied</p>
                    <p className="text-[10px] text-green-600 font-medium">Rs. {discount} discount</p>
                  </div>
                </div>
                <button
                  onClick={onRemovePromo}
                  className="p-1 hover:bg-green-100 text-green-700 rounded-md transition-all"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            ) : (
              <form onSubmit={handleApplyPromo} className="flex gap-2">
                <input
                  type="text"
                  placeholder="Promo Code"
                  value={promoInput}
                  onChange={(e) => {
                    setPromoInput(e.target.value);
                    setPromoError('');
                  }}
                  className="flex-1 px-3 py-2 border border-gray-100 focus:border-red-500 focus:ring-1 focus:ring-red-100 rounded-xl text-xs outline-none transition-all placeholder-gray-400 uppercase text-gray-700"
                />
                <button
                  type="submit"
                  className="bg-gray-900 hover:bg-black text-white text-xs font-bold px-4 py-2 rounded-xl active:scale-95 transition-all"
                >
                  Apply
                </button>
              </form>
            )}
            
            {promoError && (
              <p className="text-[10px] text-red-500 font-semibold mt-1 flex items-center gap-1">
                <AlertCircle className="h-3 w-3" /> {promoError}
              </p>
            )}

            {/* Quick-Apply Suggested Codes */}
            {!appliedPromo && (
              <div className="mt-2.5 space-y-1.5">
                <p className="text-[10px] text-gray-400 font-semibold">SUGGESTED COUPONS FOR YOU</p>
                <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-hide">
                  {PROMO_CODES.map((promo) => {
                    const isDisabled = promo.minSpend ? subtotal < promo.minSpend : false;
                    return (
                      <button
                        key={promo.code}
                        type="button"
                        onClick={() => !isDisabled && handleQuickPromo(promo.code)}
                        className={`text-[10px] px-2.5 py-1 rounded-lg border font-bold flex items-center gap-1 whitespace-nowrap transition-all ${
                          isDisabled
                            ? 'bg-gray-50 border-gray-100 text-gray-400 cursor-not-allowed'
                            : 'bg-white border-dashed border-red-200 text-red-600 hover:bg-red-50 hover:border-red-300'
                        }`}
                      >
                        <Ticket className="h-2.5 w-2.5" />
                        <span>{promo.code}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Bill summary and final CTA section */}
      {cartItems.length > 0 && (
        <div className="p-5 border-t border-gray-100 bg-gray-50/50 space-y-3">
          <div className="space-y-1.5 text-xs text-gray-600 font-semibold">
            <div className="flex justify-between">
              <span className="text-gray-400">Subtotal:</span>
              <span>Rs. {subtotal}</span>
            </div>
            
            {deliveryMethod === 'delivery' && (
              <div className="flex justify-between">
                <span className="text-gray-400">Delivery Fee:</span>
                <span>Rs. {deliveryFee}</span>
              </div>
            )}
            
            {appliedPromo && discount > 0 && (
              <div className="flex justify-between text-green-600">
                <span>Coupon Discount:</span>
                <span>- Rs. {discount}</span>
              </div>
            )}

            <div className="flex justify-between text-gray-900 font-extrabold text-sm pt-2 border-t border-gray-100">
              <span>Grand Total:</span>
              <span className="text-red-500 font-display">Rs. {total}</span>
            </div>
          </div>

          {/* Minimum order warnings */}
          {isBelowMinOrder && (
            <div className="bg-amber-50 text-amber-700 p-2.5 rounded-xl text-[10px] font-semibold border border-amber-200 flex items-start gap-1.5">
              <AlertCircle className="h-3.5 w-3.5 mt-0.5 text-amber-500 flex-shrink-0" />
              <div>
                <span>Minimum order for {activeRestaurant?.name || 'this restaurant'} is Rs. {minOrderValue}. </span>
                <span className="underline block mt-0.5">Please add Rs. {remainingForMinOrder} more to checkout.</span>
              </div>
            </div>
          )}

          <button
            onClick={onCheckout}
            disabled={isBelowMinOrder}
            id="checkout-trigger"
            className={`w-full py-3 rounded-xl font-bold text-sm tracking-tight shadow-md flex items-center justify-center gap-1.5 transition-all ${
              isBelowMinOrder
                ? 'bg-gray-300 text-gray-500 cursor-not-allowed shadow-none'
                : 'bg-red-500 hover:bg-red-600 text-white shadow-red-500/10 hover:shadow-red-500/20 active:scale-95 cursor-pointer'
            }`}
          >
            Checkout (Rs. {total})
          </button>
        </div>
      )}
    </div>
  );
}
