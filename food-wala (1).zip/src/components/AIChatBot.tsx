import React, { useState, useRef, useEffect } from 'react';
import { MessageSquare, X, Send, Bot, Sparkles, ShoppingBag, MapPin, HelpCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Restaurant } from '../types';

interface AIChatBotProps {
  cart: any[];
  restaurants: Restaurant[];
  activeOrder: any;
  onAddToCart: (itemId: string, quantity: number) => void;
  onRegisterComplaint: (notes: string) => void;
  showToast: (msg: string, type: 'success' | 'error' | 'info') => void;
}

interface Message {
  role: 'user' | 'model';
  text: string;
  isActionTriggered?: boolean;
  actions?: any[];
  groundingMetadata?: any;
}

export default function AIChatBot({
  cart,
  restaurants,
  activeOrder,
  onAddToCart,
  onRegisterComplaint,
  showToast,
}: AIChatBotProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [activeBotTab, setActiveBotTab] = useState<'support' | 'maps'>('support');
  
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'model',
      text: 'السلام علیکم! 🌸 میں ہوں آپ کا **FoodWala AI اسسٹنٹ**۔\n\nمیں آپ کے لیے کھانا تلاش کر سکتا ہوں، آرڈر لینے میں مدد کر سکتا ہوں، آپ کے آرڈر کا اسٹیٹس بتا سکتا ہوں یا شکایات درج کر سکتا ہوں۔ بتائیں آج آپ کیا کھانا پسند کریں گے؟ 🍕🍔',
    },
  ]);

  const [mapsMessages, setMapsMessages] = useState<Message[]>([
    {
      role: 'model',
      text: 'السلام علیکم! 🗺️ میں ہوں آپ کا **Google Maps فوڈ گائیڈ**۔\n\nپاکستان کے کسی بھی شہر (جیسے لاہور، کراچی، اسلام آباد) میں بہترین کھانے کی جگہیں، مشہور ریسٹورنٹس اور اسٹریٹ فوڈ تلاش کرنے کے لیے مجھ سے پوچھیں! 📍',
    },
  ]);

  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  const [coords, setCoords] = useState<{ latitude: number | null; longitude: number | null }>({
    latitude: null,
    longitude: null,
  });

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setCoords({
            latitude: pos.coords.latitude,
            longitude: pos.coords.longitude,
          });
        },
        (err) => {
          console.log('Geolocation state or permission denied, using default Lahore coordinates.', err);
        }
      );
    }
  }, []);

  const currentMessages = activeBotTab === 'support' ? messages : mapsMessages;

  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [currentMessages, isOpen, activeBotTab]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMsg = input.trim();
    setInput('');

    if (activeBotTab === 'support') {
      setMessages((prev) => [...prev, { role: 'user', text: userMsg }]);
      setIsLoading(true);
      try {
        let customInstructions = '';
        try {
          const saved = localStorage.getItem('foodwala_system_settings');
          if (saved) {
            const parsed = JSON.parse(saved);
            customInstructions = parsed.customAiInstruction || '';
          }
        } catch (err) {}

        const response = await fetch('/api/customer-bot', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            message: userMsg,
            history: messages.map((m) => ({ role: m.role, text: m.text })),
            cart,
            restaurants,
            activeOrder,
            customAiInstruction: customInstructions,
          }),
        });

        if (!response.ok) throw new Error('Failed to reach AI server');

        const data = await response.json();
        const botReply = data.reply || "معذرت، میں آپ کی بات سمجھ نہیں پایا۔ دوبارہ کوشش کریں۔";
        const actions = data.actions || [];

        setMessages((prev) => [
          ...prev,
          { role: 'model', text: botReply, actions },
        ]);

        if (actions && actions.length > 0) {
          actions.forEach((act: any) => {
            if (act.type === 'add_to_cart') {
              onAddToCart(act.itemId, act.quantity || 1);
              showToast(`🛒 Added ${act.itemName || 'Item'} to Cart via AI Assistant!`, 'success');
            } else if (act.type === 'register_complaint') {
              onRegisterComplaint(act.notes || userMsg);
              showToast('⚠️ شکایت درج کر لی گئی ہے! کسٹمر سپورٹ جلد رابطہ کرے گی۔', 'info');
            }
          });
        }
      } catch (err) {
        console.error(err);
        setMessages((prev) => [
          ...prev,
          { role: 'model', text: '⚠️ سرور سے رابطہ کرنے میں مسئلہ پیش آ رہا ہے۔ براہ کرم یقینی بنائیں کہ آپ کا انٹرنیٹ کام کر رہا ہے یا کسٹمر سروس سے رجوع کریں۔' },
        ]);
      } finally {
        setIsLoading(false);
      }
    } else {
      setMapsMessages((prev) => [...prev, { role: 'user', text: userMsg }]);
      setIsLoading(true);
      try {
        const response = await fetch('/api/maps-bot', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            message: userMsg,
            latitude: coords.latitude,
            longitude: coords.longitude,
          }),
        });

        if (!response.ok) throw new Error('Failed to reach AI server');

        const data = await response.json();
        const botReply = data.reply || "معذرت، گوگل میپس سے معلومات حاصل نہیں ہو سکیں۔";
        const groundingMetadata = data.groundingMetadata || null;

        setMapsMessages((prev) => [
          ...prev,
          { role: 'model', text: botReply, groundingMetadata },
        ]);
      } catch (err) {
        console.error(err);
        setMapsMessages((prev) => [
          ...prev,
          { role: 'model', text: '⚠️ گوگل میپس ڈیٹا حاصل کرنے میں مسئلہ ہو رہا ہے۔' },
        ]);
      } finally {
        setIsLoading(false);
      }
    }
  };

  const handleQuickPrompt = (prompt: string) => {
    setInput(prompt);
  };

  return (
    <div className="fixed bottom-6 right-6 z-40 font-sans">
      <AnimatePresence>
        {/* Chat Window */}
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 30 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 30 }}
            className="bg-white rounded-3xl shadow-2xl border border-gray-150 w-[380px] h-[580px] flex flex-col overflow-hidden mb-4"
          >
            {/* Header */}
            <div className="bg-gradient-to-r from-red-500 to-rose-600 p-4 text-white flex items-center justify-between shadow-md">
              <div className="flex items-center gap-2.5">
                <div className="h-10 w-10 bg-white/20 rounded-2xl flex items-center justify-center backdrop-blur-md">
                  <Bot className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h3 className="font-display font-black text-xs uppercase tracking-wider text-red-100">AI Assistant Hub</h3>
                  <h4 className="font-display font-black text-sm flex items-center gap-1">
                    FoodWala Assistant AI
                    <Sparkles className="h-3.5 w-3.5 text-yellow-300 fill-yellow-300" />
                  </h4>
                </div>
              </div>
              <button
                onClick={() => setIsOpen(false)}
                className="p-1.5 hover:bg-white/10 rounded-full transition-all cursor-pointer"
              >
                <X className="h-5 w-5 text-white" />
              </button>
            </div>

            {/* Tabs Switcher */}
            <div className="flex bg-gray-100 p-1 mx-4 mt-3 rounded-2xl border border-gray-200/50">
              <button
                onClick={() => {
                  setActiveBotTab('support');
                  setInput('');
                }}
                className={`flex-1 py-1.5 rounded-xl text-[11px] font-extrabold uppercase tracking-wider transition-all flex items-center justify-center gap-1 cursor-pointer ${
                  activeBotTab === 'support' ? 'bg-white text-red-600 shadow-3xs' : 'text-gray-500 hover:text-gray-800'
                }`}
              >
                <Bot className="h-3.5 w-3.5" /> Support Bot
              </button>
              <button
                onClick={() => {
                  setActiveBotTab('maps');
                  setInput('');
                }}
                className={`flex-1 py-1.5 rounded-xl text-[11px] font-extrabold uppercase tracking-wider transition-all flex items-center justify-center gap-1 cursor-pointer ${
                  activeBotTab === 'maps' ? 'bg-white text-indigo-600 shadow-3xs' : 'text-gray-500 hover:text-gray-800'
                }`}
              >
                <MapPin className="h-3.5 w-3.5 text-indigo-500" /> Maps Guide
              </button>
            </div>

            {/* Chat Messages */}
            <div className="flex-1 overflow-y-auto p-4 bg-gray-50/50 space-y-4">
              {currentMessages.map((msg, index) => (
                <div
                  key={index}
                  className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[85%] rounded-2xl p-3.5 text-xs leading-relaxed ${
                      msg.role === 'user'
                        ? 'bg-red-500 text-white font-semibold rounded-br-xs shadow-md shadow-red-500/15'
                        : 'bg-white text-gray-800 border border-gray-150 rounded-bl-xs shadow-3xs'
                    }`}
                  >
                    {/* Render Text as simple formatted lines */}
                    <p className="whitespace-pre-line font-medium text-right" dir="auto">
                      {msg.text}
                    </p>

                    {/* Show automated actions if triggered (Support Bot) */}
                    {activeBotTab === 'support' && msg.actions && msg.actions.length > 0 && (
                      <div className="mt-2.5 pt-2 border-t border-gray-100 flex flex-col gap-1.5">
                        {msg.actions.map((act, aIdx) => (
                          <div
                            key={aIdx}
                            className="bg-emerald-50 border border-emerald-100 text-emerald-800 rounded-lg p-2 flex items-center gap-2 font-bold text-[10px]"
                          >
                            <ShoppingBag className="h-3.5 w-3.5 text-emerald-600" />
                            <span>
                              {act.type === 'add_to_cart'
                                ? `Added ${act.itemName || 'Item'} to Cart!`
                                : 'Registered Complaint Ticket!'}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Show Google Maps places list if metadata exists (Maps Guide) */}
                    {msg.groundingMetadata && (
                      <div className="mt-3 pt-3 border-t border-gray-150 space-y-2">
                        <div className="text-[10px] font-black uppercase text-indigo-500 flex items-center gap-1">
                          <MapPin className="h-3 w-3" />
                          <span>Google Maps Places Found</span>
                        </div>
                        <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                          {msg.groundingMetadata.groundingChunks?.map((chunk: any, cIdx: number) => {
                            const mapInfo = chunk.web || chunk.maps;
                            if (!mapInfo || !mapInfo.uri) return null;
                            return (
                              <a
                                key={cIdx}
                                href={mapInfo.uri}
                                target="_blank"
                                rel="referrer"
                                className="block bg-indigo-50/50 hover:bg-indigo-50 border border-indigo-100 rounded-xl p-2.5 transition-all text-left"
                              >
                                <div className="flex items-center justify-between gap-1.5">
                                  <span className="font-extrabold text-indigo-950 text-[11px] leading-tight">
                                    {mapInfo.title || "View Location"}
                                  </span>
                                  <span className="text-[9px] bg-indigo-200 text-indigo-800 px-1.5 py-0.5 rounded-md font-bold uppercase shrink-0">
                                    Maps
                                  </span>
                                </div>
                                {chunk.maps?.placeAnswerSources?.reviewSnippets?.[0]?.text && (
                                  <p className="text-[9.5px] text-gray-500 mt-1 italic leading-relaxed">
                                    "{chunk.maps.placeAnswerSources.reviewSnippets[0].text}"
                                  </p>
                                )}
                              </a>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              ))}

              {isLoading && (
                <div className="flex justify-start">
                  <div className="bg-white border border-gray-150 rounded-2xl rounded-bl-xs p-3 flex items-center gap-1.5 shadow-3xs">
                    <span className="h-1.5 w-1.5 bg-red-400 rounded-full animate-bounce [animation-delay:-0.3s]" />
                    <span className="h-1.5 w-1.5 bg-red-500 rounded-full animate-bounce [animation-delay:-0.15s]" />
                    <span className="h-1.5 w-1.5 bg-red-600 rounded-full animate-bounce" />
                  </div>
                </div>
              )}

              <div ref={chatEndRef} />
            </div>

            {/* Quick Prompts (Support Bot) */}
            {activeBotTab === 'support' && currentMessages.length === 1 && (
              <div className="px-4 py-2 bg-gray-50 flex gap-1.5 overflow-x-auto border-t border-gray-100 scrollbar-none">
                <button
                  onClick={() => handleQuickPrompt('کچھ اچھا کھانے کا مشورہ دیں؟ 🍕')}
                  className="bg-white border border-gray-150 text-gray-700 hover:border-red-500 hover:text-red-500 text-[10px] font-bold px-3 py-1.5 rounded-full whitespace-nowrap transition-all cursor-pointer"
                >
                  کھانے کا مشورہ 🍕
                </button>
                <button
                  onClick={() => handleQuickPrompt('میرا آرڈر کس جگہ ہے؟ 🛵')}
                  className="bg-white border border-gray-150 text-gray-700 hover:border-red-500 hover:text-red-500 text-[10px] font-bold px-3 py-1.5 rounded-full whitespace-nowrap transition-all cursor-pointer"
                >
                  آرڈر اسٹیٹس 🛵
                </button>
                <button
                  onClick={() => handleQuickPrompt('Biryani House کی Biryani کتنے کی ہے؟')}
                  className="bg-white border border-gray-150 text-gray-700 hover:border-red-500 hover:text-red-500 text-[10px] font-bold px-3 py-1.5 rounded-full whitespace-nowrap transition-all cursor-pointer"
                >
                  بریانی کی قیمت؟ 🍚
                </button>
              </div>
            )}

            {/* Quick Prompts (Maps Guide) */}
            {activeBotTab === 'maps' && currentMessages.length === 1 && (
              <div className="px-4 py-2 bg-gray-50 flex gap-1.5 overflow-x-auto border-t border-gray-100 scrollbar-none">
                <button
                  onClick={() => handleQuickPrompt('Find top pizza spots on Mall Road Lahore')}
                  className="bg-white border border-gray-150 text-gray-700 hover:border-indigo-500 hover:text-indigo-500 text-[10px] font-bold px-3 py-1.5 rounded-full whitespace-nowrap transition-all cursor-pointer"
                >
                  Pizza Mall Road Lahore 🍕
                </button>
                <button
                  onClick={() => handleQuickPrompt('Best biryani places in Karachi')}
                  className="bg-white border border-gray-150 text-gray-700 hover:border-indigo-500 hover:text-indigo-500 text-[10px] font-bold px-3 py-1.5 rounded-full whitespace-nowrap transition-all cursor-pointer"
                >
                  Karachi Biryani 🍚
                </button>
                <button
                  onClick={() => handleQuickPrompt('Famous dessert shops near DHA Lahore')}
                  className="bg-white border border-gray-150 text-gray-700 hover:border-indigo-500 hover:text-indigo-500 text-[10px] font-bold px-3 py-1.5 rounded-full whitespace-nowrap transition-all cursor-pointer"
                >
                  DHA Desserts 🍰
                </button>
              </div>
            )}

            {/* Input Form */}
            <form onSubmit={handleSend} className="p-3 border-t border-gray-100 flex items-center gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={
                  activeBotTab === 'support'
                    ? 'AI سے پوچھیں (مثلاً: Zinger add kardo)...'
                    : 'لاہور، کراچی یا اسلام آباد کے ریسٹورنٹس تلاش کریں...'
                }
                className={`flex-1 bg-gray-50 border border-gray-150 rounded-2xl px-4 py-2.5 text-xs font-semibold outline-none focus:bg-white transition-all text-right ${
                  activeBotTab === 'maps' ? 'focus:border-indigo-500' : 'focus:border-red-500'
                }`}
                dir="rtl"
              />
              <button
                type="submit"
                disabled={!input.trim() || isLoading}
                className={`text-white p-2.5 rounded-2xl transition-all shadow-md cursor-pointer ${
                  activeBotTab === 'maps'
                    ? 'bg-indigo-600 hover:bg-indigo-700 shadow-indigo-600/15'
                    : 'bg-red-500 hover:bg-red-600 shadow-red-500/15'
                }`}
              >
                <Send className="h-4 w-4" />
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Floating Button */}
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setIsOpen(!isOpen)}
        className="bg-gradient-to-r from-red-500 to-rose-600 text-white rounded-full p-4 shadow-xl flex items-center justify-center relative cursor-pointer group"
      >
        <MessageSquare className="h-6 w-6" />
        <span className="absolute right-full mr-3 bg-gray-900 text-white text-[10px] font-bold px-2.5 py-1 rounded-lg opacity-0 group-hover:opacity-100 transition-all shadow-md whitespace-nowrap pointer-events-none">
          FoodWala Assistant AI
        </span>
        <span className="absolute -top-1 -right-1 flex h-3.5 w-3.5">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-yellow-400 opacity-75" />
          <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-yellow-500 border border-white" />
        </span>
      </motion.button>
    </div>
  );
}
