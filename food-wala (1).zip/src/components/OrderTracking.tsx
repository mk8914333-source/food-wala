import React, { useEffect, useState } from 'react';
import { CheckCircle2, Clock, MapPin, Phone, User, ShoppingBag, ArrowRight, Truck, Check, ShieldAlert, XCircle, MessageCircle, Send } from 'lucide-react';
import { Order } from '../types';
import { motion } from 'motion/react';

interface OrderTrackingProps {
  order: Order;
  onClose: () => void;
}

const STAGES = [
  { id: 'received', title: 'Order Received', description: 'Your order has been acknowledged by Food Wala', icon: ShoppingBag },
  { id: 'preparing', title: 'Preparing Food', description: 'The chef is preparing your fresh, tasty food', icon: Clock },
  { id: 'delivery', title: 'Out for Delivery', description: 'Our rider is speeding to your location', icon: Truck },
  { id: 'delivered', title: 'Delivered', description: 'Food has arrived! Enjoy your fresh meal', icon: CheckCircle2 }
];

export default function OrderTracking({ order, onClose }: OrderTrackingProps) {
  const [currentStage, setCurrentStage] = useState<'received' | 'preparing' | 'delivery' | 'delivered'>(
    order.status === 'payment_verification' || order.status === 'payment_rejected' ? 'received' : (order.status as any) || 'received'
  );
  const [timeLeft, setTimeLeft] = useState(25 * 60); // 25 minutes in seconds

  useEffect(() => {
    // Only simulate tracking transitions if order is approved and NOT in verification/rejected state
    if (order.status === 'payment_verification' || order.status === 'payment_rejected') {
      return;
    }

    // Set initial stage based on real status
    const initialStage = order.status === 'paid' ? 'received' : order.status;
    if (initialStage && ['received', 'preparing', 'delivery', 'delivered'].includes(initialStage)) {
      setCurrentStage(initialStage as any);
    }

    // 1. Simulate stage transition
    const timers = [
      setTimeout(() => setCurrentStage('preparing'), 7000),   // After 7s, start preparing
      setTimeout(() => setCurrentStage('delivery'), 18000),   // After 18s, out for delivery
      setTimeout(() => setCurrentStage('delivered'), 32000)   // After 32s, delivered
    ];

    // 2. Count down timer
    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 0) {
          clearInterval(interval);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      timers.forEach(clearTimeout);
      clearInterval(interval);
    };
  }, [order.status]);

  // Format seconds to MM:SS
  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remainingSecs = secs % 60;
    return `${mins.toString().padStart(2, '0')}:${remainingSecs.toString().padStart(2, '0')}`;
  };

  const getStageIndex = (stageId: string) => {
    return STAGES.findIndex((s) => s.id === stageId);
  };

  const activeStageIndex = getStageIndex(currentStage);
  const [messages, setMessages] = useState<{sender: 'customer' | 'rider', text: string}[]>([]);
  const [newMessage, setNewMessage] = useState('');

  const handleSendMessage = () => {
    if (!newMessage.trim()) return;
    setMessages([...messages, { sender: 'customer', text: newMessage }]);
    setNewMessage('');
    setTimeout(() => {
      setMessages(prev => [...prev, { sender: 'rider', text: 'Received, thank you!' }]);
    }, 1000);
  };

  return (
    <div id="order-tracking-view" className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden p-6 md:p-8 max-w-2xl mx-auto space-y-8">
      
      {/* 1. Payment Verification State Banner */}
      {order.status === 'payment_verification' && (
        <div className="bg-amber-50 rounded-2xl p-6 text-center border border-amber-200 relative overflow-hidden space-y-3">
          <div className="h-14 w-14 bg-amber-500 text-white rounded-full flex items-center justify-center mb-1 mx-auto shadow-md">
            <Clock className="h-7 w-7 animate-spin" />
          </div>
          <h2 className="font-display font-black text-xl text-amber-900">Payment Verification Pending</h2>
          <p className="text-xs text-amber-700 font-semibold max-w-md mx-auto leading-relaxed">
            Your payment receipt has been submitted to the Admin. Please wait while our team verifies your mobile wallet transaction details.
          </p>
          <div className="bg-white/80 p-3 rounded-xl border border-amber-100 max-w-sm mx-auto text-left text-xs font-semibold text-amber-905 space-y-1 font-mono">
            <div><span className="text-gray-400">Method:</span> <span className="text-gray-900 font-bold uppercase">{order.paymentMethod}</span></div>
            <div><span className="text-gray-400">Transaction ID:</span> <span className="text-red-600 font-black">{order.transactionId}</span></div>
            <div><span className="text-gray-400">Amount Paid:</span> <span className="text-gray-900">Rs. {order.amountPaid?.toLocaleString()}</span></div>
          </div>
        </div>
      )}

      {/* 2. Payment Rejected State Banner */}
      {order.status === 'payment_rejected' && (
        <div className="bg-red-50 rounded-2xl p-6 text-center border border-red-200 relative overflow-hidden space-y-3">
          <div className="h-14 w-14 bg-red-500 text-white rounded-full flex items-center justify-center mb-1 mx-auto shadow-md">
            <XCircle className="h-7 w-7" />
          </div>
          <h2 className="font-display font-black text-xl text-red-900">Payment Rejected</h2>
          <p className="text-xs text-red-700 font-semibold max-w-md mx-auto leading-relaxed">
            Your payment receipt was rejected by the Admin. Please check your transaction details or contact support at <span className="font-bold underline text-red-800">0330-8241277</span>.
          </p>
          <div className="bg-white/80 p-3 rounded-xl border border-red-100 max-w-sm mx-auto text-left text-xs font-semibold text-red-950 space-y-1 font-mono">
            <div><span className="text-gray-400">Transaction ID:</span> <span className="text-red-600 font-black">{order.transactionId}</span></div>
            <div><span className="text-gray-400">Status:</span> <span className="text-red-700 font-bold uppercase">Rejected / Unverified</span></div>
          </div>
        </div>
      )}

      {/* 3. Normal Progress Banner */}
      {order.status !== 'payment_verification' && order.status !== 'payment_rejected' && (
        <div className="bg-red-50 rounded-2xl p-6 text-center border border-red-100 relative overflow-hidden">
          {currentStage === 'delivered' ? (
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="flex flex-col items-center justify-center"
            >
              <div className="h-16 w-16 bg-green-500 text-white rounded-full flex items-center justify-center mb-3 shadow-lg">
                <Check className="h-8 w-8 stroke-[3]" />
              </div>
              <h2 className="font-display font-extrabold text-2xl text-gray-900">Order Delivered!</h2>
              <p className="text-xs text-gray-500 font-semibold mt-1">We hope you enjoy your warm, delicious Food Wala meal!</p>
            </motion.div>
          ) : (
            <div className="flex flex-col items-center">
              <span className="text-xs font-bold text-red-600 bg-red-100 px-3 py-1 rounded-full uppercase tracking-wider animate-pulse">
                Preparing & Delivering
              </span>
              <span className="font-mono font-extrabold text-4xl text-red-600 tracking-tight mt-2 block">
                {formatTime(timeLeft)}
              </span>
              <p className="text-xs text-gray-400 font-semibold mt-1">Our rider is speeding to your location</p>
            </div>
          )}
        </div>
      )}

      {/* Horizontal Progress Bar */}
      {order.status !== 'payment_verification' && order.status !== 'payment_rejected' && (
        <div className="flex items-center justify-between w-full mb-10 px-2">
          {STAGES.map((stage, idx) => {
            const isCompleted = idx <= activeStageIndex;
            const titles = {
              received: 'Received',
              preparing: 'Preparing',
              delivery: 'Delivery',
              delivered: 'Delivered'
            };
            return (
              <React.Fragment key={stage.id}>
                <div className={`relative flex flex-col items-center ${idx <= activeStageIndex ? 'text-red-500' : 'text-gray-300'}`}>
                  <div className={`h-3 w-3 rounded-full border-2 ${isCompleted ? 'bg-red-500 border-red-500' : 'bg-white border-gray-300'}`} />
                  <span className="text-[9px] font-bold mt-2 absolute top-4 whitespace-nowrap">{titles[stage.id as keyof typeof titles]}</span>
                </div>
                {idx < STAGES.length - 1 && (
                  <div className={`h-0.5 flex-1 mx-1 ${idx < activeStageIndex ? 'bg-red-500' : 'bg-gray-200'}`} />
                )}
              </React.Fragment>
            );
          })}
        </div>
      )}

      {/* Visual Tracking Steps (Only shown for non-verification/non-rejected states) */}
      {order.status !== 'payment_verification' && order.status !== 'payment_rejected' && (
        <div className="space-y-6">
          <h3 className="font-display font-bold text-gray-900 text-base border-b border-gray-50 pb-3">
            Live Delivery Status
          </h3>

          <div className="relative pl-8 space-y-8">
            {/* Tracking connecting line */}
            <div className="absolute top-3 bottom-3 left-4 w-0.5 bg-gray-100">
              <motion.div
                className="absolute top-0 left-0 w-full bg-red-500 origin-top"
                initial={{ height: '0%' }}
                animate={{ height: `${(activeStageIndex / (STAGES.length - 1)) * 100}%` }}
                transition={{ duration: 0.8 }}
              />
            </div>

            {STAGES.map((stage, idx) => {
              const isCompleted = idx < activeStageIndex;
              const isActive = idx === activeStageIndex;
              const Icon = stage.icon;

              return (
                <div key={stage.id} className="relative flex gap-4">
                  {/* Stage Indicator Node */}
                  <div className="absolute -left-[30px] top-0.5 z-10 flex items-center justify-center">
                    <div
                      className={`h-7 w-7 rounded-full flex items-center justify-center border-2 transition-all duration-300 ${
                        isCompleted
                          ? 'bg-red-500 border-red-500 text-white'
                          : isActive
                          ? 'bg-white border-red-500 text-red-500 animate-pulse'
                          : 'bg-white border-gray-200 text-gray-400'
                      }`}
                    >
                      {isCompleted ? (
                        <Check className="h-3.5 w-3.5 stroke-[3]" />
                      ) : (
                        <Icon className="h-3.5 w-3.5" />
                      )}
                    </div>
                  </div>

                  {/* Stage Title and Description */}
                  <div>
                    <h4
                      className={`text-sm font-bold transition-colors ${
                        isActive ? 'text-red-500' : isCompleted ? 'text-gray-900' : 'text-gray-400'
                      }`}
                    >
                      {stage.title}
                    </h4>
                    <p className="text-xs text-gray-500 mt-0.5 leading-relaxed">{stage.description}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Receipt Details Summary */}
      <div className="border-t border-gray-100 pt-6 space-y-4">
        <h3 className="font-display font-bold text-gray-900 text-base">Order Receipt</h3>
        
        {/* Customer info */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-gray-50 p-4 rounded-2xl border border-gray-100/60 text-xs font-semibold text-gray-600">
          <div className="flex items-start gap-2">
            <User className="h-4 w-4 text-red-500 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-[10px] text-gray-400 uppercase font-bold">Customer Name</p>
              <p className="text-gray-800 font-extrabold mt-0.5">{order.customerName}</p>
            </div>
          </div>
          <div className="flex items-start gap-2">
            <Phone className="h-4 w-4 text-red-500 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-[10px] text-gray-400 uppercase font-bold">Contact Phone</p>
              <p className="text-gray-800 font-extrabold mt-0.5">{order.phone}</p>
            </div>
          </div>
          <div className="flex items-start gap-2">
            <MapPin className="h-4 w-4 text-red-500 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-[10px] text-gray-400 uppercase font-bold">Address / Method</p>
              <p className="text-gray-800 font-extrabold mt-0.5 truncate max-w-[150px]" title={order.address}>
                {order.address}
              </p>
            </div>
          </div>
        </div>

        {/* Ordered items breakdown */}
        <div className="space-y-2.5">
          {order.items.map((item) => (
            <div key={item.menuItem.id} className="flex justify-between items-center text-xs">
              <div className="flex items-center gap-1.5 font-bold">
                <span className="text-gray-400">{item.quantity}x</span>
                <span className="text-gray-800">{item.menuItem.name}</span>
                <span className="text-[10px] text-gray-400 font-normal">({item.restaurantName})</span>
              </div>
              <span className="text-gray-700 font-semibold">Rs. {item.menuItem.price * item.quantity}</span>
            </div>
          ))}
          
          {/* Note from chef if any */}
          {order.notes && (
            <div className="text-[11px] bg-red-50/50 text-red-700 px-3 py-2 rounded-xl border border-red-100/50 mt-2 font-medium">
              <span className="font-bold">Instructions: </span>"{order.notes}"
            </div>
          )}

          {/* Pricing Summary */}
          <div className="border-t border-gray-100 pt-3 text-xs space-y-1 text-gray-600 font-semibold">
            <div className="flex justify-between">
              <span className="text-gray-400">Subtotal:</span>
              <span>Rs. {order.subtotal}</span>
            </div>
            {order.deliveryMethod === 'delivery' && (
              <div className="flex justify-between">
                <span className="text-gray-400">Delivery Fee:</span>
                <span>Rs. {order.deliveryFee}</span>
              </div>
            )}
            {order.discount > 0 && (
              <div className="flex justify-between text-green-600">
                <span>Coupon Applied:</span>
                <span>- Rs. {order.discount}</span>
              </div>
            )}
            <div className="flex justify-between text-gray-900 font-extrabold text-sm pt-2 border-t border-gray-100">
              <span>Paid via {order.paymentMethod || (order.deliveryMethod === 'pickup' ? 'Counter' : 'Cash on Delivery')}:</span>
              <span className="text-red-500 font-display font-black">Rs. {order.total}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Chat Section */}
      <div className="mt-8 border-t border-gray-100 pt-8">
        <h3 className="font-display font-bold text-lg text-gray-900 mb-4 flex items-center gap-2">
          <MessageCircle className="h-5 w-5 text-red-500" />
          Chat with Rider
        </h3>
        <div className="bg-gray-50 rounded-2xl p-4 h-48 overflow-y-auto mb-4 space-y-3">
          {messages.length === 0 && <p className="text-center text-gray-400 text-sm mt-16">No messages yet. Send a quick update!</p>}
          {messages.map((msg, i) => (
            <div key={i} className={`flex ${msg.sender === 'customer' ? 'justify-end' : 'justify-start'}`}>
              <div className={`px-4 py-2 rounded-2xl text-sm ${msg.sender === 'customer' ? 'bg-red-500 text-white rounded-br-none' : 'bg-white text-gray-800 rounded-bl-none shadow-sm'}`}>
                {msg.text}
              </div>
            </div>
          ))}
        </div>
        <div className="flex gap-2">
          <input
            type="text"
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
            placeholder="Type your message..."
            className="flex-1 bg-white border border-gray-200 px-4 py-3 rounded-xl text-sm focus:outline-none focus:border-red-500 transition-all"
          />
          <button 
            onClick={handleSendMessage}
            className="bg-red-500 text-white p-3 rounded-xl hover:bg-red-600 transition-colors"
          >
            <Send className="h-5 w-5" />
          </button>
        </div>
      </div>

      {/* Done / Reset Button */}
      <button
        onClick={onClose}
        className="w-full bg-red-500 hover:bg-red-600 text-white py-3 rounded-xl font-bold text-sm shadow-md shadow-red-500/10 hover:shadow-red-500/20 active:scale-95 transition-all flex items-center justify-center gap-1 cursor-pointer"
      >
        Order Something Else <ArrowRight className="h-4 w-4" />
      </button>
    </div>
  );
}
