import React, { useState } from 'react';
import { ChefHat, TrendingUp, Clock, PackageCheck, ToggleLeft, ToggleRight, ShieldAlert, Check, Coins, Plus, Trash2, Utensils, Upload, Image as ImageIcon } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Order, Restaurant, MenuItem } from '../types';

interface RestaurantPortalProps {
  restaurantId: string;
  restaurantName: string;
  orders: Order[];
  restaurants: Restaurant[];
  onUpdateOrderStatus: (orderId: string, status: 'received' | 'preparing' | 'delivery' | 'delivered') => void;
  onUpdateMenuPrice: (restaurantId: string, itemId: string, newPrice: number) => void;
  onUpdateState?: (table: 'restaurants', data: Restaurant[]) => void;
  lang?: 'en' | 'ur';
}

const PRESET_EMOJIS: Record<string, string[]> = {
  Main: ['🍛', '🍔', '🍕', '🍗', '🍜', '🍱', '🍣', '🌮', '🥩', '🍲', '🍝', '🍖'],
  Side: ['🍟', '🥪', '🍿', '🥗', '🥣', '🥟', '🍢', '🍠', '🥨', '🥯'],
  Beverage: ['🥤', '🍹', '☕', '🍺', '🥛', '🧋', '🍶', '🍵', '🥤'],
  Dessert: ['🍰', '🍦', '🍩', '🍪', '🧁', '🍫', '🥞', '🍮', '🍨', '🍯']
};

const PRESET_IMAGES: Record<string, { label: string; url: string }[]> = {
  Main: [
    { label: 'Butter Chicken', url: 'https://images.unsplash.com/photo-1565557623262-b51c2513a641?auto=format&fit=crop&w=400&q=80' },
    { label: 'Cheeseburger', url: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=400&q=80' },
    { label: 'Steaming Pizza', url: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=400&q=80' },
    { label: 'Pakistani Biryani', url: 'https://images.unsplash.com/photo-1633945274405-b6c8069047b0?auto=format&fit=crop&w=400&q=80' }
  ],
  Side: [
    { label: 'French Fries', url: 'https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&w=400&q=80' },
    { label: 'Crispy Samosas', url: 'https://images.unsplash.com/photo-1601050690597-df056fb4ce78?auto=format&fit=crop&w=400&q=80' },
    { label: 'Garlic Bread', url: 'https://images.unsplash.com/photo-1573145959142-ede042323db3?auto=format&fit=crop&w=400&q=80' },
    { label: 'Caesar Salad', url: 'https://images.unsplash.com/photo-1550304943-4f24f54ddde9?auto=format&fit=crop&w=400&q=80' }
  ],
  Beverage: [
    { label: 'Ice Cola', url: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?auto=format&fit=crop&w=400&q=80' },
    { label: 'Mint Margarita', url: 'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?auto=format&fit=crop&w=400&q=80' },
    { label: 'Chai Latte', url: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&w=400&q=80' },
    { label: 'Mango Lassi', url: 'https://images.unsplash.com/photo-1546173159-319807584405?auto=format&fit=crop&w=400&q=80' }
  ],
  Dessert: [
    { label: 'Fudge Cake', url: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=400&q=80' },
    { label: 'Waffles', url: 'https://images.unsplash.com/photo-1562376502-6f769499c886?auto=format&fit=crop&w=400&q=80' },
    { label: 'Gulab Jamun', url: 'https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&w=400&q=80' },
    { label: 'Vanilla Sundae', url: 'https://images.unsplash.com/photo-1563805042-7684c019e1cb?auto=format&fit=crop&w=400&q=80' }
  ]
};

const DEFAULT_CATEGORY_VISUALS: Record<string, { icon: string; image: string }> = {
  Main: {
    icon: '🍛',
    image: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=500&q=80'
  },
  Side: {
    icon: '🍟',
    image: 'https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&w=500&q=80'
  },
  Beverage: {
    icon: '🥤',
    image: 'https://images.unsplash.com/photo-1437419764061-2473afe69fc2?auto=format&fit=crop&w=500&q=80'
  },
  Dessert: {
    icon: '🍰',
    image: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=500&q=80'
  }
};

export default function RestaurantPortal({
  restaurantId,
  restaurantName,
  orders,
  restaurants,
  onUpdateOrderStatus,
  onUpdateMenuPrice,
  onUpdateState,
  lang = 'en'
}: RestaurantPortalProps) {
  const currentRest = restaurants.find(r => r.id === restaurantId);
  const restOrders = orders.filter(o => 
    o.items.some(item => item.restaurantId === restaurantId)
  );

  // Compute stats
  const totalRevenue = restOrders
    .filter(o => o.status === 'delivered')
    .reduce((sum, o) => sum + o.total, 0);

  const pendingCount = restOrders.filter(o => o.status === 'received' || o.status === 'paid').length;
  const preparingCount = restOrders.filter(o => o.status === 'preparing').length;

  const [editingPriceId, setEditingPriceId] = useState<string | null>(null);
  const [tempPrice, setTempPrice] = useState<number>(0);

  const handleUpdateCategoryVisual = (category: string, fields: { icon?: string; image?: string }) => {
    if (!currentRest) return;
    
    const existingVisuals = currentRest.categoryVisuals || {};
    const defaultVisual = DEFAULT_CATEGORY_VISUALS[category] || { icon: '🍽️', image: '' };
    
    const updatedVisuals = {
      ...existingVisuals,
      [category]: {
        icon: fields.icon !== undefined ? fields.icon : (existingVisuals[category]?.icon || defaultVisual.icon),
        image: fields.image !== undefined ? fields.image : (existingVisuals[category]?.image || defaultVisual.image)
      }
    };

    const updated = restaurants.map(r => {
      if (r.id === restaurantId) {
        return {
          ...r,
          categoryVisuals: updatedVisuals
        };
      }
      return r;
    });

    if (onUpdateState) {
      onUpdateState('restaurants', updated);
    }
  };

  const handleImageUpload = (category: string, file: File) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      if (typeof reader.result === 'string') {
        handleUpdateCategoryVisual(category, { image: reader.result });
      }
    };
    reader.readAsDataURL(file);
  };

  // New Restaurant Registration States
  const [isAddingRestaurant, setIsAddingRestaurant] = useState(false);
  const [newRestName, setNewRestName] = useState('');
  const [newRestCategory, setNewRestCategory] = useState('Fast Food');
  const [newRestPrepTime, setNewRestPrepTime] = useState('20-30 min');
  const [newRestMinOrder, setNewRestMinOrder] = useState('200');
  const [newRestDeliveryFee, setNewRestDeliveryFee] = useState('100');
  const [newRestImage, setNewRestImage] = useState('');

  // New Menu Item States
  const [isAddingItem, setIsAddingItem] = useState(false);
  const [newItemName, setNewItemName] = useState('');
  const [newItemPrice, setNewItemPrice] = useState('');
  const [newItemCategory, setNewItemCategory] = useState<'Main' | 'Side' | 'Beverage' | 'Dessert'>('Main');
  const [newItemDesc, setNewItemDesc] = useState('');
  const [newItemImage, setNewItemImage] = useState('');
  const [newItemIsVegetarian, setNewItemIsVegetarian] = useState(false);
  const [newItemIsPopular, setNewItemIsPopular] = useState(false);
  const [formErrors, setFormErrors] = useState<{ name?: string; price?: string }>({});

  const handleAddNewRestaurantSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRestName.trim()) return;

    const newRest: Restaurant = {
      id: `rest-${Date.now().toString().slice(-4)}`,
      name: newRestName,
      category: newRestCategory,
      rating: 5.0,
      reviewsCount: 1,
      image: newRestImage.trim() || 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=600&q=80',
      tags: [newRestCategory, 'New Outlet'],
      prepTime: newRestPrepTime,
      minOrder: parseFloat(newRestMinOrder) || 200,
      deliveryFee: parseFloat(newRestDeliveryFee) || 100,
      ownerId: 'rest-owner-' + Date.now(),
      status: 'active',
      isHotel: false,
      menu: []
    };

    if (onUpdateState) {
      onUpdateState('restaurants', [...restaurants, newRest]);
      alert(lang === 'en' ? 'New Restaurant registered successfully!' : 'نیا ریسٹورنٹ کامیابی سے رجسٹر ہو گیا!');
    }

    setIsAddingRestaurant(false);
    setNewRestName('');
    setNewRestImage('');
  };

  const handleAddNewItemSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const errors: { name?: string; price?: string } = {};

    if (!newItemName.trim()) {
      errors.name = lang === 'en' ? 'Dish Name is required.' : 'کھانے کا نام ضروری ہے۔';
    }

    const trimmedPrice = newItemPrice.trim();
    if (!trimmedPrice) {
      errors.price = lang === 'en' ? 'Price is required.' : 'قیمت ضروری ہے۔';
    } else {
      const priceVal = parseFloat(trimmedPrice);
      if (isNaN(priceVal)) {
        errors.price = lang === 'en' ? 'Price must be a valid number.' : 'قیمت ایک درست نمبر ہونی چاہیے۔';
      } else if (priceVal <= 0) {
        errors.price = lang === 'en' ? 'Price must be a positive number greater than zero.' : 'قیمت صفر سے زیادہ ہونی چاہیے۔';
      }
    }

    if (Object.keys(errors).length > 0) {
      setFormErrors(errors);
      return;
    }

    setFormErrors({});
    const priceVal = parseFloat(trimmedPrice);

    const newItem: MenuItem = {
      id: `it-${Date.now().toString().slice(-5)}`,
      name: newItemName.trim(),
      price: priceVal,
      description: newItemDesc.trim() || 'Delicious and fresh',
      image: newItemImage.trim() || 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=300&q=80',
      category: newItemCategory,
      isVegetarian: newItemIsVegetarian,
      isPopular: newItemIsPopular
    };

    const updated = restaurants.map(r => {
      if (r.id === restaurantId) {
        return {
          ...r,
          menu: [...(r.menu || []), newItem]
        };
      }
      return r;
    });

    if (onUpdateState) {
      onUpdateState('restaurants', updated);
      alert(lang === 'en' ? 'Item added to menu successfully!' : 'آئٹم مینو میں کامیابی سے شامل کر دیا گیا!');
    }

    setIsAddingItem(false);
    setNewItemName('');
    setNewItemPrice('');
    setNewItemDesc('');
    setNewItemImage('');
    setNewItemIsVegetarian(false);
    setNewItemIsPopular(false);
  };

  const handleDeleteItem = (itemId: string) => {
    const confirmation = window.confirm(lang === 'en' ? 'Are you sure you want to delete this menu item?' : 'کیا آپ واقعی اس آئٹم کو مینو سے حذف کرنا چاہتے ہیں؟');
    if (!confirmation) return;

    const updated = restaurants.map(r => {
      if (r.id === restaurantId) {
        return {
          ...r,
          menu: (r.menu || []).filter(item => item.id !== itemId)
        };
      }
      return r;
    });

    if (onUpdateState) {
      onUpdateState('restaurants', updated);
    }
  };

  return (
    <div className="space-y-6 font-sans">
      {/* Add/Manage Restaurants Section */}
      <div className="bg-white border border-gray-150 rounded-3xl p-5 md:p-6 shadow-3xs space-y-4">
        <div className="flex justify-between items-center border-b border-gray-100 pb-3">
          <h3 className="font-display font-black text-gray-900 text-sm">
            {lang === 'en' ? 'My Restaurants' : 'میرے ریسٹورنٹس'}
          </h3>
          <button 
            onClick={() => setIsAddingRestaurant(!isAddingRestaurant)}
            className="bg-red-500 hover:bg-red-600 text-white text-xs font-bold px-4 py-2 rounded-xl transition-all cursor-pointer flex items-center gap-1"
          >
            <Plus className="h-4 w-4" />
            {lang === 'en' ? 'Add New Restaurant' : 'نیا ریسٹورنٹ شامل کریں'}
          </button>
        </div>
        <div className="text-xs text-gray-500">
          {lang === 'en' 
            ? 'Manage your restaurant listings, update details, and view individual metrics.' 
            : 'اپنے ریسٹورنٹ کی فہرستوں کا نظم کریں، تفصیلات اپ ڈیٹ کریں، اور میٹرکس دیکھیں۔'}
        </div>

        {/* New Restaurant Form */}
        <AnimatePresence>
          {isAddingRestaurant && (
            <motion.form 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              onSubmit={handleAddNewRestaurantSubmit} 
              className="bg-gray-50 border border-gray-150 rounded-2xl p-4 space-y-3 mt-2 overflow-hidden"
            >
              <h4 className="font-bold text-xs text-gray-800 uppercase tracking-wider">
                {lang === 'en' ? 'Register New Restaurant' : 'نیا ریسٹورنٹ رجسٹر کریں'}
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-gray-500">{lang === 'en' ? 'Restaurant Name' : 'ریسٹورنٹ کا نام'}</label>
                  <input 
                    type="text" 
                    required 
                    value={newRestName} 
                    onChange={e => setNewRestName(e.target.value)}
                    className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2 text-xs outline-none"
                    placeholder="e.g. Gourmet Palace"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-gray-500">{lang === 'en' ? 'Category / Cuisine' : 'کیٹیگری'}</label>
                  <select 
                    value={newRestCategory} 
                    onChange={e => setNewRestCategory(e.target.value)}
                    className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2 text-xs outline-none font-bold"
                  >
                    <option value="Fast Food">Fast Food</option>
                    <option value="Pakistani Food">Pakistani Food</option>
                    <option value="Pizza">Pizza</option>
                    <option value="Burgers">Burgers</option>
                    <option value="Desserts">Desserts</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-gray-500">{lang === 'en' ? 'Prep Time' : 'تیاری کا وقت'}</label>
                  <input 
                    type="text" 
                    required 
                    value={newRestPrepTime} 
                    onChange={e => setNewRestPrepTime(e.target.value)}
                    className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2 text-xs outline-none"
                    placeholder="e.g. 15-25 min"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-gray-500">{lang === 'en' ? 'Min Order (Rs.)' : 'کم از کم آرڈر'}</label>
                  <input 
                    type="number" 
                    required 
                    value={newRestMinOrder} 
                    onChange={e => setNewRestMinOrder(e.target.value)}
                    className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2 text-xs outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-gray-500">{lang === 'en' ? 'Delivery Fee (Rs.)' : 'ڈلیوری فیس'}</label>
                  <input 
                    type="number" 
                    required 
                    value={newRestDeliveryFee} 
                    onChange={e => setNewRestDeliveryFee(e.target.value)}
                    className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2 text-xs outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-gray-500">{lang === 'en' ? 'Image URL' : 'تصویر کا لنک'}</label>
                  <input 
                    type="text" 
                    value={newRestImage} 
                    onChange={e => setNewRestImage(e.target.value)}
                    className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2 text-xs outline-none"
                    placeholder="https://images.unsplash.com/..."
                  />
                </div>
              </div>
              <div className="flex justify-end gap-2 pt-2 border-t border-gray-150">
                <button 
                  type="button" 
                  onClick={() => setIsAddingRestaurant(false)}
                  className="bg-gray-200 hover:bg-gray-300 text-gray-700 text-xs font-bold px-4 py-2 rounded-xl"
                >
                  {lang === 'en' ? 'Cancel' : 'منسوخ کریں'}
                </button>
                <button 
                  type="submit" 
                  className="bg-red-500 hover:bg-red-600 text-white text-xs font-bold px-4 py-2 rounded-xl"
                >
                  {lang === 'en' ? 'Save Restaurant' : 'محفوظ کریں'}
                </button>
              </div>
            </motion.form>
          )}
        </AnimatePresence>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white border border-gray-150 p-4.5 rounded-2xl flex items-center gap-4 shadow-3xs">
          <div className="bg-emerald-50 text-emerald-600 p-3 rounded-xl">
            <Coins className="h-5 w-5" />
          </div>
          <div>
            <span className="text-[10px] text-gray-400 font-bold uppercase">{lang === 'en' ? 'Settled Earnings' : 'کل آمدنی'}</span>
            <p className="text-base font-black text-gray-800 mt-0.5">Rs. {totalRevenue.toLocaleString()}</p>
          </div>
        </div>

        <div className="bg-white border border-gray-150 p-4.5 rounded-2xl flex items-center gap-4 shadow-3xs">
          <div className="bg-amber-50 text-amber-600 p-3 rounded-xl">
            <Clock className="h-5 w-5" />
          </div>
          <div>
            <span className="text-[10px] text-gray-400 font-bold uppercase">{lang === 'en' ? 'Preparing Food' : 'تیار ہونے والا کھانا'}</span>
            <p className="text-base font-black text-gray-800 mt-0.5">{preparingCount} active</p>
          </div>
        </div>

        <div className="bg-white border border-gray-150 p-4.5 rounded-2xl flex items-center gap-4 shadow-3xs">
          <div className="bg-blue-50 text-blue-600 p-3 rounded-xl">
            <PackageCheck className="h-5 w-5" />
          </div>
          <div>
            <span className="text-[10px] text-gray-400 font-bold uppercase">{lang === 'en' ? 'Queue Pending' : 'آرڈرز کی قطار'}</span>
            <p className="text-base font-black text-gray-800 mt-0.5">{pendingCount} orders</p>
          </div>
        </div>
      </div>

      {/* Order Dispatch Dashboard Section */}
      <div className="bg-white border border-gray-150 rounded-3xl p-5 md:p-6 shadow-3xs space-y-4">
        <h3 className="font-display font-black text-gray-900 text-sm border-b border-gray-100 pb-3">
          {lang === 'en' ? 'Kitchen Live Orders Feed' : 'کچن لائیو آرڈرز فیڈ'} ({restOrders.length})
        </h3>

        {restOrders.length === 0 ? (
          <div className="p-8 text-center border-2 border-dashed border-gray-100 rounded-2xl text-gray-400 text-xs">
            ✨ {lang === 'en' 
              ? 'No orders received yet. Switch to "Customer" portal to place new orders!' 
              : 'ابھی تک کوئی آرڈر موصول نہیں ہوا۔ نئے آرڈر دینے کے لیے "کسٹمر" پورٹل پر جائیں!'}
          </div>
        ) : (
          <div className="divide-y divide-gray-100">
            {restOrders.map((order) => (
              <div key={order.id} className="py-4.5 flex flex-wrap items-center justify-between gap-4">
                <div className="space-y-1 flex-1 min-w-[200px]">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-xs bg-red-50 text-red-600 px-2.5 py-0.5 rounded-md">
                      {order.id}
                    </span>
                    <span className="text-[10px] bg-gray-100 text-gray-500 font-bold px-2 py-0.5 rounded-md uppercase">
                      {order.status}
                    </span>
                  </div>

                  {/* Order items inside */}
                  <div className="text-xs text-gray-600 space-y-0.5 font-medium mt-1">
                    {order.items
                      .filter(item => item.restaurantId === restaurantId)
                      .map((item, idx) => (
                        <div key={idx} className="flex items-center gap-1">
                          <span className="font-extrabold text-red-500">{item.quantity}x</span>
                          <span>{item.menuItem.name}</span>
                        </div>
                      ))}
                  </div>

                  <p className="text-[11px] text-gray-400 mt-1 font-semibold">
                    📍 {order.address} • Phone: {order.phone}
                  </p>
                </div>

                {/* State Transitions Actions */}
                <div className="flex gap-2.5">
                  {(order.status === 'received' || order.status === 'paid') && (
                    <button
                      onClick={() => onUpdateOrderStatus(order.id, 'preparing')}
                      className="bg-red-500 hover:bg-red-600 text-white text-xs font-bold px-4 py-2.5 rounded-xl transition-all shadow-sm cursor-pointer"
                    >
                      {lang === 'en' ? 'Accept & Cook' : 'آرڈر قبول کریں'}
                    </button>
                  )}
                  {order.status === 'preparing' && (
                    <button
                      onClick={() => onUpdateOrderStatus(order.id, 'delivery')}
                      className="bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold px-4 py-2.5 rounded-xl transition-all shadow-sm cursor-pointer"
                    >
                      {lang === 'en' ? 'Dispatched / Ready' : 'تیار / روانہ کریں'}
                    </button>
                  )}
                  {order.status === 'delivery' && (
                    <span className="text-[11px] text-amber-600 font-bold bg-amber-50 px-3 py-2 rounded-xl border border-amber-100/50 flex items-center gap-1">
                      🚚 {lang === 'en' ? 'Speeding out with Rider' : 'رائڈر کے ساتھ روانہ ہو گیا'}
                    </span>
                  )}
                  {order.status === 'delivered' && (
                    <span className="text-[11px] text-green-600 font-bold bg-green-50 px-3 py-2 rounded-xl border border-green-100/50 flex items-center gap-1">
                      <Check className="h-4 w-4 stroke-[3]" /> {lang === 'en' ? 'Settlement Paid' : 'ادائیگی موصول'}
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Menu / Inventory Pricing Section */}
      {currentRest && (
        <>
          <div className="bg-white border border-gray-150 rounded-3xl p-5 md:p-6 shadow-3xs space-y-4">
          <div className="flex justify-between items-center border-b border-gray-100 pb-3">
            <h3 className="font-display font-black text-gray-900 text-sm">
              {lang === 'en' ? 'Menu Price & Inventory Management' : 'مینو کی قیمتیں اور انوینٹری کا انتظام'}
            </h3>
            <button 
              onClick={() => {
                setIsAddingItem(!isAddingItem);
                setFormErrors({});
              }}
              className="bg-red-500 hover:bg-red-600 text-white text-xs font-bold px-3 py-1.5 rounded-xl transition-all cursor-pointer flex items-center gap-1"
            >
              <Plus className="h-3.5 w-3.5" />
              {lang === 'en' ? 'Add Food Item' : 'نیا کھانا شامل کریں'}
            </button>
          </div>

          {/* New Menu Item Form */}
          <AnimatePresence>
            {isAddingItem && (
              <motion.form 
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                onSubmit={handleAddNewItemSubmit} 
                className="bg-gray-50 border border-gray-150 rounded-2xl p-4 space-y-3 overflow-hidden"
              >
                <h4 className="font-bold text-xs text-gray-800 uppercase tracking-wider">
                  {lang === 'en' ? 'Add New Food Item to Menu' : 'مینو میں نیا کھانا شامل کریں'}
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-gray-500">
                      {lang === 'en' ? 'Dish Name' : 'کھانے کا نام'} <span className="text-red-500">*</span>
                    </label>
                    <input 
                      type="text" 
                      value={newItemName} 
                      onChange={e => {
                        setNewItemName(e.target.value);
                        if (formErrors.name) {
                          setFormErrors(prev => ({ ...prev, name: undefined }));
                        }
                      }}
                      className={`w-full bg-white border ${
                        formErrors.name ? 'border-red-500 focus:ring-1 focus:ring-red-400' : 'border-gray-200 focus:border-gray-300'
                      } rounded-xl px-3 py-2 text-xs outline-none transition-all`}
                      placeholder="e.g. Special Beef Pulao"
                    />
                    {formErrors.name && (
                      <p className="text-[10px] text-red-500 font-semibold mt-0.5">{formErrors.name}</p>
                    )}
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-gray-500">
                      {lang === 'en' ? 'Price (Rs.)' : 'قیمت (روپے)'} <span className="text-red-500">*</span>
                    </label>
                    <input 
                      type="text" 
                      value={newItemPrice} 
                      onChange={e => {
                        setNewItemPrice(e.target.value);
                        if (formErrors.price) {
                          setFormErrors(prev => ({ ...prev, price: undefined }));
                        }
                      }}
                      className={`w-full bg-white border ${
                        formErrors.price ? 'border-red-500 focus:ring-1 focus:ring-red-400' : 'border-gray-200 focus:border-gray-300'
                      } rounded-xl px-3 py-2 text-xs outline-none transition-all`}
                      placeholder="e.g. 350"
                    />
                    {formErrors.price && (
                      <p className="text-[10px] text-red-500 font-semibold mt-0.5">{formErrors.price}</p>
                    )}
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-gray-500">{lang === 'en' ? 'Category' : 'کیٹیگری'}</label>
                    <select 
                      value={newItemCategory} 
                      onChange={e => setNewItemCategory(e.target.value as any)}
                      className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2 text-xs outline-none font-bold"
                    >
                      <option value="Main">Main Course</option>
                      <option value="Side">Side dish</option>
                      <option value="Beverage">Beverages</option>
                      <option value="Dessert">Dessert</option>
                    </select>
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-gray-500">{lang === 'en' ? 'Image URL' : 'تصویر کا لنک'}</label>
                    <input 
                      type="text" 
                      value={newItemImage} 
                      onChange={e => setNewItemImage(e.target.value)}
                      className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2 text-xs outline-none"
                      placeholder="https://images.unsplash.com/..."
                    />
                  </div>
                  <div className="space-y-1 md:col-span-2">
                    <label className="text-[10px] font-bold text-gray-500">{lang === 'en' ? 'Description' : 'تفصیل'}</label>
                    <textarea 
                      value={newItemDesc} 
                      onChange={e => setNewItemDesc(e.target.value)}
                      className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2 text-xs outline-none h-16"
                      placeholder="e.g. Traditional recipe cooked with high quality ingredients..."
                    />
                  </div>
                  <div className="flex items-center gap-4 py-2 md:col-span-2">
                    <label className="flex items-center gap-1.5 text-xs text-gray-700 font-semibold cursor-pointer">
                      <input 
                        type="checkbox" 
                        checked={newItemIsVegetarian} 
                        onChange={e => setNewItemIsVegetarian(e.target.checked)}
                        className="rounded text-red-500"
                      />
                      {lang === 'en' ? 'Vegetarian / Veg' : 'سبزی خور (Veg)'}
                    </label>
                    <label className="flex items-center gap-1.5 text-xs text-gray-700 font-semibold cursor-pointer">
                      <input 
                        type="checkbox" 
                        checked={newItemIsPopular} 
                        onChange={e => setNewItemIsPopular(e.target.checked)}
                        className="rounded text-red-500"
                      />
                      {lang === 'en' ? 'Bestseller / Popular' : 'مقبول / مقبول ترین'}
                    </label>
                  </div>
                </div>
                <div className="flex justify-end gap-2 pt-2 border-t border-gray-150">
                  <button 
                    type="button" 
                    onClick={() => {
                      setIsAddingItem(false);
                      setFormErrors({});
                    }}
                    className="bg-gray-200 hover:bg-gray-300 text-gray-700 text-xs font-bold px-4 py-2 rounded-xl"
                  >
                    {lang === 'en' ? 'Cancel' : 'منسوخ کریں'}
                  </button>
                  <button 
                    type="submit" 
                    className="bg-red-500 hover:bg-red-600 text-white text-xs font-bold px-4 py-2 rounded-xl"
                  >
                    {lang === 'en' ? 'Add Item' : 'کھانا شامل کریں'}
                  </button>
                </div>
              </motion.form>
            )}
          </AnimatePresence>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-100 font-bold text-gray-400 uppercase tracking-wider">
                  <th className="p-3">{lang === 'en' ? 'Dish / Item' : 'ڈش / آئٹم'}</th>
                  <th className="p-3">{lang === 'en' ? 'Category' : 'کیٹیگری'}</th>
                  <th className="p-3">{lang === 'en' ? 'Current Price' : 'موجودہ قیمت'}</th>
                  <th className="p-3">{lang === 'en' ? 'Modify Rate / Actions' : 'تبدیل کریں / اقدامات'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50 font-medium">
                {(currentRest.menu || []).length === 0 ? (
                  <tr>
                    <td colSpan={4} className="p-6 text-center text-gray-400">
                      🍽️ {lang === 'en' ? 'No items in menu yet. Click "+ Add Food Item" above to add your first dish!' : 'ابھی تک مینو میں کوئی آئٹمز نہیں ہیں۔ شامل کرنے کے لیے اوپر بٹن دبائیں۔'}
                    </td>
                  </tr>
                ) : (
                  (currentRest.menu || []).map((dish) => (
                    <tr key={dish.id} className="hover:bg-gray-50/50">
                      <td className="p-3">
                        <div className="flex items-center gap-2">
                          <img src={dish.image} className="h-8 w-8 rounded-lg object-cover" referrerPolicy="no-referrer" />
                          <div>
                            <div className="flex items-center gap-1.5">
                              <p className="font-black text-gray-800">{dish.name}</p>
                              {dish.isPopular && (
                                <span className="bg-yellow-50 text-yellow-700 text-[8px] font-bold px-1 rounded-sm">Bestseller</span>
                              )}
                              {dish.isVegetarian && (
                                <span className="bg-green-50 text-green-700 text-[8px] font-bold px-1 rounded-sm">Veg</span>
                              )}
                            </div>
                            <p className="text-[10px] text-gray-400 font-medium truncate max-w-[200px]">{dish.description}</p>
                          </div>
                        </div>
                      </td>
                      <td className="p-3 text-gray-500 uppercase font-black text-[10px]">{dish.category}</td>
                      <td className="p-3 font-bold text-gray-800">Rs. {dish.price}</td>
                      <td className="p-3">
                        <div className="flex items-center gap-3">
                          {editingPriceId === dish.id ? (
                            <div className="flex items-center gap-1">
                              <input
                                type="number"
                                value={tempPrice}
                                onChange={(e) => setTempPrice(Number(e.target.value))}
                                className="w-16 p-1 border border-red-400 rounded-md outline-none text-xs font-mono font-bold"
                              />
                              <button
                                onClick={() => {
                                  onUpdateMenuPrice(restaurantId, dish.id, tempPrice);
                                  setEditingPriceId(null);
                                }}
                                className="bg-emerald-500 text-white px-2 py-1 rounded-md text-[10px] font-bold cursor-pointer"
                              >
                                {lang === 'en' ? 'Save' : 'محفوظ'}
                              </button>
                            </div>
                          ) : (
                            <button
                              onClick={() => {
                                setEditingPriceId(dish.id);
                                setTempPrice(dish.price);
                              }}
                              className="text-red-500 hover:text-red-600 hover:underline font-bold cursor-pointer"
                            >
                              {lang === 'en' ? 'Edit Price' : 'قیمت تبدیل کریں'}
                            </button>
                          )}

                          <button 
                            onClick={() => handleDeleteItem(dish.id)}
                            className="text-gray-400 hover:text-red-600 transition-colors p-1 rounded-md cursor-pointer"
                            title={lang === 'en' ? 'Delete Item' : 'حذف کریں'}
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Category Visuals / Icons / Images Customizer Section */}
        <div className="bg-white border border-gray-150 rounded-3xl p-5 md:p-6 shadow-3xs space-y-6">
          <div className="border-b border-gray-100 pb-3 flex items-center gap-2">
            <span className="text-xl">🎨</span>
            <div>
              <h3 className="font-display font-black text-gray-900 text-sm">
                {lang === 'en' ? 'Food Categories Visual Customization' : 'کھانے کے زمرے کی ظاہری شکل'}
              </h3>
              <p className="text-[10px] md:text-xs text-gray-400 font-medium mt-0.5">
                {lang === 'en' 
                  ? 'Upload images or select custom icons for each food category to enhance the customer shopping experience.'
                  : 'صارفین کی سہولت کے لیے ہر کیٹیگری کے لیے خوبصورت آئیکن اور تصویر کا انتخاب کریں۔'}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
            {(['Main', 'Side', 'Beverage', 'Dessert'] as const).map((cat) => {
              const visual = currentRest.categoryVisuals?.[cat] || DEFAULT_CATEGORY_VISUALS[cat] || { icon: '🍽️', image: '' };
              const presets = PRESET_EMOJIS[cat] || [];
              const imgPresets = PRESET_IMAGES[cat] || [];

              return (
                <div key={cat} className="border border-gray-100/85 rounded-2xl p-4 bg-gray-50/40 flex flex-col justify-between space-y-4">
                  <div>
                    {/* Active Preview */}
                    <div className="relative h-24 rounded-xl overflow-hidden mb-3 group flex items-center">
                      <img 
                        src={visual.image} 
                        alt={cat} 
                        className="absolute inset-0 h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" 
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/45 to-transparent"></div>
                      <div className="relative z-10 px-4 text-white">
                        <span className="text-2xl block mb-1">{visual.icon}</span>
                        <h4 className="font-display font-black text-sm">{cat}</h4>
                        <span className="text-[9px] text-gray-300 bg-white/20 px-1.5 py-0.5 rounded font-mono">
                          {visual.image.startsWith('data:') ? 'Custom Uploaded' : 'Web Image'}
                        </span>
                      </div>
                    </div>

                    {/* Icon Customizer */}
                    <div className="space-y-1.5 mb-4">
                      <label className="text-[10px] font-bold text-gray-500 block uppercase tracking-wider">
                        {lang === 'en' ? 'Select or Type Icon / Emoji' : 'آئیکن / ایموجی منتخب کریں'}
                      </label>
                      {/* Emojis selection grid */}
                      <div className="flex flex-wrap gap-1">
                        {presets.map(emoji => (
                          <button
                            key={emoji}
                            type="button"
                            onClick={() => handleUpdateCategoryVisual(cat, { icon: emoji })}
                            className={`h-8 w-8 text-lg rounded-lg border flex items-center justify-center transition-all cursor-pointer ${
                              visual.icon === emoji 
                                ? 'bg-red-500 border-red-500 text-white scale-110 shadow-xs' 
                                : 'bg-white hover:bg-gray-100 border-gray-150 text-gray-700'
                            }`}
                          >
                            {emoji}
                          </button>
                        ))}
                      </div>
                      {/* Custom emoji input */}
                      <div className="flex gap-2 pt-1">
                        <input
                          type="text"
                          maxLength={5}
                          value={visual.icon}
                          onChange={(e) => handleUpdateCategoryVisual(cat, { icon: e.target.value })}
                          className="bg-white border border-gray-150 rounded-lg px-2.5 py-1 text-xs outline-none focus:border-red-400 w-24 text-center font-bold"
                          placeholder="Emoji"
                        />
                        <span className="text-[10px] text-gray-400 self-center">
                          {lang === 'en' ? 'Or type any emoji' : 'یا کوئی بھی ایموجی ٹائپ کریں'}
                        </span>
                      </div>
                    </div>

                    {/* Cover Image Customizer */}
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-gray-500 block uppercase tracking-wider">
                        {lang === 'en' ? 'Choose Cover Image' : 'کیور تصویر منتخب کریں'}
                      </label>
                      
                      {/* Preset images selection */}
                      <div className="grid grid-cols-4 gap-2">
                        {imgPresets.map((preset, index) => (
                          <button
                            key={index}
                            type="button"
                            onClick={() => handleUpdateCategoryVisual(cat, { image: preset.url })}
                            className={`relative h-12 rounded-lg overflow-hidden border-2 transition-all cursor-pointer ${
                              visual.image === preset.url 
                                ? 'border-red-500 scale-95 shadow-2xs' 
                                : 'border-transparent opacity-85 hover:opacity-100'
                            }`}
                            title={preset.label}
                          >
                            <img src={preset.url} alt={preset.label} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                            <div className="absolute inset-0 bg-black/25 flex items-end p-0.5 justify-center">
                              <span className="text-[7px] text-white font-extrabold truncate w-full text-center">{preset.label}</span>
                            </div>
                          </button>
                        ))}
                      </div>

                      {/* File Upload / Custom URL */}
                      <div className="space-y-1.5 pt-1">
                        <div className="flex flex-col sm:flex-row gap-2">
                          {/* File Upload Input */}
                          <label className="bg-red-50 hover:bg-red-100 border border-red-200 text-red-600 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1 shrink-0">
                            <Upload className="h-3.5 w-3.5" />
                            <span>{lang === 'en' ? 'Upload Image' : 'تصویر اپلوڈ کریں'}</span>
                            <input 
                              type="file" 
                              accept="image/*" 
                              className="hidden" 
                              onChange={(e) => {
                                if (e.target.files?.[0]) {
                                  handleImageUpload(cat, e.target.files[0]);
                                }
                              }}
                            />
                          </label>
                          
                          {/* URL Input */}
                          <input
                            type="text"
                            value={visual.image.startsWith('data:') ? '' : visual.image}
                            onChange={(e) => handleUpdateCategoryVisual(cat, { image: e.target.value })}
                            placeholder={lang === 'en' ? 'Or paste custom image URL...' : 'یا تصویر کا لنک یہاں پیسٹ کریں...'}
                            className="bg-white border border-gray-150 rounded-lg px-2.5 py-1.5 text-xs outline-none focus:border-red-400 flex-1"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
        </>
      )}
    </div>
  );
}
