import React, { useState } from 'react';
import { ArrowLeft, Star, Clock, Check, Plus, Minus, ThumbsUp, Leaf } from 'lucide-react';
import { Restaurant, MenuItem, CartItem } from '../types';
import { motion } from 'motion/react';

interface MenuSectionProps {
  restaurant: Restaurant;
  cartItems: CartItem[];
  onAddToCart: (item: MenuItem) => void;
  onRemoveFromCart: (item: MenuItem) => void;
  onBack: () => void;
}

export default function MenuSection({
  restaurant,
  cartItems,
  onAddToCart,
  onRemoveFromCart,
  onBack
}: MenuSectionProps) {
  const [selectedSubCategory, setSelectedSubCategory] = useState<'All' | 'Main' | 'Side' | 'Beverage' | 'Dessert'>('All');

  // Helper to find the current quantity of a menu item in the cart
  const getItemQuantity = (itemId: string) => {
    const item = cartItems.find((ci) => ci.menuItem.id === itemId);
    return item ? item.quantity : 0;
  };

  const DEFAULT_CATEGORY_VISUALS: Record<string, { icon: string; image: string }> = {
    Main: {
      icon: '🍛',
      image: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=500&q=80'
    },
    Side: {
      icon: '🍟',
      image: 'https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&w=500&q=80'
    },
    Beverage: {
      icon: '🥤',
      image: 'https://images.unsplash.com/photo-1437419764061-2473afe69fc2?auto=format&fit=crop&w=500&q=80'
    },
    Dessert: {
      icon: '🍰',
      image: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=500&q=80'
    }
  };

  const getCategoryVisual = (cat: string) => {
    const custom = restaurant.categoryVisuals?.[cat];
    const def = DEFAULT_CATEGORY_VISUALS[cat] || { icon: '🍽️', image: '' };
    return {
      icon: custom?.icon || def.icon,
      image: custom?.image || def.image
    };
  };

  const menuList = restaurant.menu || [];
  const filteredMenu = selectedSubCategory === 'All'
    ? menuList
    : menuList.filter((item) => item.category === selectedSubCategory);

  return (
    <div id="restaurant-menu-view" className="bg-white rounded-3xl overflow-hidden border border-gray-100 shadow-xs">
      {/* Restaurant Header Jumbotron */}
      <div className="relative h-60 md:h-72 bg-gray-900">
        <img
          src={restaurant.image}
          alt={restaurant.name}
          className="w-full h-full object-cover opacity-60"
          referrerPolicy="no-referrer"
        />
        
        {/* Floating Back Button */}
        <button
          onClick={onBack}
          className="absolute top-4 left-4 bg-white/90 hover:bg-white text-gray-800 p-2.5 rounded-full shadow-md transition-all active:scale-95 flex items-center justify-center cursor-pointer"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>

        {/* Info overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent flex flex-col justify-end p-6 md:p-8">
          <div className="flex flex-wrap items-center gap-2 mb-2">
            {restaurant.tags.map((tag) => (
              <span key={tag} className="text-[10px] md:text-xs bg-white/20 text-white font-semibold px-2.5 py-1 rounded-full backdrop-blur-md">
                {tag}
              </span>
            ))}
          </div>
          
          <h2 className="font-display font-bold text-2xl md:text-4xl text-white tracking-tight mb-2">
            {restaurant.name}
          </h2>

          <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-xs md:text-sm text-gray-200 font-medium">
            <div className="flex items-center gap-1 text-yellow-400">
              <Star className="h-4 w-4 fill-current" />
              <span className="font-bold text-white">{restaurant.rating}</span>
              <span className="text-gray-300">({restaurant.reviewsCount} reviews)</span>
            </div>
            
            <div className="h-1 w-1 rounded-full bg-gray-400"></div>
            
            <div className="flex items-center gap-1">
              <Clock className="h-4 w-4" />
              <span>{restaurant.prepTime} delivery</span>
            </div>

            <div className="h-1 w-1 rounded-full bg-gray-400"></div>

            <div>
              <span>Min. Order: Rs. {restaurant.minOrder}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Menu Categories Pills Inside Restaurant */}
      <div className="border-b border-gray-100 bg-gray-50/50 px-6 py-4 flex gap-2 overflow-x-auto scrollbar-hide">
        {(['All', 'Main', 'Side', 'Beverage', 'Dessert'] as const).map((cat) => {
          // Check if category exists in menu
          const count = cat === 'All' 
            ? menuList.length 
            : menuList.filter(i => i.category === cat).length;
          
          if (count === 0) return null;

          const isActive = selectedSubCategory === cat;
          const { icon } = cat === 'All' ? { icon: '🍽️' } : getCategoryVisual(cat);

          return (
            <button
              key={cat}
              onClick={() => setSelectedSubCategory(cat)}
              className={`text-xs font-semibold px-4 py-2 rounded-xl whitespace-nowrap transition-all duration-200 flex items-center gap-1.5 ${
                isActive
                  ? 'bg-red-500 text-white shadow-xs animate-none'
                  : 'bg-white text-gray-600 hover:text-gray-900 border border-gray-100/70'
              }`}
            >
              <span className="text-sm">{icon}</span>
              <span>{cat} ({count})</span>
            </button>
          );
        })}
      </div>

      {/* Menu Items Grid */}
      <div className="p-6 md:p-8">
        {selectedSubCategory !== 'All' && (() => {
          const visual = getCategoryVisual(selectedSubCategory);
          return (
            <div className="relative h-28 md:h-36 rounded-2xl overflow-hidden mb-6 group flex items-center">
              <img 
                src={visual.image} 
                alt={selectedSubCategory} 
                className="absolute inset-0 h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" 
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-black/85 via-black/45 to-transparent"></div>
              <div className="relative z-10 px-6 text-white">
                <span className="text-3xl md:text-4xl block mb-1">{visual.icon}</span>
                <h4 className="font-display font-extrabold text-lg md:text-xl">{selectedSubCategory}</h4>
                <p className="text-[10px] md:text-xs text-gray-200 mt-0.5 font-medium">
                  Browse our finest selection of {selectedSubCategory.toLowerCase()} dishes.
                </p>
              </div>
            </div>
          );
        })()}

        <h3 className="font-display font-bold text-xl text-gray-900 mb-6">
          {selectedSubCategory} Menu Selection
        </h3>

        {filteredMenu.length === 0 ? (
          <div className="p-12 text-center border-2 border-dashed border-gray-100 rounded-3xl text-gray-400 text-sm">
            <span className="text-3xl block mb-2">🍽️</span>
            No food items found in this category.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredMenu.map((item) => {
              const quantity = getItemQuantity(item.id);
              return (
                <motion.div
                  key={item.id}
                  id={`menu-item-${item.id}`}
                  whileHover={{ scale: 1.02 }}
                  transition={{ duration: 0.2 }}
                  className="flex gap-4 p-4 border border-gray-100 hover:border-gray-200/80 rounded-2xl transition-all duration-200 hover:shadow-md hover:bg-gray-50/50"
                >
                  {/* Item Info */}
                  <div className="flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center gap-1.5 flex-wrap mb-1">
                        <span className="font-semibold text-gray-900 text-base">{item.name}</span>
                        
                        {item.isPopular && (
                          <span className="bg-yellow-50 text-yellow-700 text-[9px] font-bold px-1.5 py-0.5 rounded-sm flex items-center gap-0.5">
                            <ThumbsUp className="h-2 w-2" /> Bestseller
                          </span>
                        )}
                        {item.isVegetarian && (
                          <span className="bg-green-50 text-green-700 text-[9px] font-bold px-1.5 py-0.5 rounded-sm flex items-center gap-0.5">
                            <Leaf className="h-2 w-2" /> Veg
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-gray-500 leading-relaxed line-clamp-2 mt-1 pr-2">
                        {item.description}
                      </p>
                    </div>

                    <div className="flex items-end justify-between mt-3">
                      <span className="font-display font-extrabold text-red-600 text-lg">
                        Rs. {item.price}
                      </span>

                      {/* Quantity controllers */}
                      <div className="flex items-center">
                        {quantity > 0 ? (
                          <div className="flex items-center bg-red-500 text-white rounded-xl shadow-xs px-1 py-1">
                            <button
                              onClick={() => onRemoveFromCart(item)}
                              className="p-1 hover:bg-red-600 rounded-lg active:scale-90 transition-transform cursor-pointer"
                            >
                              <Minus className="h-3.5 w-3.5" />
                            </button>
                            <span className="text-xs font-bold w-7 text-center">{quantity}</span>
                            <button
                              onClick={() => onAddToCart(item)}
                              className="p-1 hover:bg-red-600 rounded-lg active:scale-90 transition-transform cursor-pointer"
                            >
                              <Plus className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => onAddToCart(item)}
                            className="px-4 py-1.5 bg-red-50 text-red-600 hover:bg-red-500 hover:text-white border border-red-200 hover:border-red-500 font-bold text-xs rounded-xl transition-all duration-200 active:scale-95 cursor-pointer flex items-center gap-1"
                          >
                            <Plus className="h-3 w-3" /> Add
                          </button>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Item Image */}
                  <div className="h-24 w-24 md:h-28 md:w-28 rounded-2xl overflow-hidden bg-gray-50 flex-shrink-0 relative group cursor-pointer">
                    <img
                      src={item.image}
                      alt={item.name}
                      className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
                      referrerPolicy="no-referrer"
                    />
                    {/* Quick Add Overlay */}
                    <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <button
                          onClick={(e) => { e.stopPropagation(); onAddToCart(item); }}
                          className="bg-white/90 text-red-600 px-3 py-1.5 rounded-xl text-xs font-bold shadow-lg hover:bg-white active:scale-95 transition-all"
                      >
                          Quick Add
                      </button>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
