import React from 'react';
import { Rider } from '../types';
import { Award, Star, Package } from 'lucide-react';

interface TopRidersSectionProps {
  riders: Rider[];
}

export default function TopRidersSection({ riders }: TopRidersSectionProps) {
  // Sort riders by rating first, then by completed deliveries
  const sortedRiders = [...riders].sort((a, b) => {
    const ratingDiff = (b.rating || 0) - (a.rating || 0);
    if (ratingDiff !== 0) return ratingDiff;
    return b.completedDeliveries - a.completedDeliveries;
  });

  return (
    <div className="bg-white border border-gray-150 rounded-3xl p-6 shadow-3xs space-y-5">
      <div className="flex items-center gap-2 mb-2">
        <Award className="h-6 w-6 text-amber-500" />
        <h3 className="font-display font-black text-slate-900 text-lg">Top Riders</h3>
      </div>
      
      <div className="space-y-3">
        {sortedRiders.slice(0, 3).map((rider, index) => (
          <div key={rider.id} className="flex items-center gap-4 p-3 bg-gray-50 rounded-2xl border border-gray-100">
            <div className={`flex items-center justify-center w-8 h-8 rounded-full font-black text-xs ${
              index === 0 ? 'bg-amber-100 text-amber-700' : 
              index === 1 ? 'bg-slate-200 text-slate-700' : 'bg-orange-100 text-orange-700'
            }`}>
              {index + 1}
            </div>
            <div className="flex-1">
              <p className="font-bold text-sm text-slate-900">{rider.name}</p>
              <div className="flex items-center gap-3 text-[10px] text-gray-500 font-semibold mt-0.5">
                <span className="flex items-center gap-1"><Star className="h-3 w-3 text-yellow-500" /> {rider.rating?.toFixed(1)}</span>
                <span className="flex items-center gap-1"><Package className="h-3 w-3 text-blue-500" /> {rider.completedDeliveries} del.</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
