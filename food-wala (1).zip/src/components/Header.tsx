import React from 'react';
import { Search, ShoppingBag, MapPin, ChefHat, Sparkles, History, Sun, Moon } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface HeaderProps {
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  activeCategory: string;
  setActiveCategory: (category: string) => void;
  cartCount: number;
  onCartClick: () => void;
  onHistoryClick: () => void;
  selectedAddress: string;
  onUpdateAddress: (address: string) => void;
  walletBalance: number;
  onWalletClick: () => void;
  theme: 'light' | 'dark';
  onToggleTheme: () => void;
}

const CATEGORIES = ['All', 'Fast Food', 'Burgers', 'Pizza', 'Pakistani Food'];

export default function Header({
  searchQuery,
  setSearchQuery,
  activeCategory,
  setActiveCategory,
  cartCount,
  onCartClick,
  onHistoryClick,
  selectedAddress,
  onUpdateAddress,
  walletBalance,
  onWalletClick,
  theme,
  onToggleTheme
}: HeaderProps) {
  const handleLocate = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) => {
        // Simple logic for "Hyderabad, Sindh"
        // In a real app, use Reverse Geocoding
        onUpdateAddress("Hyderabad, Sindh");
      });
    }
  };
  return (
    <header id="foodwala-header" className="sticky top-0 z-40 bg-white dark:bg-gray-900 border-b border-gray-100 dark:border-gray-800 shadow-xs">
      {/* Upper Navigation Row */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between gap-4">
        {/* Logo and Tagline */}
        <div className="flex items-center gap-3">
          <img src="/logo.png" alt="Food Wala" className="h-12 w-auto" />
        </div>

        {/* Global Search Bar (Desktop) */}
        <div className="hidden md:flex flex-1 max-w-md relative">
          <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400">
            <Search className="h-4.5 w-4.5" />
          </div>
          <input
            type="text"
            placeholder="Search restaurants, burgers, biryani, pizza..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-gray-50 dark:bg-gray-800 hover:bg-gray-100/70 dark:hover:bg-gray-800/80 focus:bg-white dark:focus:bg-gray-700 border border-gray-100 dark:border-gray-700 focus:border-red-500 focus:ring-2 focus:ring-red-100 dark:focus:ring-red-900 rounded-xl text-sm transition-all outline-none text-gray-800 dark:text-gray-100 placeholder-gray-400"
          />
        </div>

        {/* Right side: Location indicator and Shopping Cart button */}
        <div className="flex items-center gap-4">
          <button
            onClick={onToggleTheme}
            className="p-2.5 rounded-xl bg-gray-50 dark:bg-gray-800 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
          >
            {theme === 'light' ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
          </button>
          <div className="hidden sm:flex items-center gap-2 bg-gray-50 dark:bg-gray-800 border border-gray-100/80 dark:border-gray-700 px-3 py-1.5 rounded-xl cursor-pointer" onClick={handleLocate}>
            <MapPin className="h-4 w-4 text-red-500 animate-pulse" />
            <div className="text-left">
              <p className="text-[10px] text-gray-400 dark:text-gray-500 font-semibold uppercase leading-none">Delivering to</p>
              <p className="text-xs font-semibold text-gray-700 dark:text-gray-200 truncate max-w-[150px] mt-0.5">
                {selectedAddress || "Select Address"}
              </p>
            </div>
          </div>

          <button
            onClick={onWalletClick}
            id="header-wallet-btn"
            className="flex items-center gap-1.5 bg-amber-50 dark:bg-amber-900/30 hover:bg-amber-100 dark:hover:bg-amber-900/50 text-amber-800 dark:text-amber-200 border border-amber-100/70 dark:border-amber-900/50 font-bold px-3.5 py-2.5 rounded-xl transition-all active:scale-95 group cursor-pointer"
          >
            <span className="text-sm">🪙</span>
            <div className="text-left leading-none">
              <span className="text-[8px] text-amber-600 dark:text-amber-400 block font-semibold">FOODWALA WALLET</span>
              <span className="text-xs font-black">Rs. {walletBalance.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 2 })}</span>
            </div>
          </button>

          <button
            onClick={onHistoryClick}
            id="header-past-orders-btn"
            className="flex items-center gap-1.5 bg-gray-50 dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white border border-gray-100 dark:border-gray-700 font-semibold px-3.5 py-2.5 rounded-xl transition-all active:scale-95 group cursor-pointer"
          >
            <History className="h-4 w-4 text-gray-400 dark:text-gray-500 group-hover:text-red-500 transition-colors" />
            <span className="text-xs hidden sm:inline">Past Orders</span>
          </button>

          <button
            onClick={onCartClick}
            id="mobile-cart-toggle"
            className="relative flex items-center gap-2 bg-red-500 hover:bg-red-600 text-white font-semibold px-4 py-2.5 rounded-xl shadow-lg shadow-red-500/20 transition-all active:scale-95 group"
          >
            <ShoppingBag className="h-4.5 w-4.5 group-hover:scale-110 transition-transform" />
            <span className="text-sm hidden sm:inline">My Cart</span>
            
            <AnimatePresence>
              {cartCount > 0 && (
                <motion.span
                  key={cartCount}
                  initial={{ scale: 0.6, opacity: 0 }}
                  animate={{ scale: [1.3, 0.9, 1], opacity: 1 }}
                  exit={{ scale: 0.6, opacity: 0 }}
                  className="absolute -top-1.5 -right-1.5 bg-yellow-400 text-red-950 text-[11px] font-black h-5 w-5 rounded-full flex items-center justify-center border-2 border-white dark:border-gray-900 shadow-sm"
                >
                  {cartCount}
                </motion.span>
              )}
            </AnimatePresence>
          </button>
        </div>
      </div>

      {/* Categories Bar & Search (Mobile Only) */}
      <div className="px-4 pb-4 md:hidden">
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400">
            <Search className="h-4 w-4" />
          </div>
          <input
            type="text"
            placeholder="Search restaurants, burgers, biryani..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-gray-50 dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-xl text-xs outline-none focus:border-red-500 focus:bg-white dark:focus:bg-gray-700 transition-all text-gray-800 dark:text-gray-100"
          />
        </div>
      </div>

      {/* Category Filter Pills Row */}
      <div className="border-t border-gray-50 dark:border-gray-800 bg-gray-50/50 dark:bg-gray-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2.5 flex gap-2 overflow-x-auto scrollbar-hide">
          {CATEGORIES.map((cat) => {
            const isActive = activeCategory === cat;
            return (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`text-xs font-semibold px-4.5 py-2 rounded-full whitespace-nowrap transition-all duration-200 ${
                  isActive
                    ? 'bg-red-500 text-white shadow-xs'
                    : 'bg-white dark:bg-gray-800 text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white border border-gray-100/70 dark:border-gray-700 hover:border-gray-200 dark:hover:border-gray-600'
                }`}
              >
                {cat}
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
}
