import React, { useState, useEffect } from 'react';
import { X, ShieldCheck, CreditCard, Check, AlertCircle, Smartphone, Copy, HelpCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface PaymentGatewayProps {
  isOpen: boolean;
  onClose: () => void;
  total: number;
  onSuccess: (paymentMethod: string) => void;
}

export default function PaymentGateway({ isOpen, onClose, total, onSuccess }: PaymentGatewayProps) {
  const paymentSettings = (() => {
    try {
      const saved = localStorage.getItem('foodwala_payment_settings');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return {
      jazzCashActive: true,
      jazzCashAccountNo: '0324-0732363',
      jazzCashTillId: '980131623',
      easyPaisaActive: true,
      easyPaisaAccountNo: '0324-0732363',
      codActive: true,
    };
  })();

  const [method, setMethod] = useState<'card' | 'easypaisa' | 'jazzcash'>('card');
  const [cardNumber, setCardNumber] = useState('');
  const [expiry, setExpiry] = useState('');
  const [cvv, setCvv] = useState('');
  const [mobileNumber, setMobileNumber] = useState('');
  const [transactionId, setTransactionId] = useState('');
  const [copiedText, setCopiedText] = useState<string | null>(null);
  const [step, setStep] = useState<'form' | 'processing' | 'success'>('form');
  const [loaderText, setLoaderText] = useState('Initiating Secure Settlement...');
  const [errors, setErrors] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(label);
    setTimeout(() => setCopiedText(null), 2000);
  };

  const handleProcess = (e: React.FormEvent) => {
    e.preventDefault();
    setErrors(null);

    if (method === 'card') {
      if (cardNumber.replace(/\s/g, '').length < 16) {
        setErrors('Please enter a valid 16-digit Card Number');
        return;
      }
      if (!expiry.includes('/')) {
        setErrors('Expiry Date should be in MM/YY format');
        return;
      }
      if (cvv.length < 3) {
        setErrors('Please enter a valid 3-digit CVV');
        return;
      }
    } else {
      if (!/^(03|923)\d{9}$/.test(mobileNumber.trim())) {
        setErrors('Please enter a valid Pakistani mobile wallet number (e.g., 03240732363)');
        return;
      }
      if (transactionId.trim().length < 8) {
        setErrors('Please enter a valid Transaction ID (TID) to proceed.');
        return;
      }
    }

    // Step transition simulation
    setStep('processing');
    const loadingTexts = [
      'Authenticating wallet settlement credentials...',
      'Connecting to Bank Secure Net Proxy...',
      'Verifying Transaction ID (TID) on gateway records...',
      'Deducting transaction amount...',
      'Logging receipt under secure bank id...'
    ];

    let currentIdx = 0;
    const interval = setInterval(() => {
      if (currentIdx < loadingTexts.length) {
        setLoaderText(loadingTexts[currentIdx]);
        currentIdx++;
      } else {
        clearInterval(interval);
        setStep('success');
        setTimeout(() => {
          onSuccess(method === 'card' ? '💳 Credit/Debit Card' : method === 'easypaisa' ? '📱 EasyPaisa Wallet' : '📱 JazzCash Wallet');
          onClose();
        }, 1500);
      }
    }, 700);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-900/60 backdrop-blur-xs">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        className="bg-white rounded-3xl overflow-hidden shadow-2xl max-w-md w-full border border-gray-100 flex flex-col relative"
      >
        {/* Step: FORM */}
        {step === 'form' && (
          <>
            <div className="p-5 border-b border-gray-100 flex items-center justify-between bg-gray-50/50">
              <div>
                <h3 className="font-display font-black text-base text-gray-900 flex items-center gap-1.5">
                  <ShieldCheck className="h-5 w-5 text-emerald-500 fill-emerald-50/50" />
                  Secure Online Gateway
                </h3>
                <p className="text-[10px] text-gray-400 font-semibold uppercase mt-0.5">Hyderabad Bank Direct Settlement</p>
              </div>
              <button
                onClick={onClose}
                className="p-1.5 hover:bg-gray-100 text-gray-400 hover:text-gray-900 rounded-full transition-all cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleProcess} className="p-6 space-y-5">
              {/* Selector Tabs */}
              <div className="grid grid-cols-3 gap-2 bg-gray-100 p-1 rounded-2xl">
                <button
                  type="button"
                  onClick={() => { setMethod('card'); setErrors(null); }}
                  className={`py-2 rounded-xl text-[10px] font-black uppercase transition-all ${
                    method === 'card' ? 'bg-white text-gray-900 shadow-xs' : 'text-gray-500'
                  }`}
                >
                  Card
                </button>
                <button
                  type="button"
                  onClick={() => { setMethod('easypaisa'); setErrors(null); }}
                  className={`py-2 rounded-xl text-[10px] font-black uppercase transition-all ${
                    method === 'easypaisa' ? 'bg-white text-emerald-600 shadow-xs' : 'text-gray-500'
                  }`}
                >
                  EasyPaisa
                </button>
                <button
                  type="button"
                  onClick={() => { setMethod('jazzcash'); setErrors(null); }}
                  className={`py-2 rounded-xl text-[10px] font-black uppercase transition-all ${
                    method === 'jazzcash' ? 'bg-white text-orange-600 shadow-xs' : 'text-gray-500'
                  }`}
                >
                  JazzCash
                </button>
              </div>

              {/* Amount payable banner */}
              <div className="flex items-center justify-between p-3.5 bg-gray-50 border border-gray-150 rounded-2xl">
                <div>
                  <span className="text-[9px] text-gray-400 font-bold uppercase">Settlement total</span>
                  <p className="text-sm font-extrabold text-gray-900 mt-0.5">Rs. {total.toLocaleString()}</p>
                </div>
                <span className="text-[10px] bg-red-50 text-red-600 font-bold px-2.5 py-1 rounded-lg">
                  Instant Prep
                </span>
              </div>

              {/* Error block */}
              {errors && (
                <div className="p-3 bg-red-50 border border-red-100 text-red-700 rounded-xl text-[11px] font-bold flex items-center gap-1.5">
                  <AlertCircle className="h-4 w-4" />
                  <span>{errors}</span>
                </div>
              )}

              {/* Input forms depending on Payment selector */}
              {method === 'card' ? (
                <div className="space-y-3.5">
                  <div>
                    <label className="block text-[10px] font-extrabold text-gray-400 uppercase tracking-wider mb-1">
                      Cardholder Name
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Muhammad Ali"
                      className="w-full px-3.5 py-2.5 border border-gray-150 focus:border-red-500 rounded-xl text-xs outline-none focus:ring-1 focus:ring-red-100 font-semibold"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-extrabold text-gray-400 uppercase tracking-wider mb-1">
                      Card Number
                    </label>
                    <div className="relative">
                      <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center text-gray-400">
                        <CreditCard className="h-4 w-4" />
                      </span>
                      <input
                        type="text"
                        required
                        maxLength={19}
                        placeholder="4123 4567 8901 2345"
                        value={cardNumber}
                        onChange={(e) => {
                          const val = e.target.value.replace(/\D/g, '').replace(/(.{4})/g, '$1 ').trim();
                          setCardNumber(val);
                        }}
                        className="w-full pl-10 pr-4 py-2.5 border border-gray-150 focus:border-red-500 rounded-xl text-xs outline-none focus:ring-1 focus:ring-red-100 font-semibold font-mono"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3.5">
                    <div>
                      <label className="block text-[10px] font-extrabold text-gray-400 uppercase tracking-wider mb-1">
                        Expiry Date
                      </label>
                      <input
                        type="text"
                        required
                        maxLength={5}
                        placeholder="MM/YY"
                        value={expiry}
                        onChange={(e) => {
                          let val = e.target.value.replace(/\D/g, '');
                          if (val.length > 2) val = `${val.slice(0, 2)}/${val.slice(2, 4)}`;
                          setExpiry(val);
                        }}
                        className="w-full px-3.5 py-2.5 border border-gray-150 focus:border-red-500 rounded-xl text-xs outline-none focus:ring-1 focus:ring-red-100 font-semibold font-mono"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] font-extrabold text-gray-400 uppercase tracking-wider mb-1">
                        CVV / CVC
                      </label>
                      <input
                        type="password"
                        required
                        maxLength={3}
                        placeholder="***"
                        value={cvv}
                        onChange={(e) => setCvv(e.target.value.replace(/\D/g, ''))}
                        className="w-full px-3.5 py-2.5 border border-gray-150 focus:border-red-500 rounded-xl text-xs outline-none focus:ring-1 focus:ring-red-100 font-semibold font-mono"
                      />
                    </div>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  {/* Account Information Card */}
                  <div className="bg-gray-950 text-white rounded-2xl p-4 border border-gray-800 shadow-lg space-y-3 relative overflow-hidden">
                    <div className="absolute top-0 right-0 p-6 bg-red-500/5 rounded-full blur-2xl pointer-events-none" />
                    
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-black uppercase tracking-wider text-gray-400">
                        Transfer Target Account Details
                      </span>
                      <span className={`text-[10px] font-black px-2 py-0.5 rounded-full ${
                        method === 'easypaisa' ? 'bg-emerald-500 text-white' : 'bg-orange-500 text-white'
                      }`}>
                        {method === 'easypaisa' ? 'EasyPaisa' : 'JazzCash'}
                      </span>
                    </div>

                    <div className="space-y-2.5">
                      {/* Mobile Wallet Number */}
                      <div className="flex items-center justify-between bg-gray-900 p-2.5 rounded-xl border border-gray-800">
                        <div>
                          <span className="text-[9px] text-gray-500 font-bold block">MOBILE NUMBER</span>
                          <span className="text-sm font-mono font-extrabold text-white">
                            {method === 'easypaisa' ? paymentSettings.easyPaisaAccountNo : paymentSettings.jazzCashAccountNo}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleCopy(method === 'easypaisa' ? paymentSettings.easyPaisaAccountNo : paymentSettings.jazzCashAccountNo, 'num')}
                          className="text-[10px] bg-gray-800 hover:bg-gray-700 text-gray-300 font-bold px-3 py-1.5 rounded-lg flex items-center gap-1 transition-all"
                        >
                          {copiedText === 'num' ? (
                            <>
                              <Check className="h-3 w-3 text-emerald-400" /> Copied
                            </>
                          ) : (
                            <>
                              <Copy className="h-3 w-3" /> Copy
                            </>
                          )}
                        </button>
                      </div>

                      {/* Till ID (JazzCash only) */}
                      {method === 'jazzcash' && (
                        <div className="flex items-center justify-between bg-gray-900 p-2.5 rounded-xl border border-gray-800">
                          <div>
                            <span className="text-[9px] text-gray-500 font-bold block">TILL ID</span>
                            <span className="text-sm font-mono font-extrabold text-white">{paymentSettings.jazzCashTillId}</span>
                          </div>
                          <button
                            type="button"
                            onClick={() => handleCopy(paymentSettings.jazzCashTillId, 'till')}
                            className="text-[10px] bg-gray-800 hover:bg-gray-700 text-gray-300 font-bold px-3 py-1.5 rounded-lg flex items-center gap-1 transition-all"
                          >
                            {copiedText === 'till' ? (
                              <>
                                <Check className="h-3 w-3 text-emerald-400" /> Copied
                              </>
                            ) : (
                              <>
                                <Copy className="h-3 w-3" /> Copy
                              </>
                            )}
                          </button>
                        </div>
                      )}
                    </div>

                    {/* Urdu Instruction Banner */}
                    <div className="pt-2 border-t border-gray-900 text-right space-y-1" dir="rtl">
                      <p className="text-[11px] text-gray-200 font-bold leading-relaxed">
                        {method === 'easypaisa' 
                          ? 'EasyPaisa سے ادائیگی کے بعد اپنا Transaction ID محفوظ رکھیں۔'
                          : 'JazzCash سے ادائیگی کے بعد اپنا Transaction ID محفوظ رکھیں۔'
                        }
                      </p>
                      <p className="text-[10px] text-gray-400 leading-relaxed font-semibold">
                        {method === 'easypaisa'
                          ? 'ادائیگی کرنے سے پہلے موبائل نمبر اچھی طرح چیک کریں۔'
                          : 'ادائیگی کرنے سے پہلے موبائل نمبر اور Till ID اچھی طرح چیک کریں۔'
                        }
                      </p>
                    </div>
                  </div>

                  {/* Inputs Form */}
                  <div className="space-y-3.5">
                    {/* Sender's wallet account */}
                    <div>
                      <label className="block text-[10px] font-extrabold text-gray-500 uppercase tracking-wider mb-1">
                        Your Mobile Number (جس نمبر سے رقم بھیجی)
                      </label>
                      <div className="relative">
                        <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center text-gray-400">
                          <Smartphone className="h-4 w-4" />
                        </span>
                        <input
                          type="tel"
                          required
                          placeholder="e.g. 03211234567"
                          value={mobileNumber}
                          onChange={(e) => setMobileNumber(e.target.value.replace(/\D/g, ''))}
                          className="w-full pl-10 pr-4 py-2.5 border border-gray-150 focus:border-red-500 rounded-xl text-xs outline-none focus:ring-1 focus:ring-red-100 font-semibold font-mono"
                        />
                      </div>
                    </div>

                    {/* Transaction ID */}
                    <div>
                      <label className="block text-[10px] font-extrabold text-gray-500 uppercase tracking-wider mb-1 flex justify-between">
                        <span>Transaction ID (TID)</span>
                        <span className="text-red-500 text-[9px] font-bold">حاصل کردہ ٹرانزیکشن آئی ڈی</span>
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. 80234567892"
                        value={transactionId}
                        onChange={(e) => setTransactionId(e.target.value)}
                        className="w-full px-3.5 py-2.5 border border-gray-150 focus:border-red-500 rounded-xl text-xs outline-none focus:ring-1 focus:ring-red-100 font-extrabold font-mono"
                      />
                    </div>
                  </div>

                  {/* Support note */}
                  <div className="p-3 bg-red-50 text-red-900 border border-red-100 rounded-xl space-y-1 text-center" dir="rtl">
                    <p className="text-[10px] text-gray-700 leading-normal">
                      اگر ادائیگی کے بعد آرڈر اپڈیٹ نہ ہو تو اس نمبر پر رابطہ کریں:
                    </p>
                    <p className="text-[12px] text-red-600 font-black leading-none" dir="ltr">
                      📞 Support Help Line: 0330-8241277
                    </p>
                  </div>
                </div>
              )}

              {/* Submit trigger */}
              <button
                type="submit"
                className="w-full bg-red-500 hover:bg-red-600 text-white font-bold py-3 rounded-xl text-xs transition-all active:scale-95 flex items-center justify-center gap-1.5 shadow-md shadow-red-500/10 cursor-pointer"
              >
                {method === 'card' 
                  ? `Authorize Payment of Rs. ${total.toLocaleString()}`
                  : 'Verify Receipt & Complete Order'
                }
              </button>
            </form>
          </>
        )}

        {/* Step: PROCESSING LOADER */}
        {step === 'processing' && (
          <div className="p-10 flex flex-col items-center justify-center space-y-6 min-h-[350px] text-center">
            <div className="relative">
              <div className="h-16 w-16 border-4 border-red-100 border-t-red-500 rounded-full animate-spin" />
              <div className="absolute inset-0 flex items-center justify-center text-lg">
                🔐
              </div>
            </div>
            <div className="space-y-1">
              <h4 className="font-display font-black text-gray-900 text-sm">Processing transaction secure link</h4>
              <p className="text-xs text-red-500 font-bold font-mono animate-pulse">{loaderText}</p>
            </div>
            <span className="text-[10px] bg-gray-50 border border-gray-150 text-gray-400 font-semibold px-3 py-1 rounded-full uppercase tracking-wider">
              Do not close this window
            </span>
          </div>
        )}

        {/* Step: SUCCESS */}
        {step === 'success' && (
          <div className="p-10 flex flex-col items-center justify-center space-y-5 min-h-[350px] text-center bg-emerald-50/10">
            <div className="h-16 w-16 bg-emerald-500 text-white rounded-full flex items-center justify-center shadow-lg shadow-emerald-500/20">
              <Check className="h-8 w-8 stroke-[3] animate-bounce" />
            </div>
            <div className="space-y-1">
              <h4 className="font-display font-extrabold text-lg text-emerald-800">Authorization Successful!</h4>
              <p className="text-xs text-gray-400 font-semibold">Your settlement has been approved & logged under secure bank id.</p>
            </div>
            <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-3 py-1.5 rounded-full">
              Settlement ID: LHE-TXN-{Math.floor(100000 + Math.random() * 900000)}
            </span>
          </div>
        )}
      </motion.div>
    </div>
  );
}
