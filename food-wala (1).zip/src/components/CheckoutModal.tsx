import React, { useState } from 'react';
import { X, MapPin, Phone, User, CreditCard, ChevronRight, Check, RotateCcw, Upload } from 'lucide-react';
import { motion } from 'motion/react';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (
    details: { name: string; phone: string; address: string },
    paymentMethod: 'cod' | 'jazzcash' | 'easypaisa' | 'wallet',
    verification?: { transactionId: string; amountPaid: number; screenshot?: string }
  ) => void;
  total: number;
  deliveryMethod: 'delivery' | 'pickup';
  walletBalance: number;
  onOpenWallet: () => void;
}

export default function CheckoutModal({
  isOpen,
  onClose,
  onSubmit,
  total,
  deliveryMethod,
  walletBalance,
  onOpenWallet
}: CheckoutModalProps) {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const paymentSettings = (() => {
    try {
      const saved = localStorage.getItem('foodwala_payment_settings');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return {
      jazzCashActive: true,
      jazzCashAccountNo: '03240732363',
      jazzCashTillId: '980131623',
      easyPaisaActive: true,
      easyPaisaAccountNo: '03240732363',
      codActive: true,
    };
  })();

  const [paymentMethod, setPaymentMethod] = useState<'cod' | 'jazzcash' | 'easypaisa' | 'wallet'>(() => {
    try {
      const saved = localStorage.getItem('foodwala_payment_settings');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.codActive) return 'cod';
        if (parsed.jazzCashActive) return 'jazzcash';
        if (parsed.easyPaisaActive) return 'easypaisa';
      }
    } catch (e) {}
    return 'cod';
  });
  
  // Verification states
  const [transactionId, setTransactionId] = useState('');
  const [amountPaid, setAmountPaid] = useState('');
  const [screenshot, setScreenshot] = useState<string | undefined>(undefined);
  const [screenshotName, setScreenshotName] = useState<string>('');

  const [errors, setErrors] = useState<{
    name?: string;
    phone?: string;
    address?: string;
    transactionId?: string;
    amountPaid?: string;
  }>({});

  if (!isOpen) return null;

  const validate = () => {
    const newErrors: typeof errors = {};
    if (!name.trim()) newErrors.name = 'Full name is required';
    
    if (!phone.trim()) {
      newErrors.phone = 'Phone number is required';
    } else if (!/^\+?92\d{9}$|^03\d{9}$/.test(phone.trim())) {
      newErrors.phone = 'Enter a valid Pakistani phone number (e.g. 03211234567)';
    }
    
    if (deliveryMethod === 'delivery' && !address.trim()) {
      newErrors.address = 'Delivery address is required';
    }

    if (paymentMethod === 'jazzcash' || paymentMethod === 'easypaisa') {
      if (!transactionId.trim()) {
        newErrors.transactionId = 'Transaction ID / Reference Number is required';
      }
      if (!amountPaid.trim()) {
        newErrors.amountPaid = 'Amount Paid is required';
      } else if (isNaN(Number(amountPaid)) || Number(amountPaid) <= 0) {
        newErrors.amountPaid = 'Enter a valid positive paid amount';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setScreenshotName(file.name);
      const reader = new FileReader();
      reader.onloadend = () => {
        setScreenshot(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleReset = () => {
    setTransactionId('');
    setAmountPaid('');
    setScreenshot(undefined);
    setScreenshotName('');
    setErrors({});
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      const verificationDetails = (paymentMethod === 'jazzcash' || paymentMethod === 'easypaisa') ? {
        transactionId: transactionId.trim(),
        amountPaid: Number(amountPaid),
        screenshot
      } : undefined;

      onSubmit(
        {
          name: name.trim(),
          phone: phone.trim(),
          address: deliveryMethod === 'delivery' ? address.trim() : 'Self-Pickup at Store'
        },
        paymentMethod,
        verificationDetails
      );
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-900/60 backdrop-blur-xs">
      {/* Modal Container */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        className="bg-white rounded-3xl overflow-hidden shadow-2xl max-w-lg w-full border border-gray-100 flex flex-col max-h-[90vh]"
      >
        {/* Header */}
        <div className="p-5 border-b border-gray-100 flex items-center justify-between bg-gray-50/50">
          <div>
            <h3 className="font-display font-bold text-lg text-gray-900">Checkout – Payment Verification</h3>
            <p className="text-xs text-gray-400 font-semibold mt-0.5">Choose your payment mode & confirm billing</p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 hover:bg-gray-100 text-gray-400 hover:text-gray-900 rounded-full transition-all cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-4">
          
          {/* User Details Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Contact Name */}
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">
                Contact Name
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400">
                  <User className="h-4 w-4" />
                </span>
                <input
                  type="text"
                  required
                  placeholder="e.g. Muhammad Ali"
                  value={name}
                  onChange={(e) => {
                    setName(e.target.value);
                    if (errors.name) setErrors({ ...errors, name: undefined });
                  }}
                  className={`w-full pl-10 pr-4 py-2 border rounded-xl text-xs outline-none transition-all ${
                    errors.name
                      ? 'border-red-400 focus:ring-1 focus:ring-red-100 focus:border-red-500'
                      : 'border-gray-150 focus:border-red-500 focus:ring-1 focus:ring-red-100'
                  }`}
                />
              </div>
              {errors.name && (
                <p className="text-[10px] text-red-500 font-semibold mt-1">{errors.name}</p>
              )}
            </div>

            {/* Phone Number */}
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">
                Phone Number
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400">
                  <Phone className="h-4 w-4" />
                </span>
                <input
                  type="tel"
                  required
                  placeholder="e.g. 03211234567"
                  value={phone}
                  onChange={(e) => {
                    setPhone(e.target.value);
                    if (errors.phone) setErrors({ ...errors, phone: undefined });
                  }}
                  className={`w-full pl-10 pr-4 py-2 border rounded-xl text-xs outline-none transition-all ${
                    errors.phone
                      ? 'border-red-400 focus:ring-1 focus:ring-red-100 focus:border-red-500'
                      : 'border-gray-150 focus:border-red-500 focus:ring-1 focus:ring-red-100'
                  }`}
                />
              </div>
              {errors.phone && (
                <p className="text-[10px] text-red-500 font-semibold mt-1">{errors.phone}</p>
              )}
            </div>
          </div>

          {/* Delivery Address (Conditional) */}
          {deliveryMethod === 'delivery' ? (
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">
                Delivery Address
              </label>
              <div className="relative font-semibold">
                <span className="absolute top-2.5 left-3.5 text-gray-400">
                  <MapPin className="h-4 w-4" />
                </span>
                <textarea
                  required
                  rows={2}
                  placeholder="e.g. House 45, Street 2, Sector Y, Hyderabad, Sindh"
                  value={address}
                  onChange={(e) => {
                    setAddress(e.target.value);
                    if (errors.address) setErrors({ ...errors, address: undefined });
                  }}
                  className={`w-full pl-10 pr-4 py-2 border rounded-xl text-xs outline-none transition-all resize-none ${
                    errors.address
                      ? 'border-red-400 focus:ring-1 focus:ring-red-100 focus:border-red-500'
                      : 'border-gray-150 focus:border-red-500 focus:ring-1 focus:ring-red-100'
                  }`}
                />
              </div>
              {errors.address && (
                <p className="text-[10px] text-red-500 font-semibold mt-1">{errors.address}</p>
              )}
            </div>
          ) : (
            <div className="bg-yellow-50 text-yellow-800 p-3 rounded-xl border border-yellow-100 text-xs flex gap-2">
              <MapPin className="h-4 w-4 text-yellow-600 flex-shrink-0" />
              <div>
                <p className="font-bold">Self-Pickup Option Selected</p>
                <p className="text-[10px] text-yellow-700 mt-0.5">
                  Your order will be prepared and waiting at the designated restaurant counter. No address required!
                </p>
              </div>
            </div>
          )}

          {/* Select Payment Method */}
          <div>
            <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">
              Select Payment Method
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {/* COD */}
              {paymentSettings.codActive && (
                <div
                  onClick={() => { setPaymentMethod('cod'); handleReset(); }}
                  className={`border p-2.5 rounded-xl cursor-pointer flex flex-col justify-between h-20 transition-all ${
                    paymentMethod === 'cod'
                      ? 'border-red-500 bg-red-50/40 shadow-3xs'
                      : 'border-gray-150 hover:bg-gray-50'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-bold text-gray-950 leading-tight">Cash on Delivery</span>
                    {paymentMethod === 'cod' && (
                      <span className="bg-red-500 text-white rounded-full p-0.5">
                        <Check className="h-2.5 w-2.5" />
                      </span>
                    )}
                  </div>
                  <p className="text-[9px] text-gray-400">💵 Pay on Delivery</p>
                </div>
              )}

              {/* JazzCash */}
              {paymentSettings.jazzCashActive && (
                <div
                  onClick={() => { setPaymentMethod('jazzcash'); handleReset(); }}
                  className={`border p-2.5 rounded-xl cursor-pointer flex flex-col justify-between h-20 transition-all ${
                    paymentMethod === 'jazzcash'
                      ? 'border-purple-600 bg-purple-50/40 shadow-3xs'
                      : 'border-gray-150 hover:bg-gray-50'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-bold text-gray-950 leading-tight">JazzCash</span>
                    {paymentMethod === 'jazzcash' && (
                      <span className="bg-purple-600 text-white rounded-full p-0.5">
                        <Check className="h-2.5 w-2.5" />
                      </span>
                    )}
                  </div>
                  <p className="text-[9px] text-purple-600 font-bold">🟣 Mobile Wallet</p>
                </div>
              )}

              {/* Easypaisa */}
              {paymentSettings.easyPaisaActive && (
                <div
                  onClick={() => { setPaymentMethod('easypaisa'); handleReset(); }}
                  className={`border p-2.5 rounded-xl cursor-pointer flex flex-col justify-between h-20 transition-all ${
                    paymentMethod === 'easypaisa'
                      ? 'border-green-600 bg-green-50/40 shadow-3xs'
                      : 'border-gray-150 hover:bg-gray-50'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-bold text-gray-950 leading-tight">Easypaisa</span>
                    {paymentMethod === 'easypaisa' && (
                      <span className="bg-green-600 text-white rounded-full p-0.5">
                        <Check className="h-2.5 w-2.5" />
                      </span>
                    )}
                  </div>
                  <p className="text-[9px] text-green-600 font-bold">🟢 Mobile Wallet</p>
                </div>
              )}

              {/* Wallet */}
              <div
                onClick={() => { setPaymentMethod('wallet'); handleReset(); }}
                className={`border p-2.5 rounded-xl cursor-pointer flex flex-col justify-between h-20 transition-all ${
                  paymentMethod === 'wallet'
                    ? 'border-amber-500 bg-amber-50/40 shadow-3xs'
                    : 'border-gray-150 hover:bg-gray-50'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold text-gray-950 leading-tight">FoodWala Wallet</span>
                  {paymentMethod === 'wallet' && (
                    <span className="bg-amber-500 text-white rounded-full p-0.5">
                      <Check className="h-2.5 w-2.5" />
                    </span>
                  )}
                </div>
                <p className="text-[9px] text-amber-600 font-black font-mono">
                  💰 Rs. {walletBalance.toFixed(0)}
                </p>
              </div>
            </div>
          </div>

          {/* Conditional Blocks depending on selection */}
          {paymentMethod === 'cod' && (
            <div className="p-3.5 bg-red-50/40 rounded-xl border border-red-100 text-xs text-red-800 space-y-1">
              <div className="flex justify-between items-center font-bold">
                <span>💵 Cash on Delivery (COD)</span>
                <span className="text-[9px] bg-red-100 text-red-700 px-1.5 py-0.5 rounded-md">کیش آن ڈلیوری</span>
              </div>
              <p className="text-[11px] leading-relaxed font-bold text-right font-sans" dir="rtl">
                اپنے آرڈر کی رقم ڈلیوری کے وقت کیش میں ادا کریں۔
              </p>
              <p className="text-[10px] text-gray-500 leading-relaxed font-semibold">
                Cash on Delivery specifies handing over cash to our logistics rider upon physical package handoff.
              </p>
            </div>
          )}

          {paymentMethod === 'wallet' && (
            <div className={`p-3.5 rounded-xl border text-xs space-y-1.5 ${
              walletBalance >= total
                ? 'bg-emerald-50/40 border-emerald-100 text-emerald-850'
                : 'bg-red-50/40 border-red-100 text-red-850'
            }`}>
              <div className="flex justify-between items-center font-extrabold">
                <span className="flex items-center gap-1">🪙 FoodWala Wallet Settlement</span>
                <span className={`text-[8px] font-black uppercase px-2 py-0.5 rounded-md ${
                  walletBalance >= total ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'
                }`}>
                  {walletBalance >= total ? 'Sufficient Balance' : 'Insufficient Balance'}
                </span>
              </div>
              <p className="text-[10.5px] leading-relaxed font-medium">
                {walletBalance >= total
                  ? `Your current wallet balance is Rs. ${walletBalance.toFixed(2)}. Placing this order will instantly settle and deduct Rs. ${total.toFixed(2)}.`
                  : `Your wallet balance of Rs. ${walletBalance.toFixed(2)} is insufficient for this Rs. ${total.toFixed(2)} checkout.`}
              </p>
              {walletBalance < total && (
                <button
                  type="button"
                  onClick={onOpenWallet}
                  className="w-full bg-amber-500 hover:bg-amber-600 text-white font-extrabold py-2 rounded-xl text-[10px] transition-all cursor-pointer shadow-sm active:scale-95"
                >
                  ➕ Deposit Funds to Wallet (رقم جمع کریں)
                </button>
              )}
            </div>
          )}

          {/* JazzCash or Easypaisa details and verification fields */}
          {(paymentMethod === 'jazzcash' || paymentMethod === 'easypaisa') && (
            <div className="space-y-4">
              {/* Payment details block */}
              <div className="bg-slate-900 text-white rounded-2xl p-4 border border-slate-800 space-y-3.5">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <h4 className="text-xs font-black uppercase tracking-wider text-gray-300">
                    Payment Transfer Details
                  </h4>
                  <span className={`text-[9px] font-black px-2 py-0.5 rounded-md text-white uppercase tracking-wider ${
                    paymentMethod === 'jazzcash' ? 'bg-purple-600' : 'bg-green-600'
                  }`}>
                    {paymentMethod === 'jazzcash' ? 'JazzCash' : 'Easypaisa'}
                  </span>
                </div>

                {paymentMethod === 'jazzcash' ? (
                  <div className="space-y-2 text-xs font-medium text-slate-300">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Account Name:</span>
                      <span className="font-extrabold text-white">Mohsin Ali</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Mobile:</span>
                      <span className="font-mono font-black text-purple-400 select-all">0324-0732363</span>
                    </div>
                    <div className="border-t border-slate-800 pt-2 space-y-1.5">
                      <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest block">Till Payment option:</span>
                      <div className="flex justify-between text-[11px]">
                        <span className="text-gray-400">Business Name:</span>
                        <span className="font-bold text-white">MOHSIN MOBILE SHOP</span>
                      </div>
                      <div className="flex justify-between text-[11px]">
                        <span className="text-gray-400">Till ID:</span>
                        <span className="font-mono font-black text-yellow-400 select-all">980131623</span>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-2 text-xs font-medium text-slate-300">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Account Name:</span>
                      <span className="font-extrabold text-white">Mohsin Ali</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Mobile:</span>
                      <span className="font-mono font-black text-green-400 select-all">0324-0732363</span>
                    </div>
                  </div>
                )}
              </div>

              {/* Payment Verification input fields */}
              <div className="bg-gray-50 border border-gray-150 rounded-2xl p-4.5 space-y-4">
                <h4 className="text-xs font-black uppercase tracking-wider text-gray-700 flex items-center justify-between">
                  <span>Payment Verification</span>
                  <span className="text-red-500 font-bold text-[10px]" dir="rtl">ادائیگی کی تصدیق</span>
                </h4>

                {/* Transaction ID */}
                <div>
                  <label className="block text-[10px] font-extrabold text-gray-500 uppercase tracking-wider mb-1.5">
                    Transaction ID / Reference Number
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Enter transaction reference ID"
                    value={transactionId}
                    onChange={(e) => {
                      setTransactionId(e.target.value);
                      if (errors.transactionId) setErrors({ ...errors, transactionId: undefined });
                    }}
                    className={`w-full px-3.5 py-2 border rounded-xl text-xs font-mono font-bold outline-none transition-all ${
                      errors.transactionId
                        ? 'border-red-400 focus:ring-1 focus:ring-red-100 focus:border-red-500'
                        : 'border-gray-250 focus:border-red-500 focus:ring-1 focus:ring-red-100'
                    }`}
                  />
                  {errors.transactionId && (
                    <p className="text-[10px] text-red-500 font-semibold mt-1">{errors.transactionId}</p>
                  )}
                </div>

                {/* Amount Paid */}
                <div>
                  <label className="block text-[10px] font-extrabold text-gray-500 uppercase tracking-wider mb-1.5">
                    Amount Paid (Rs.)
                  </label>
                  <input
                    type="text"
                    required
                    placeholder={`e.g. ${total}`}
                    value={amountPaid}
                    onChange={(e) => {
                      setAmountPaid(e.target.value.replace(/\D/g, ''));
                      if (errors.amountPaid) setErrors({ ...errors, amountPaid: undefined });
                    }}
                    className={`w-full px-3.5 py-2 border rounded-xl text-xs font-mono font-bold outline-none transition-all ${
                      errors.amountPaid
                        ? 'border-red-400 focus:ring-1 focus:ring-red-100 focus:border-red-500'
                        : 'border-gray-250 focus:border-red-500 focus:ring-1 focus:ring-red-100'
                    }`}
                  />
                  {errors.amountPaid && (
                    <p className="text-[10px] text-red-500 font-semibold mt-1">{errors.amountPaid}</p>
                  )}
                </div>

                {/* Optional Screenshot upload */}
                <div>
                  <label className="block text-[10px] font-extrabold text-gray-500 uppercase tracking-wider mb-1.5 flex justify-between items-center">
                    <span>Upload Payment Screenshot (Optional)</span>
                    <span className="text-gray-400 font-bold text-[9px]">تصویر اپلوڈ کریں</span>
                  </label>
                  <div className="flex items-center gap-3">
                    <label className="flex items-center gap-2 px-3 py-2 border border-dashed border-gray-300 hover:border-red-500 bg-white hover:bg-red-50/20 text-gray-600 hover:text-red-600 rounded-xl cursor-pointer text-xs font-bold transition-all select-none">
                      <Upload className="h-4 w-4" />
                      <span>Choose File</span>
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={handleFileChange}
                      />
                    </label>
                    {screenshotName ? (
                      <span className="text-xs text-gray-600 font-mono truncate max-w-[150px] font-bold">
                        {screenshotName}
                      </span>
                    ) : (
                      <span className="text-xs text-gray-400">No file selected</span>
                    )}
                  </div>
                  {screenshot && (
                    <div className="mt-2.5 relative border border-gray-200 rounded-xl overflow-hidden max-w-[140px] aspect-video shadow-3xs">
                      <img src={screenshot} alt="Payment screenshot" className="w-full h-full object-cover" />
                      <button
                        type="button"
                        onClick={() => { setScreenshot(undefined); setScreenshotName(''); }}
                        className="absolute top-1 right-1 bg-gray-900/80 hover:bg-red-600 text-white p-1 rounded-full transition-all"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Payable Summary card */}
          <div className="p-4 bg-gray-50 rounded-2xl flex items-center justify-between border border-gray-100">
            <div>
              <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">Total Payable</p>
              <p className="text-base font-black text-gray-950 mt-0.5">Rs. {total.toLocaleString()}</p>
            </div>
            <div className="bg-red-500 text-white p-2.5 rounded-xl shadow-md">
              <CreditCard className="h-5 w-5" />
            </div>
          </div>

          {/* Control Buttons row */}
          <div className="flex gap-2.5 pt-1">
            {/* Reset Button (only shown/active for JazzCash and Easypaisa) */}
            {(paymentMethod === 'jazzcash' || paymentMethod === 'easypaisa') && (
              <button
                type="button"
                onClick={handleReset}
                className="flex items-center justify-center gap-1.5 px-4 py-3 border border-gray-200 hover:border-red-200 text-gray-500 hover:text-red-500 rounded-xl text-xs font-bold transition-all hover:bg-red-50/10 cursor-pointer"
              >
                <RotateCcw className="h-4 w-4" />
                <span>Reset</span>
              </button>
            )}

            {/* Submit I've Paid */}
            <button
              type="submit"
              disabled={paymentMethod === 'wallet' && walletBalance < total}
              className={`flex-1 py-3 rounded-xl font-bold text-xs tracking-wider uppercase transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-md ${
                paymentMethod === 'wallet' && walletBalance < total
                  ? 'bg-gray-100 text-gray-400 border border-gray-200 cursor-not-allowed font-semibold shadow-none'
                  : 'bg-red-500 hover:bg-red-600 text-white shadow-red-500/10 hover:shadow-red-500/20 active:scale-95'
              }`}
            >
              <span>{paymentMethod === 'wallet' && walletBalance < total ? 'Insufficient Wallet Balance' : "I've Paid"}</span>
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>

          {/* Support Helpline Footer line */}
          <div className="text-center pt-2 border-t border-gray-100">
            <p className="text-[11px] text-gray-400 font-bold">
              📞 Help Desk Support: <span className="text-red-500 hover:underline font-mono">0330-8241277</span>
            </p>
          </div>
        </form>
      </motion.div>
    </div>
  );
}
