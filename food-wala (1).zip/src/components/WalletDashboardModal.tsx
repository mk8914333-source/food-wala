import React, { useState } from 'react';
import { X, Wallet, Plus, ArrowUpLeft, ArrowDownRight, Copy, Check, Sparkles, HelpCircle, AlertCircle, Coins } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { WalletTransaction } from '../types';

interface WalletDashboardModalProps {
  isOpen: boolean;
  onClose: () => void;
  balance: number;
  transactions: WalletTransaction[];
  onAddMoney: (amount: number, channel: 'easypaisa' | 'jazzcash' | 'cash_deposit', senderPhone: string, tid: string) => void;
  onWithdraw: (amount: number, channel: 'easypaisa' | 'jazzcash', accountName: string, accountNo: string) => void;
}

export default function WalletDashboardModal({
  isOpen,
  onClose,
  balance,
  transactions,
  onAddMoney,
  onWithdraw
}: WalletDashboardModalProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'deposit' | 'withdraw'>('overview');
  const [depositAmount, setDepositAmount] = useState('1000');
  const [depositChannel, setDepositChannel] = useState<'easypaisa' | 'jazzcash' | 'cash_deposit'>('easypaisa');
  const [senderPhone, setSenderPhone] = useState('');
  const [tid, setTid] = useState('');
  const [copiedText, setCopiedText] = useState<string | null>(null);

  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [withdrawChannel, setWithdrawChannel] = useState<'easypaisa' | 'jazzcash'>('easypaisa');
  const [withdrawName, setWithdrawName] = useState('');
  const [withdrawNo, setWithdrawNo] = useState('');
  
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(label);
    setTimeout(() => setCopiedText(null), 2000);
  };

  const handleDepositSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSuccessMsg(null);
    setErrorMsg(null);

    const amt = parseFloat(depositAmount);
    if (isNaN(amt) || amt <= 0) {
      setErrorMsg('براہ مہربانی درست رقم درج کریں۔');
      return;
    }

    if (depositChannel !== 'cash_deposit') {
      if (!senderPhone.trim()) {
        setErrorMsg('براہ کرم اپنا موبائل نمبر درج کریں۔');
        return;
      }
      if (tid.trim().length < 8) {
        setErrorMsg('درست ٹرانزیکشن آئی ڈی (TID) درج کریں۔');
        return;
      }
    }

    onAddMoney(amt, depositChannel, senderPhone, tid || `CASH-${Math.floor(Math.random() * 900000)}`);
    setSuccessMsg('ادائیگی کی درخواست موصول ہوگئی ہے۔ ایڈمن کی منظوری کے بعد رقم والٹ میں منتقل کر دی جائے گی۔');
    
    // Clear inputs
    setSenderPhone('');
    setTid('');
    setTimeout(() => {
      setSuccessMsg(null);
      setActiveTab('overview');
    }, 4000);
  };

  const handleWithdrawSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSuccessMsg(null);
    setErrorMsg(null);

    const amt = parseFloat(withdrawAmount);
    if (isNaN(amt) || amt <= 0) {
      setErrorMsg('براہ مہربانی درست رقم درج کریں۔');
      return;
    }

    if (amt > balance) {
      setErrorMsg('والٹ میں ناکافی بیلنس ہے!');
      return;
    }

    if (!withdrawName.trim() || !withdrawNo.trim()) {
      setErrorMsg('براہ کرم تمام خانے پُر کریں۔');
      return;
    }

    onWithdraw(amt, withdrawChannel, withdrawName, withdrawNo);
    setSuccessMsg('رقم نکلوانے (Withdrawal) کی درخواست ایڈمن کو بھیج دی گئی ہے۔ منظوری کے بعد رقم منتقل کر دی جائے گی۔');

    // Clear inputs
    setWithdrawAmount('');
    setWithdrawName('');
    setWithdrawNo('');
    setTimeout(() => {
      setSuccessMsg(null);
      setActiveTab('overview');
    }, 4000);
  };

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case 'deposit': return <ArrowDownRight className="h-4 w-4 text-emerald-500" />;
      case 'payment': return <ArrowUpLeft className="h-4 w-4 text-red-500" />;
      case 'refund': return <ArrowDownRight className="h-4 w-4 text-sky-500 animate-pulse" />;
      case 'cashback': return <Sparkles className="h-4 w-4 text-amber-500 animate-bounce" />;
      case 'withdrawal': return <ArrowUpLeft className="h-4 w-4 text-orange-500" />;
      default: return <Wallet className="h-4 w-4 text-gray-500" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-950/60 backdrop-blur-md">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="bg-white rounded-3xl shadow-2xl max-w-lg w-full overflow-hidden border border-gray-100 flex flex-col max-h-[85vh]"
      >
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between bg-gray-50/50">
          <div className="flex items-center gap-2.5">
            <div className="bg-amber-500/10 text-amber-600 p-2 rounded-xl">
              <Wallet className="h-5 w-5" />
            </div>
            <div>
              <h2 className="font-display font-extrabold text-base text-gray-900 tracking-tight">
                FoodWala Wallet <span className="text-amber-600">والٹ</span>
              </h2>
              <p className="text-[10px] text-gray-400 font-bold tracking-wider uppercase">Secure Settlement Ledger</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 hover:bg-gray-100 text-gray-400 hover:text-gray-900 rounded-xl transition-all"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Tabs navigation */}
        <div className="flex border-b border-gray-100">
          {(['overview', 'deposit', 'withdraw'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => {
                setActiveTab(tab);
                setSuccessMsg(null);
                setErrorMsg(null);
              }}
              className={`flex-1 py-3 text-xs font-black capitalize tracking-tight transition-all border-b-2 ${
                activeTab === tab
                  ? 'border-amber-500 text-amber-600 bg-amber-500/5'
                  : 'border-transparent text-gray-500 hover:text-gray-900 hover:bg-gray-50/50'
              }`}
            >
              {tab === 'overview' && '💳 Balance & History'}
              {tab === 'deposit' && '➕ Add Money (ڈپازٹ)'}
              {tab === 'withdraw' && '💸 Withdraw (رقم نکلوائیں)'}
            </button>
          ))}
        </div>

        {/* Modal Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          <AnimatePresence mode="wait">
            {activeTab === 'overview' && (
              <motion.div
                key="overview-tab"
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10 }}
                className="space-y-5"
              >
                {/* Visual Wallet Credit Card */}
                <div className="bg-gradient-to-br from-amber-650 via-yellow-600 to-amber-700 text-white rounded-3xl p-6 shadow-xl relative overflow-hidden border border-amber-550 flex flex-col justify-between min-h-[170px] transform hover:scale-[1.01] transition-transform duration-300">
                  <div className="absolute top-0 right-0 p-12 bg-white/5 rounded-full blur-3xl pointer-events-none" />
                  <div className="absolute -bottom-6 -left-6 p-12 bg-black/10 rounded-full blur-2xl pointer-events-none" />
                  
                  <div className="flex justify-between items-start">
                    <div>
                      <span className="text-[10px] font-black tracking-widest text-yellow-250 uppercase opacity-90 block">
                        FOODWALA SMART WALLET
                      </span>
                      <span className="text-[9px] font-medium text-amber-100 block mt-0.5" dir="rtl">
                        محفوظ اور تیز ترین ادائیگی کا نظام
                      </span>
                    </div>
                    <Coins className="h-8 w-8 text-yellow-350 shrink-0" />
                  </div>

                  <div>
                    <span className="text-[10px] font-bold text-amber-200 block">Available Balance</span>
                    <span className="text-3xl font-mono font-black tracking-tight text-white flex items-baseline gap-1">
                      Rs. {balance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </span>
                  </div>

                  <div className="flex justify-between items-center pt-2 border-t border-white/10 text-[10px] font-bold text-amber-100">
                    <span>MEMBER PRIVILEGES ACTIVE</span>
                    <span className="flex items-center gap-1">
                      <Sparkles className="h-3 w-3 text-yellow-300" /> 5% Deposit Bonus
                    </span>
                  </div>
                </div>

                {/* Promotional banner */}
                <div className="p-3 bg-amber-50 rounded-2xl border border-amber-100 flex items-start gap-2.5 text-amber-900">
                  <Sparkles className="h-4 w-4 text-amber-600 shrink-0 mt-0.5" />
                  <div className="space-y-0.5">
                    <p className="text-[11px] font-bold">Cashback & Loyalty Rewards Active!</p>
                    <p className="text-[10px] text-gray-500 font-medium">
                      Receive an instant <strong className="text-amber-700">5% Cashback</strong> bonus on all wallet deposits above Rs. 1,000, plus <strong className="text-amber-700">2% Refund Points</strong> on food order payments.
                    </p>
                  </div>
                </div>

                {/* Transaction list history */}
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <h3 className="text-xs font-black uppercase text-gray-500 tracking-wider">Transaction History (تفصیل)</h3>
                    <span className="text-[10px] text-gray-400 font-bold">{transactions.length} records found</span>
                  </div>

                  {transactions.length === 0 ? (
                    <div className="text-center py-8 border border-dashed border-gray-150 rounded-2xl bg-gray-50/50">
                      <Wallet className="h-8 w-8 text-gray-300 mx-auto mb-2" />
                      <p className="text-xs font-bold text-gray-400">کوئی لین دین نہیں پایا گیا</p>
                      <p className="text-[10px] text-gray-400">No wallet activities logged yet.</p>
                    </div>
                  ) : (
                    <div className="space-y-2.5 max-h-[220px] overflow-y-auto pr-1">
                      {transactions.map((tx) => (
                        <div
                          key={tx.id}
                          className="flex items-center justify-between p-3 bg-gray-50 rounded-2xl border border-gray-100/70 hover:border-gray-150 transition-all text-xs"
                        >
                          <div className="flex gap-2.5 items-center">
                            <div className="bg-white p-2 rounded-xl border border-gray-100 shadow-xs">
                              {getTransactionIcon(tx.type)}
                            </div>
                            <div>
                              <div className="flex items-center gap-1.5">
                                <span className="font-extrabold text-gray-900 capitalize">
                                  {tx.type === 'deposit' && 'Deposited Funds'}
                                  {tx.type === 'payment' && 'Order Payment'}
                                  {tx.type === 'refund' && 'Order Refund'}
                                  {tx.type === 'cashback' && 'Cashback Benefit'}
                                  {tx.type === 'withdrawal' && 'Withdraw Funds'}
                                </span>
                                {tx.status === 'pending' && (
                                  <span className="bg-amber-100 text-amber-700 text-[8px] font-black px-1.5 py-0.5 rounded uppercase">
                                    Pending Approval
                                  </span>
                                )}
                                {tx.status === 'failed' && (
                                  <span className="bg-red-100 text-red-700 text-[8px] font-black px-1.5 py-0.5 rounded uppercase">
                                    Rejected
                                  </span>
                                )}
                              </div>
                              <p className="text-[10px] text-gray-400 font-semibold mt-0.5">
                                {tx.channel && `${tx.channel.replace('_', ' ').toUpperCase()} • `}
                                {tx.referenceId && `Ref: ${tx.referenceId} • `}
                                {tx.timestamp}
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <span className={`font-mono font-black text-xs ${
                              tx.type === 'deposit' || tx.type === 'refund' || tx.type === 'cashback'
                                ? 'text-emerald-600'
                                : 'text-gray-800'
                            }`}>
                              {tx.type === 'deposit' || tx.type === 'refund' || tx.type === 'cashback' ? '+' : '-'}
                              Rs. {tx.amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                            </span>
                            {tx.notes && <p className="text-[9px] text-gray-400 italic mt-0.5">{tx.notes}</p>}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </motion.div>
            )}

            {activeTab === 'deposit' && (
              <motion.div
                key="deposit-tab"
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                className="space-y-4"
              >
                {successMsg ? (
                  <div className="p-4 bg-emerald-50 text-emerald-800 border border-emerald-150 rounded-2xl text-center space-y-2">
                    <Check className="h-8 w-8 text-emerald-500 mx-auto" />
                    <p className="text-xs font-bold leading-relaxed">{successMsg}</p>
                  </div>
                ) : (
                  <form onSubmit={handleDepositSubmit} className="space-y-4">
                    {errorMsg && (
                      <div className="p-3 bg-red-50 text-red-800 border border-red-100 rounded-xl text-xs flex gap-2 items-center font-bold">
                        <AlertCircle className="h-4 w-4 text-red-500 shrink-0" />
                        <span>{errorMsg}</span>
                      </div>
                    )}

                    {/* Choose channel */}
                    <div className="space-y-2">
                      <label className="block text-[10px] font-black text-gray-500 uppercase tracking-wider">
                        Select Settlement Channel
                      </label>
                      <div className="grid grid-cols-3 gap-2">
                        {([
                          { id: 'easypaisa', label: 'EasyPaisa', style: 'border-emerald-100 bg-emerald-50/20 text-emerald-800' },
                          { id: 'jazzcash', label: 'JazzCash', style: 'border-orange-100 bg-orange-50/20 text-orange-800' },
                          { id: 'cash_deposit', label: 'Cash Deposit', style: 'border-blue-100 bg-blue-50/20 text-blue-800' }
                        ] as const).map((ch) => {
                          const isSelected = depositChannel === ch.id;
                          return (
                            <button
                              key={ch.id}
                              type="button"
                              onClick={() => {
                                setDepositChannel(ch.id);
                                setErrorMsg(null);
                              }}
                              className={`p-3 text-center border-2 rounded-2xl flex flex-col items-center justify-center gap-1.5 transition-all font-bold ${
                                isSelected
                                  ? 'border-amber-500 ring-2 ring-amber-100 bg-amber-50/20'
                                  : 'border-gray-150 hover:bg-gray-50 text-gray-600'
                              }`}
                            >
                              <span className="text-xs">{ch.label}</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* Account Details Box */}
                    {depositChannel !== 'cash_deposit' ? (
                      <div className="bg-gray-900 text-white rounded-2xl p-4 border border-gray-800 space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="text-[9px] font-black text-gray-400 uppercase tracking-wider">
                            Transfer Money to our Account
                          </span>
                          <span className="text-[10px] bg-red-500 text-white font-extrabold px-2 py-0.5 rounded-full">
                            OFFICIAL WALLET
                          </span>
                        </div>

                        <div className="space-y-2">
                          <div className="flex items-center justify-between bg-gray-950 p-2.5 rounded-xl border border-gray-800">
                            <div>
                              <span className="text-[9px] text-gray-500 font-bold block">MOBILE WALLET NUMBER</span>
                              <span className="text-sm font-mono font-black text-white">0324-0732363</span>
                            </div>
                            <button
                              type="button"
                              onClick={() => handleCopy('03240732363', 'official_num')}
                              className="text-[10px] bg-gray-800 hover:bg-gray-750 text-gray-300 px-3 py-1.5 rounded-lg flex items-center gap-1 transition-all"
                            >
                              {copiedText === 'official_num' ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
                              {copiedText === 'official_num' ? 'Copied' : 'Copy'}
                            </button>
                          </div>

                          {depositChannel === 'jazzcash' && (
                            <div className="flex items-center justify-between bg-gray-950 p-2.5 rounded-xl border border-gray-800">
                              <div>
                                <span className="text-[9px] text-gray-500 font-bold block">TILL ID</span>
                                <span className="text-sm font-mono font-black text-white">980131623</span>
                              </div>
                              <button
                                type="button"
                                onClick={() => handleCopy('980131623', 'official_till')}
                                className="text-[10px] bg-gray-800 hover:bg-gray-750 text-gray-300 px-3 py-1.5 rounded-lg flex items-center gap-1 transition-all"
                              >
                                {copiedText === 'official_till' ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
                                {copiedText === 'official_till' ? 'Copied' : 'Copy'}
                              </button>
                            </div>
                          )}
                        </div>

                        <div className="text-right text-[11px] text-gray-300 font-semibold space-y-0.5 leading-relaxed" dir="rtl">
                          <p>آسان پیسہ یا جیز کیش سے ادائیگی کے بعد اپنی رسید سے معلومات نیچے درج کریں۔</p>
                          <p className="text-[10px] text-gray-400">ادائیگی کی تصدیق ایڈمن کی طرف سے کی جائے گی۔</p>
                        </div>
                      </div>
                    ) : (
                      <div className="bg-blue-50/50 rounded-2xl p-4 border border-blue-100 text-blue-900 space-y-1.5 text-xs">
                        <h4 className="font-bold">💵 Cash Deposit Guideline (کیش ڈپازٹ گائیڈ لائن)</h4>
                        <p className="text-[11px] leading-relaxed text-gray-600">
                          نقد رقم کے ذریعے والٹ بیلنس بڑھانے کے لیے ہمارے ہیلپ لائن نمائندے سے <strong>0330-8241277</strong> پر رابطہ کریں۔ نمائندہ نقد ادائیگی کی وصولی کے بعد آپ کا والٹ بیلنس فوری طور پر اپ ڈیٹ کر دے گا۔
                        </p>
                      </div>
                    )}

                    {/* Amount Input */}
                    <div className="grid grid-cols-2 gap-3.5">
                      <div>
                        <label className="block text-[10px] font-black text-gray-500 uppercase tracking-wider mb-1">
                          Amount (رقم)
                        </label>
                        <input
                          type="number"
                          required
                          min="100"
                          step="100"
                          value={depositAmount}
                          onChange={(e) => setDepositAmount(e.target.value)}
                          className="w-full px-3.5 py-2.5 border border-gray-150 focus:border-amber-500 rounded-xl text-xs font-mono font-extrabold outline-none"
                        />
                      </div>

                      {depositChannel !== 'cash_deposit' && (
                        <div>
                          <label className="block text-[10px] font-black text-gray-500 uppercase tracking-wider mb-1">
                            Your Phone (رقم بھیجنے والا نمبر)
                          </label>
                          <input
                            type="tel"
                            required
                            placeholder="e.g. 03001234567"
                            value={senderPhone}
                            onChange={(e) => setSenderPhone(e.target.value.replace(/\D/g, ''))}
                            className="w-full px-3.5 py-2.5 border border-gray-150 focus:border-amber-500 rounded-xl text-xs font-mono font-extrabold outline-none"
                          />
                        </div>
                      )}
                    </div>

                    {depositChannel !== 'cash_deposit' && (
                      <div>
                        <label className="block text-[10px] font-black text-gray-500 uppercase tracking-wider mb-1 flex justify-between">
                          <span>Transaction ID (TID)</span>
                          <span className="text-red-500 text-[9px] font-black">ٹرانزیکشن آئی ڈی</span>
                        </label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. 8012345678"
                          value={tid}
                          onChange={(e) => setTid(e.target.value)}
                          className="w-full px-3.5 py-2.5 border border-gray-150 focus:border-amber-500 rounded-xl text-xs font-mono font-extrabold outline-none"
                        />
                      </div>
                    )}

                    <button
                      type="submit"
                      className="w-full bg-amber-500 hover:bg-amber-600 text-white font-extrabold py-3 rounded-2xl text-xs shadow-md shadow-amber-500/10 cursor-pointer transition-all active:scale-95"
                    >
                      Submit Deposit Settlement Verification
                    </button>
                  </form>
                )}
              </motion.div>
            )}

            {activeTab === 'withdraw' && (
              <motion.div
                key="withdraw-tab"
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                className="space-y-4"
              >
                {successMsg ? (
                  <div className="p-4 bg-emerald-50 text-emerald-800 border border-emerald-150 rounded-2xl text-center space-y-2">
                    <Check className="h-8 w-8 text-emerald-500 mx-auto" />
                    <p className="text-xs font-bold leading-relaxed">{successMsg}</p>
                  </div>
                ) : (
                  <form onSubmit={handleWithdrawSubmit} className="space-y-4">
                    {errorMsg && (
                      <div className="p-3 bg-red-50 text-red-800 border border-red-100 rounded-xl text-xs flex gap-2 items-center font-bold">
                        <AlertCircle className="h-4 w-4 text-red-500 shrink-0" />
                        <span>{errorMsg}</span>
                      </div>
                    )}

                    {/* Disclaimer */}
                    <div className="p-3 bg-amber-50 text-amber-900 border border-amber-100 rounded-2xl space-y-1 text-[11px] leading-relaxed">
                      <div className="flex gap-1.5 items-center font-bold text-amber-700">
                        <HelpCircle className="h-4 w-4" />
                        <span>Withdrawal Guideline (رقم نکلوانے کی معلومات)</span>
                      </div>
                      <p className="text-gray-600 font-semibold leading-relaxed" dir="rtl">
                        والٹ بیلنس کو اپنے ذاتی موبائل والٹ (EasyPaisa یا JazzCash) میں واپس بھیجنے کے لیے فارم جمع کریں۔ رقم 12 گھنٹے کے اندر آپ کے کھاتے میں منتقل کر دی جائے گی۔
                      </p>
                    </div>

                    {/* Choose channel */}
                    <div className="space-y-2">
                      <label className="block text-[10px] font-black text-gray-500 uppercase tracking-wider">
                        Payout Mobile Wallet Channel
                      </label>
                      <div className="grid grid-cols-2 gap-2">
                        {([
                          { id: 'easypaisa', label: 'EasyPaisa Payout' },
                          { id: 'jazzcash', label: 'JazzCash Payout' }
                        ] as const).map((ch) => {
                          const isSelected = withdrawChannel === ch.id;
                          return (
                            <button
                              key={ch.id}
                              type="button"
                              onClick={() => {
                                setWithdrawChannel(ch.id);
                                setErrorMsg(null);
                              }}
                              className={`p-3 text-center border-2 rounded-2xl flex flex-col items-center justify-center gap-1.5 transition-all font-bold ${
                                isSelected
                                  ? 'border-amber-500 ring-2 ring-amber-100 bg-amber-50/20 text-amber-800'
                                  : 'border-gray-150 hover:bg-gray-50 text-gray-600'
                              }`}
                            >
                              <span className="text-xs">{ch.label}</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* Form fields */}
                    <div className="space-y-3">
                      <div>
                        <label className="block text-[10px] font-black text-gray-500 uppercase tracking-wider mb-1">
                          Withdrawal Amount (رقم)
                        </label>
                        <input
                          type="number"
                          required
                          min="100"
                          max={balance}
                          placeholder={`Max: Rs. ${balance.toFixed(0)}`}
                          value={withdrawAmount}
                          onChange={(e) => setWithdrawAmount(e.target.value)}
                          className="w-full px-3.5 py-2.5 border border-gray-150 focus:border-amber-500 rounded-xl text-xs font-mono font-extrabold outline-none"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[10px] font-black text-gray-500 uppercase tracking-wider mb-1">
                            Account Name (کھاتہ دار کا نام)
                          </label>
                          <input
                            type="text"
                            required
                            placeholder="e.g. Ahmad Butt"
                            value={withdrawName}
                            onChange={(e) => setWithdrawName(e.target.value)}
                            className="w-full px-3.5 py-2.5 border border-gray-150 focus:border-amber-500 rounded-xl text-xs outline-none"
                          />
                        </div>

                        <div>
                          <label className="block text-[10px] font-black text-gray-500 uppercase tracking-wider mb-1">
                            Account Number (موبائل نمبر)
                          </label>
                          <input
                            type="tel"
                            required
                            placeholder="e.g. 03211234567"
                            value={withdrawNo}
                            onChange={(e) => setWithdrawNo(e.target.value.replace(/\D/g, ''))}
                            className="w-full px-3.5 py-2.5 border border-gray-150 focus:border-amber-500 rounded-xl text-xs font-mono font-extrabold outline-none"
                          />
                        </div>
                      </div>
                    </div>

                    <button
                      type="submit"
                      className="w-full bg-red-500 hover:bg-red-600 text-white font-extrabold py-3 rounded-2xl text-xs shadow-md shadow-red-500/10 cursor-pointer transition-all active:scale-95"
                    >
                      Authorize Wallet Liquidation Request
                    </button>
                  </form>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Modal Footer Helpline info */}
        <div className="px-6 py-4 bg-gray-50 border-t border-gray-100 flex items-center justify-between">
          <p className="text-[10px] text-gray-400 font-bold">
            🔒 SECURED BANK-GRADE DOUBLE ENCRYPTED LEDGER
          </p>
          <p className="text-[10px] text-gray-400 font-bold">
            📞 Helpline: <span className="text-red-500 font-extrabold hover:underline">0330-8241277</span>
          </p>
        </div>
      </motion.div>
    </div>
  );
}
