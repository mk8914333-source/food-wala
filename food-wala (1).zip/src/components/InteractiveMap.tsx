import React, { useState, useEffect } from 'react';
import { MapPin, Navigation, Compass, Map, ShieldCheck, Heart } from 'lucide-react';
import { motion } from 'motion/react';

interface InteractiveMapProps {
  restaurantId: string;
  restaurantName: string;
  customerAddress: string;
  orderStatus: 'received' | 'preparing' | 'delivery' | 'delivered';
  onRiderArrived?: () => void;
}

const LANDMARKS = [
  { name: 'Gulberg (Main Blvd)', x: 140, y: 80 },
  { name: 'Model Town Park', x: 260, y: 150 },
  { name: 'DHA Phase 5', x: 380, y: 110 },
  { name: 'Johar Town', x: 80, y: 220 },
  { name: 'Liberty Market', x: 210, y: 60 }
];

export default function InteractiveMap({
  restaurantId,
  restaurantName,
  customerAddress,
  orderStatus,
  onRiderArrived
}: InteractiveMapProps) {
  // Coordinates of our delivery nodes
  const restaurantCoords = { x: 100, y: 90 }; // Starting point (e.g. Biryani House in Gulberg)
  const customerCoords = { x: 320, y: 180 };   // Ending point (e.g. DHA)

  const [riderPos, setRiderPos] = useState({ x: restaurantCoords.x, y: restaurantCoords.y });
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (orderStatus === 'received' || orderStatus === 'preparing') {
      // Rider is waiting at the restaurant
      setRiderPos(restaurantCoords);
      setProgress(0);
    } else if (orderStatus === 'delivery') {
      // Rider is moving towards customer
      let currentProgress = 0;
      const interval = setInterval(() => {
        currentProgress += 2;
        if (currentProgress >= 100) {
          currentProgress = 100;
          clearInterval(interval);
          if (onRiderArrived) onRiderArrived();
        }
        
        setProgress(currentProgress);

        // Interpolate position along the path with a slight curve
        const ratio = currentProgress / 100;
        const nextX = restaurantCoords.x + (customerCoords.x - restaurantCoords.x) * ratio;
        const nextY = restaurantCoords.y + (customerCoords.y - restaurantCoords.y) * ratio - Math.sin(ratio * Math.PI) * 20; // curve offset

        setRiderPos({ x: nextX, y: nextY });
      }, 350);

      return () => clearInterval(interval);
    } else if (orderStatus === 'delivered') {
      // Rider has successfully delivered
      setRiderPos(customerCoords);
      setProgress(100);
    }
  }, [orderStatus, restaurantId]);

  // Dynamic status coordinates
  const latVal = (31.5204 + (riderPos.y / 1000)).toFixed(5);
  const lngVal = (74.3587 + (riderPos.x / 1000)).toFixed(5);

  return (
    <div className="bg-gray-50 border border-gray-150 rounded-3xl p-5 md:p-6 space-y-4 shadow-2xs relative overflow-hidden">
      {/* Top Map Meta details */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-gray-200/50 pb-3">
        <div className="flex items-center gap-2">
          <div className="bg-red-500 text-white p-1.5 rounded-xl">
            <Map className="h-4 w-4" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-gray-800 flex items-center gap-1.5">
              FoodWala Live Tracker Map <span className="text-[10px] bg-red-100 text-red-600 px-2 py-0.5 rounded-full font-black">Hyderabad, Sindh, PK</span>
            </h4>
            <p className="text-[10px] text-gray-400 font-semibold">Simulated tracking of your rider via OpenStreetMap coordinates</p>
          </div>
        </div>

        <div className="flex items-center gap-3 text-[10px] font-mono font-bold text-gray-500 bg-white px-2.5 py-1.5 rounded-xl border border-gray-150">
          <Compass className="h-3.5 w-3.5 text-gray-400 animate-spin" style={{ animationDuration: '6s' }} />
          <span>{latVal}° N, {lngVal}° E</span>
        </div>
      </div>

      {/* Map visual canvas representation */}
      <div className="relative w-full h-56 bg-slate-100 rounded-2xl overflow-hidden border border-gray-200/60 shadow-inner">
        {/* Abstract road grid backdrop pattern */}
        <svg className="absolute inset-0 w-full h-full opacity-20 pointer-events-none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="road-grid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#4b5563" strokeWidth="1" />
              <circle cx="20" cy="20" r="1.5" fill="#4b5563" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#road-grid)" />
          
          {/* Main Simulated Express Road link */}
          <path
            d={`M ${restaurantCoords.x} ${restaurantCoords.y} Q ${(restaurantCoords.x + customerCoords.x)/2} ${(restaurantCoords.y + customerCoords.y)/2 - 40} ${customerCoords.x} ${customerCoords.y}`}
            fill="none"
            stroke="#94a3b8"
            strokeWidth="4"
            strokeDasharray="6 4"
          />
        </svg>

        {/* Landmarks text */}
        {LANDMARKS.map((mark) => (
          <div
            key={mark.name}
            style={{ left: `${mark.x}px`, top: `${mark.y}px` }}
            className="absolute -translate-x-1/2 -translate-y-1/2 select-none pointer-events-none flex flex-col items-center"
          >
            <span className="h-1.5 w-1.5 bg-gray-300 rounded-full mb-1" />
            <span className="text-[9px] text-gray-400 font-bold bg-white/70 px-1.5 py-0.5 rounded-md backdrop-blur-xs whitespace-nowrap">
              {mark.name}
            </span>
          </div>
        ))}

        {/* Start node: Restaurant */}
        <div
          style={{ left: `${restaurantCoords.x}px`, top: `${restaurantCoords.y}px` }}
          className="absolute -translate-x-1/2 -translate-y-1/2 z-10 flex flex-col items-center"
        >
          <div className="relative">
            <span className="absolute -inset-2 bg-red-500/20 rounded-full animate-ping" />
            <div className="h-8 w-8 bg-red-500 border-2 border-white rounded-full flex items-center justify-center text-white shadow-md">
              🍔
            </div>
          </div>
          <span className="text-[9px] font-extrabold text-white bg-red-500 px-1.5 py-0.5 rounded-md mt-1 shadow-sm whitespace-nowrap">
            {restaurantName}
          </span>
        </div>

        {/* End node: Customer House */}
        <div
          style={{ left: `${customerCoords.x}px`, top: `${customerCoords.y}px` }}
          className="absolute -translate-x-1/2 -translate-y-1/2 z-10 flex flex-col items-center"
        >
          <div className="relative">
            <span className="absolute -inset-2 bg-emerald-500/20 rounded-full animate-ping" />
            <div className="h-8 w-8 bg-emerald-500 border-2 border-white rounded-full flex items-center justify-center text-white shadow-md">
              🏠
            </div>
          </div>
          <span className="text-[9px] font-extrabold text-white bg-emerald-500 px-1.5 py-0.5 rounded-md mt-1 shadow-sm whitespace-nowrap">
            {customerAddress.length > 10 ? `${customerAddress.slice(0, 8)}...` : customerAddress}
          </span>
        </div>

        {/* Movable Rider Scooter node */}
        <div
          style={{ left: `${riderPos.x}px`, top: `${riderPos.y}px` }}
          className="absolute -translate-x-1/2 -translate-y-1/2 z-20 flex flex-col items-center transition-all duration-300 ease-out"
        >
          <div className="relative">
            <div className="h-8 w-8 bg-amber-500 border-2 border-white rounded-full flex items-center justify-center text-white shadow-lg animate-bounce">
              🏍️
            </div>
          </div>
          <span className="text-[9px] font-black text-gray-900 bg-white border border-amber-200 px-1.5 py-0.5 rounded-md mt-1 shadow-xs whitespace-nowrap flex items-center gap-0.5">
            <Navigation className="h-2 w-2 text-amber-500 animate-pulse" /> Rider {progress}%
          </span>
        </div>
      </div>

      {/* Map status summary cards */}
      <div className="grid grid-cols-2 gap-3">
        <div className="p-3 bg-white border border-gray-150 rounded-2xl text-xs flex items-center gap-2">
          <div className="h-8 w-8 bg-gray-50 rounded-xl flex items-center justify-center text-gray-500 text-lg">
            🗺️
          </div>
          <div>
            <p className="text-[9px] text-gray-400 font-bold uppercase">Estimated route</p>
            <p className="text-[11px] font-black text-gray-800">Gulberg ➔ DHA Phase 5</p>
          </div>
        </div>

        <div className="p-3 bg-white border border-gray-150 rounded-2xl text-xs flex items-center gap-2">
          <div className="h-8 w-8 bg-gray-50 rounded-xl flex items-center justify-center text-gray-500 text-lg">
            🛡️
          </div>
          <div>
            <p className="text-[9px] text-gray-400 font-bold uppercase">Safety standard</p>
            <p className="text-[11px] font-black text-emerald-600 flex items-center gap-1">
              <ShieldCheck className="h-3.5 w-3.5" /> Hygiene Certified
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
