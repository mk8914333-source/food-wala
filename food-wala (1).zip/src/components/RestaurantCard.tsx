import React from 'react';
import { Star, Clock, Heart, ArrowRight } from 'lucide-react';
import { Restaurant } from '../types';
import { motion } from 'motion/react';

interface RestaurantCardProps {
  key?: string;
  restaurant: Restaurant;
  onSelect: (restaurant: Restaurant) => void;
}

export default function RestaurantCard({ restaurant, onSelect }: RestaurantCardProps) {
  return (
    <motion.div
      layout
      whileHover={{ y: -4 }}
      transition={{ duration: 0.2 }}
      className="bg-white rounded-3xl overflow-hidden border border-gray-100 shadow-xs hover:shadow-xl transition-all duration-300 group cursor-pointer flex flex-col h-full"
      onClick={() => onSelect(restaurant)}
      id={`restaurant-card-${restaurant.id}`}
    >
      {/* Restaurant Image Banner */}
      <div className="relative h-48 overflow-hidden bg-gray-100">
        <img
          src={restaurant.image}
          alt={restaurant.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 ease-out"
          loading="lazy"
          referrerPolicy="no-referrer"
        />
        
        {/* Rating Floating Badge */}
        <div className="absolute top-3 left-3 bg-white/95 backdrop-blur-xs px-2.5 py-1 rounded-full shadow-xs flex items-center gap-1">
          <Star className="h-3.5 w-3.5 fill-yellow-400 text-yellow-400" />
          <span className="text-xs font-bold text-gray-800">{restaurant.rating}</span>
          <span className="text-[10px] text-gray-400">({restaurant.reviewsCount})</span>
        </div>

        {/* Prep Time Floating Badge */}
        <div className="absolute top-3 right-3 bg-red-500 text-white px-2.5 py-1 rounded-full shadow-xs flex items-center gap-1 font-semibold text-xs">
          <Clock className="h-3.5 w-3.5" />
          <span>{restaurant.prepTime}</span>
        </div>
        
        {/* Hotel Badge */}
        {restaurant.isHotel && (
          <div className="absolute top-12 right-3 bg-indigo-500 text-white px-2.5 py-1 rounded-full shadow-xs flex items-center gap-1 font-semibold text-xs">
            Hotel
          </div>
        )}
      </div>

      {/* Restaurant Info */}
      <div className="p-5 flex flex-col flex-grow">
        <div className="flex justify-between items-start gap-2 mb-2">
          <h3 className="font-display font-bold text-lg text-gray-900 group-hover:text-red-500 transition-colors">
            {restaurant.name}
          </h3>
          <button 
            onClick={(e) => {
              e.stopPropagation();
              // Simulating toggle favorite
            }}
            className="p-1.5 rounded-full hover:bg-gray-50 text-gray-400 hover:text-red-500 transition-all active:scale-90"
          >
            <Heart className="h-4.5 w-4.5" />
          </button>
        </div>

        <p className="text-xs text-gray-500 mb-3 font-medium">
          {restaurant.tags.join(' • ')}
        </p>

        {/* Bottom Details Footer */}
        <div className="mt-auto pt-4 border-t border-gray-50 flex items-center justify-between text-xs font-semibold text-gray-600">
          <div>
            <span className="text-gray-400 font-medium">Min:</span> Rs. {restaurant.minOrder}
          </div>
          <div>
            <span className="text-gray-400 font-medium">Delivery:</span> Rs. {restaurant.deliveryFee}
          </div>
          
          <span className="text-red-500 flex items-center gap-1 group-hover:translate-x-1 transition-transform">
            View Menu <ArrowRight className="h-3.5 w-3.5" />
          </span>
        </div>
      </div>
    </motion.div>
  );
}
