import { Restaurant, PromoCode } from './types';

export const RESTAURANTS: Restaurant[] = [
  {
    id: 'kfc',
    name: 'KFC',
    category: 'Fast Food',
    rating: 4.8,
    reviewsCount: 1240,
    image: 'https://images.unsplash.com/photo-1513639776629-7b61b0ac49cb?auto=format&fit=crop&w=600&q=80',
    tags: ['Burgers', 'Fried Chicken', 'Fast Food'],
    prepTime: '15-25 min',
    minOrder: 300,
    deliveryFee: 100,
    ownerId: 'rest-owner-1',
    status: 'active',
    isHotel: false,
    menu: [
      {
        id: 'kfc-zinger',
        name: 'Zinger Burger',
        price: 650,
        description: 'Our signature crispy, golden-fried chicken breast fillet topped with crunchy lettuce and creamy mayo, all tucked inside a fresh sesame seed bun.',
        image: 'https://images.unsplash.com/photo-1625813506062-0aeb1d7a094b?auto=format&fit=crop&w=400&q=80',
        category: 'Main',
        isPopular: true
      },
      {
        id: 'kfc-wings',
        name: 'Hot Wings (10 Pcs)',
        price: 550,
        description: 'Ten pieces of bone-in chicken wings, marinated in a fiery blend of peppers and spices, double breaded and cooked to absolute crunchiness.',
        image: 'https://images.unsplash.com/photo-1567620832903-9fc6debc209f?auto=format&fit=crop&w=400&q=80',
        category: 'Main',
        isPopular: true
      },
      {
        id: 'kfc-fries',
        name: 'French Fries (Large)',
        price: 250,
        description: 'Fluffy inside and golden-crisp outside premium potatoes, lightly sprinkled with dynamic table salt. The perfect companion to any meal.',
        image: 'https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&w=400&q=80',
        category: 'Side',
        isVegetarian: true
      },
      {
        id: 'kfc-krusher',
        name: 'Oreo Krusher',
        price: 350,
        description: 'A decadent, rich, and creamy blended vanilla milkshake loaded with chunks of crunchy Oreo cookies, whipped cream, and chocolate syrup.',
        image: 'https://images.unsplash.com/photo-1572490122747-3968b75cc699?auto=format&fit=crop&w=400&q=80',
        category: 'Beverage'
      }
    ]
  },
  {
    id: 'mcdonalds',
    name: "McDonald's",
    category: 'Burgers',
    rating: 4.7,
    reviewsCount: 980,
    image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=600&q=80',
    tags: ['Burgers', 'American', 'Shakes'],
    prepTime: '20-30 min',
    minOrder: 250,
    deliveryFee: 120,
    ownerId: 'rest-owner-2',
    status: 'active',
    isHotel: false,
    menu: [
      {
        id: 'mcd-bigmac',
        name: 'Big Mac Burger',
        price: 850,
        description: 'Two 100% pure beef patties, slice of melted cheese, crisp shredded lettuce, pickles, minced onions, and our legendary Big Mac special sauce on a sesame seed bun.',
        image: 'https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=400&q=80',
        category: 'Main',
        isPopular: true
      },
      {
        id: 'mcd-mcchicken',
        name: 'McChicken',
        price: 580,
        description: 'A crispy chicken patty seasoned perfectly, topped with fresh, crispy shredded lettuce and just the right amount of classic mayo on a toasted bun.',
        image: 'https://images.unsplash.com/photo-1606755962773-d324e0a13086?auto=format&fit=crop&w=400&q=80',
        category: 'Main'
      },
      {
        id: 'mcd-fries',
        name: 'World Famous Fries',
        price: 250,
        description: 'Our world-famous golden fries, crispy on the outside, soft on the inside. Sourced from high-quality Russet potatoes for that signature McDonald’s taste.',
        image: 'https://images.unsplash.com/photo-1630384060421-cb20d0e0649d?auto=format&fit=crop&w=400&q=80',
        category: 'Side',
        isVegetarian: true
      },
      {
        id: 'mcd-pie',
        name: 'Apple Pie',
        price: 290,
        description: 'Our warm, turnover-style apple pie features sweet apples baked with cinnamon in a crisp, flaky, sugar-dusted pastry lattice.',
        image: 'https://images.unsplash.com/photo-1519869325930-281384150729?auto=format&fit=crop&w=400&q=80',
        category: 'Dessert',
        isVegetarian: true
      }
    ]
  },
  {
    id: 'pizza-point',
    name: 'Pizza Point',
    category: 'Pizza',
    rating: 4.6,
    reviewsCount: 845,
    image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=600&q=80',
    tags: ['Pizza', 'Italian', 'Pasta'],
    prepTime: '25-35 min',
    minOrder: 400,
    deliveryFee: 150,
    ownerId: 'rest-owner-3',
    status: 'active',
    isHotel: true,
    menu: [
      {
        id: 'pizza-tikka',
        name: 'Chicken Tikka Pizza',
        price: 1200,
        description: 'A local specialty! Loaded with smoky, spiced Pakistani chicken tikka chunks, sliced sweet onions, bell peppers, fresh cilantro, and gooey premium mozzarella.',
        image: 'https://images.unsplash.com/photo-1593560708920-61dd98c46a4e?auto=format&fit=crop&w=400&q=80',
        category: 'Main',
        isPopular: true
      },
      {
        id: 'pizza-cheese',
        name: "Cheese Lover's Pizza",
        price: 1100,
        description: 'An absolute heaven for cheese devotees. Featuring a rich blend of seasoned Italian pizza sauce, cheddar, parmesan, and double-strength mozzarella cheese.',
        image: 'https://images.unsplash.com/photo-1574071318508-1cdbab80d002?auto=format&fit=crop&w=400&q=80',
        category: 'Main',
        isVegetarian: true
      },
      {
        id: 'pizza-garlic',
        name: 'Garlic Bread (4 Pcs)',
        price: 350,
        description: 'Thick, crusty baguette slices slathered in our homemade sweet garlic herb butter, toasted until bubbling-hot and golden brown around the edges.',
        image: 'https://images.unsplash.com/photo-1573140247632-f8fd74997d5c?auto=format&fit=crop&w=400&q=80',
        category: 'Side',
        isVegetarian: true
      },
      {
        id: 'pizza-fries',
        name: 'Spicy Masala Fries',
        price: 250,
        description: 'Hot french fries generously dusted with a custom, mouth-watering blend of Pakistani red chili, chat masala, and exotic ground spices.',
        image: 'https://images.unsplash.com/photo-1585109649139-366815a0d713?auto=format&fit=crop&w=400&q=80',
        category: 'Side',
        isVegetarian: true
      }
    ]
  },
  {
    id: 'biryani-house',
    name: 'Biryani House',
    category: 'Pakistani Food',
    rating: 4.9,
    reviewsCount: 2310,
    image: 'https://images.unsplash.com/photo-1633945274405-b6c8069047b0?auto=format&fit=crop&w=600&q=80',
    tags: ['Pakistani Food', 'Biryani', 'Traditional'],
    prepTime: '20-30 min',
    minOrder: 200,
    deliveryFee: 80,
    ownerId: 'rest-owner-4',
    status: 'active',
    isHotel: false,
    menu: [
      {
        id: 'biryani-chicken',
        name: 'Special Chicken Biryani',
        price: 450,
        description: 'The King of Biryanis! Aged basmati rice cooked layered with saffron, mint, crisp onions, and tender chicken marinated in a top-secret spiced yogurt gravy.',
        image: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=400&q=80',
        category: 'Main',
        isPopular: true
      },
      {
        id: 'biryani-pulao',
        name: 'Beef Bannu Pulao',
        price: 500,
        description: 'An aromatic, deeply savory rice delicacy made with slow-cooked bone-in tender beef broth, brown onions, and high-grade long-grain basmati rice.',
        image: 'https://images.unsplash.com/photo-1601050690597-df056fb4ce78?auto=format&fit=crop&w=400&q=80',
        category: 'Main',
        isPopular: true
      },
      {
        id: 'biryani-tikka',
        name: 'Chicken Tikka Boti',
        price: 380,
        description: 'Juicy skewers of hand-cut chicken cubes marinated in heavy yogurt, lemon juice, red chilies, and authentic tandoor spices, cooked over active charcoal.',
        image: 'https://images.unsplash.com/photo-1599487488170-d11ec9c172f0?auto=format&fit=crop&w=400&q=80',
        category: 'Side'
      },
      {
        id: 'biryani-raita',
        name: 'Mint Raita & Salad Cup',
        price: 120,
        description: 'Fresh cooling yogurt whisked with crushed mountain mint and roasted cumin, paired with a cup of freshly sliced crisp onions, cucumbers, and tomatoes.',
        image: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=400&q=80',
        category: 'Side',
        isVegetarian: true
      }
    ]
  }
];

export const PROMO_CODES: PromoCode[] = [
  {
    code: 'FOODWALA50',
    discountType: 'fixed',
    value: 150,
    description: 'Rs. 150 off on orders above Rs. 1000',
    minSpend: 1000
  },
  {
    code: 'FIRSTEAT',
    discountType: 'percentage',
    value: 20,
    description: '20% off on your order, no minimum spend!',
    minSpend: 0
  },
  {
    code: 'FREEFRIES',
    discountType: 'fixed',
    value: 250,
    description: 'Rs. 250 off on orders above Rs. 800',
    minSpend: 800
  }
];
