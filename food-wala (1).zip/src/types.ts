export type Role = 'super_owner' | 'admin' | 'restaurant' | 'rider' | 'customer';

export interface User {
  id: string;
  name: string;
  email: string;
  role: Role;
  status: 'active' | 'suspended' | 'blocked';
  created_at: string;
  password?: string;
  passcode?: string;
  username?: string;
}

export interface MenuItem {
  id: string;
  name: string;
  price: number;
  description: string;
  image: string;
  category: 'Main' | 'Side' | 'Beverage' | 'Dessert';
  isPopular?: boolean;
  isVegetarian?: boolean;
}

export interface Restaurant {
  id: string;
  name: string;
  category: string;
  rating: number;
  reviewsCount: number;
  image: string;
  tags: string[];
  prepTime: string;
  minOrder: number;
  deliveryFee: number;
  menu: MenuItem[];
  ownerId: string;
  status: 'active' | 'pending' | 'suspended';
  isHotel?: boolean;
  categoryVisuals?: Record<string, { icon?: string; image?: string }>;
}

export interface CartItem {
  menuItem: MenuItem;
  quantity: number;
  restaurantId: string;
  restaurantName: string;
}

export interface PromoCode {
  code: string;
  discountType: 'fixed' | 'percentage';
  value: number;
  description: string;
  minSpend?: number;
}

export interface Order {
  id: string;
  items: CartItem[];
  subtotal: number;
  discount: number;
  deliveryFee: number;
  total: number;
  customerName: string;
  phone: string;
  address: string;
  notes?: string;
  status: 'received' | 'preparing' | 'delivery' | 'delivered' | 'payment_verification' | 'payment_rejected' | 'paid';
  date: string;
  deliveryMethod: 'delivery' | 'pickup';
  paymentMethod?: string;
  transactionId?: string;
  amountPaid?: number;
  screenshot?: string;
  rating?: number;
  ratingNote?: string;
}

export interface Rider {
  id: string;
  name: string;
  phone: string;
  status: 'available' | 'delivering';
  vehicle: string;
  rating?: number;
  reviewsCount?: number;
  completedDeliveries: number;
}
export interface WalletTransaction {
  id: string;
  type: 'deposit' | 'payment' | 'refund' | 'cashback' | 'withdrawal';
  amount: number;
  channel?: 'easypaisa' | 'jazzcash' | 'cash_deposit' | 'wallet_system';
  referenceId?: string;
  timestamp: string;
  status: 'pending' | 'completed' | 'failed';
  notes?: string;
  senderPhone?: string;
  accountName?: string;
  accountNo?: string;
}
